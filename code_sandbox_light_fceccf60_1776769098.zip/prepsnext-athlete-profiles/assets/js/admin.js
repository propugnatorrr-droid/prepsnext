/**
 * PrepsNext Athlete Profiles — Admin JavaScript
 */
(function ($) {
    'use strict';

    // ── Media Uploader ────────────────────────────────────────────────────
    var mediaFrame;

    $(document).on('click', '.pn-upload-image', function (e) {
        e.preventDefault();
        var $btn     = $(this);
        var $wrap    = $btn.closest('.pn-image-upload');
        var fieldName = $wrap.data('field');

        mediaFrame = wp.media({
            title:    prepsnextAdmin.strings.uploadImage,
            button:   { text: prepsnextAdmin.strings.selectImage },
            multiple: false,
            library:  { type: 'image' },
        });

        mediaFrame.on('select', function () {
            var attachment = mediaFrame.state().get('selection').first().toJSON();
            $wrap.find('input[type="hidden"]').val(attachment.id);
            var imgHtml = '<img src="' + (attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url) + '" alt="">';
            imgHtml += '<button type="button" class="pn-remove-image button">' + prepsnextAdmin.strings.removeImage + '</button>';
            $wrap.find('.pn-image-preview').html(imgHtml);
        });

        mediaFrame.open();
    });

    $(document).on('click', '.pn-remove-image', function (e) {
        e.preventDefault();
        var $wrap = $(this).closest('.pn-image-upload');
        $wrap.find('input[type="hidden"]').val('');
        $wrap.find('.pn-image-preview').html(
            '<button type="button" class="pn-upload-image button button-primary">' + prepsnextAdmin.strings.uploadImage + '</button>'
        );
    });

    // ── Season Rows ────────────────────────────────────────────────────────
    var seasonIndex = $('#pn-seasons-wrap .pn-season-row').length;

    $(document).on('click', '#pn-add-season', function () {
        var template = $('#pn-season-template').html();
        if (!template) return;
        template = template.replace(/\{\{INDEX\}\}/g, seasonIndex);
        $('#pn-seasons-wrap').append('<div class="pn-season-row" data-index="' + seasonIndex + '">' + template + '</div>');
        seasonIndex++;
    });

    $(document).on('click', '.pn-remove-season', function () {
        if (!confirm(prepsnextAdmin.strings.confirmDelete)) return;
        $(this).closest('.pn-season-row').remove();
    });

    $(document).on('click', '.pn-toggle-season', function (e) {
        e.stopPropagation();
        var body = $(this).closest('.pn-season-row').find('.pn-season-body');
        body.slideToggle(200);
        $(this).text(body.is(':visible') ? '▼' : '▶');
    });

    // Update season title as user types grade/year
    $(document).on('change keyup', '.pn-season-row select[name*="[grade]"], .pn-season-row input[name*="[year]"]', function () {
        var $row   = $(this).closest('.pn-season-row');
        var grade  = $row.find('select[name*="[grade]"]').val() || '';
        var year   = $row.find('input[name*="[year]"]').val() || '';
        $row.find('.pn-season-title').text(grade || year ? (grade + ' ' + year).trim() : 'Season');
    });

    // ── Sortable seasons ──────────────────────────────────────────────────
    if ($.fn.sortable) {
        $('#pn-seasons-wrap').sortable({
            handle: '.pn-drag-handle',
            axis: 'y',
            placeholder: 'pn-sortable-placeholder',
            update: function () {
                reindexSeasons();
            }
        });
    }

    function reindexSeasons() {
        $('#pn-seasons-wrap .pn-season-row').each(function (i) {
            $(this).attr('data-index', i);
            $(this).find('[name]').each(function () {
                var name = $(this).attr('name');
                // Replace pn_seasons[N] with pn_seasons[i]
                name = name.replace(/pn_seasons\[\d+\]/, 'pn_seasons[' + i + ']');
                $(this).attr('name', name);
            });
        });
    }

    // ── Media Gallery ─────────────────────────────────────────────────────
    var mediaGalleryIndex = $('#pn-media-gallery .pn-media-item').length;

    $(document).on('click', '#pn-add-media-item', function () {
        var template = $('#pn-media-item-template').html();
        if (!template) return;
        template = template.replace(/\{\{INDEX\}\}/g, mediaGalleryIndex);
        $('#pn-media-gallery').append(
            '<div class="pn-media-item" data-index="' + mediaGalleryIndex + '">' + template + '</div>'
        );
        mediaGalleryIndex++;
    });

    $(document).on('click', '.pn-remove-media-item', function () {
        if (!confirm(prepsnextAdmin.strings.confirmDelete)) return;
        $(this).closest('.pn-media-item').remove();
    });

    // ── Media gallery sortable ─────────────────────────────────────────────
    if ($.fn.sortable) {
        $('#pn-media-gallery').sortable({
            handle: '.pn-drag-handle',
            placeholder: 'pn-sortable-placeholder',
        });
    }

    // ── Related Posts AJAX Search ─────────────────────────────────────────
    $(document).on('click', '#pn-related-search-btn', function () {
        var query = $('#pn-related-search-input').val().trim();
        if (!query) return;

        var $results = $('#pn-related-search-results');
        $results.html('<p>Searching...</p>');

        $.post(prepsnextAdmin.ajaxUrl, {
            action: 'pn_search_posts',
            nonce:  prepsnextAdmin.nonce,
            query:  query,
        }, function (response) {
            if (!response.success || !response.data.length) {
                $results.html('<p style="color:#8c8f94">No posts found.</p>');
                return;
            }
            var html = '';
            $.each(response.data, function (i, post) {
                html += '<div class="pn-search-result-item">';
                html += '<span>' + post.title + ' (ID: ' + post.id + ')</span>';
                html += '<button type="button" class="button button-small pn-add-related" data-id="' + post.id + '" data-title="' + post.title + '">+ Add</button>';
                html += '</div>';
            });
            $results.html(html);
        });
    });

    $(document).on('click', '.pn-add-related', function () {
        var id    = $(this).data('id');
        var title = $(this).data('title');

        // Check if already added
        if ($('#pn-related-posts input[value="' + id + '"]').length) {
            alert('This post is already linked.');
            return;
        }

        var html = '<div class="pn-related-post-item">';
        html += '<input type="hidden" name="pn_related_posts[]" value="' + id + '">';
        html += '<span>' + title + ' (ID: ' + id + ')</span>';
        html += '<button type="button" class="pn-remove-related button button-small pn-danger">✕</button>';
        html += '</div>';

        $('#pn-related-posts').append(html);
        $(this).text('✓ Added').prop('disabled', true);
    });

    $(document).on('click', '.pn-remove-related', function () {
        $(this).closest('.pn-related-post-item').remove();
    });

    // ── Enter key search ─────────────────────────────────────────────────
    $(document).on('keypress', '#pn-related-search-input', function (e) {
        if (e.which === 13) {
            e.preventDefault();
            $('#pn-related-search-btn').trigger('click');
        }
    });

    // ── Settings color picker ─────────────────────────────────────────────
    if ($.fn.wpColorPicker) {
        $('.pn-color-picker').wpColorPicker();
    }

    // ── Init ──────────────────────────────────────────────────────────────
    $(document).ready(function () {
        // Collapse all seasons by default except first
        $('#pn-seasons-wrap .pn-season-row').each(function (i) {
            if (i > 0) {
                $(this).find('.pn-season-body').hide();
                $(this).find('.pn-toggle-season').text('▶');
            }
        });
    });

})(jQuery);
