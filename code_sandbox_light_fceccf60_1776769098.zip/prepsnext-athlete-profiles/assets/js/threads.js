/**
 * PrepsNext Threads — Frontend JS
 * Handles: posting, likes, reposts, comments, follows,
 *          infinite scroll, notifications, modals, toasts.
 */
(function ($) {
    'use strict';

    const cfg = window.pnThreads || {};
    const ajax = cfg.ajaxUrl;
    const nonce = cfg.nonce;
    const approved = !!cfg.isApproved;
    const loggedIn = !!cfg.userId;

    /* ── Utility ─────────────────────────────────────────────── */
    function toast(msg, type = '') {
        const $t = $('#pnt-toast');
        $t.text(msg)
          .removeClass('pnt-toast--success pnt-toast--error')
          .addClass(type ? 'pnt-toast--' + type : '')
          .fadeIn(180);
        clearTimeout($t.data('timer'));
        $t.data('timer', setTimeout(() => $t.fadeOut(300), 3000));
    }

    function requireApproval(action) {
        if (!loggedIn)  { toast(cfg.strings.loginRequired, 'error');   return false; }
        if (!approved)  { toast(cfg.strings.pendingApproval, 'error'); return false; }
        return true;
    }

    function formatCount(n) {
        if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
        if (n >= 1000)    return (n/1000).toFixed(1) + 'K';
        return String(n);
    }

    /* ── Character counter ───────────────────────────────────── */
    $(document).on('input', '#pnt-compose-body, .pnt-compose-textarea', function () {
        const max = 500;
        const rem = max - $(this).val().length;
        const $cnt = $(this).closest('.pnt-compose-fields, .pnt-modal, .pnt-compose-inner').find('.pnt-char-count');
        if ($cnt.length) {
            $cnt.text(rem)
                .toggleClass('pnt-char-warning', rem <= 80 && rem > 20)
                .toggleClass('pnt-char-danger',  rem <= 20);
        }
        // Show meta row when typing
        if ($(this).attr('id') === 'pnt-compose-body') {
            $('#pnt-compose-meta').toggle($(this).val().length > 0 || $('#pnt-compose-img-preview img').length > 0);
        }
    });

    /* ── Compose image preview ───────────────────────────────── */
    $(document).on('change', '#pnt-compose-img', function () {
        const file = this.files[0];
        if (!file) return;
        if (file.size > cfg.imgMax) { toast(cfg.strings.imgTooLarge, 'error'); this.value = ''; return; }
        const allowed = ['image/jpeg','image/png','image/gif','image/webp'];
        if (!allowed.includes(file.type)) { toast(cfg.strings.imgBadType, 'error'); this.value = ''; return; }
        const reader = new FileReader();
        reader.onload = e => {
            $('#pnt-compose-img-preview')
                .html('<img src="' + e.target.result + '" alt=""><button class="pnt-compose-img-remove" id="pnt-remove-compose-img">✕</button>');
            $('#pnt-compose-meta').show();
        };
        reader.readAsDataURL(file);
    });

    $(document).on('click', '#pnt-remove-compose-img', function () {
        $('#pnt-compose-img-preview').empty();
        $('#pnt-compose-img').val('');
        if (!$('#pnt-compose-body').val().length) $('#pnt-compose-meta').hide();
    });

    /* ── Post new thread ─────────────────────────────────────── */
    $(document).on('click', '#pnt-post-btn', function () {
        if (!requireApproval()) return;
        const $btn   = $(this);
        const body   = $('#pnt-compose-body').val().trim();
        const sport  = $('#pnt-compose-sport').val();
        const imgFile = $('#pnt-compose-img')[0] && $('#pnt-compose-img')[0].files[0];

        if (!body && !imgFile) { toast('Write something first.', 'error'); return; }
        if (body.length > 500) { toast('Max 500 characters.', 'error'); return; }

        $btn.text(cfg.strings.posting).prop('disabled', true);

        const fd = new FormData();
        fd.append('action', 'pn_post_thread');
        fd.append('nonce', nonce);
        fd.append('body', body);
        fd.append('sport_tag', sport);
        if (imgFile) fd.append('media', imgFile);

        $.ajax({ url: ajax, method: 'POST', data: fd, processData: false, contentType: false })
         .done(res => {
             if (res.success) {
                 $('#pnt-compose-body').val('').trigger('input');
                 $('#pnt-compose-img').val('');
                 $('#pnt-compose-img-preview').empty();
                 $('#pnt-compose-meta').hide();
                 $('#pnt-thread-list').prepend(res.data.html);
                 toast('Posted! 🎉', 'success');
             } else {
                 toast(res.data.msg || 'Error posting.', 'error');
             }
         })
         .fail(() => toast('Server error.', 'error'))
         .always(() => $btn.text('Post').prop('disabled', false));
    });

    /* ── Feed filter tabs ────────────────────────────────────── */
    let currentFilter = 'all';
    let currentSport  = '';
    let feedPage      = 2;
    let hasMore       = true;

    function switchFeed(filter, sport = '') {
        currentFilter = filter;
        currentSport  = sport;
        feedPage      = 1;
        hasMore       = true;
        loadFeed(true);
    }

    function loadFeed(replace = false) {
        if (!hasMore && !replace) return;
        const $list = $('#pnt-thread-list');
        const $btn  = $('#pnt-load-more');
        if (replace) $list.html('<div class="pnt-loading-spinner"></div>');
        $btn.prop('disabled', true);

        $.post(ajax, { action:'pn_get_feed', nonce, page: replace ? 1 : feedPage, filter: currentFilter, sport: currentSport })
         .done(res => {
             if (res.success) {
                 if (replace) $list.empty();
                 if (res.data.html) {
                     $list.append(res.data.html);
                     feedPage++;
                 } else if (replace) {
                     $list.html('<div class="pnt-empty-state"><div class="pnt-empty-icon">🏟️</div><h3>Nothing here yet</h3><p>Be the first to post.</p></div>');
                 }
                 hasMore = res.data.has_more;
                 $('#pnt-load-more-wrap').toggle(hasMore);
             }
         })
         .always(() => $btn.prop('disabled', false));
    }

    // Desktop tabs
    $(document).on('click', '.pnt-nav-tab', function () {
        $('.pnt-nav-tab').removeClass('pnt-nav-tab--active');
        $(this).addClass('pnt-nav-tab--active');
        const filter = $(this).data('filter');
        const sport  = $(this).data('sport') || '';
        switchFeed(filter === 'sport' ? 'all' : filter, sport);
    });

    // Mobile tabs
    $(document).on('click', '.pnt-feed-tab', function () {
        $('.pnt-feed-tab').removeClass('pnt-feed-tab--active');
        $(this).addClass('pnt-feed-tab--active');
        const filter = $(this).data('filter');
        const sport  = $(this).data('sport') || '';
        switchFeed(filter === 'sport' ? 'all' : filter, sport);
    });

    // Load more
    $(document).on('click', '#pnt-load-more', function () {
        loadFeed(false);
    });

    /* ── Thread detail modal ─────────────────────────────────── */
    $(document).on('click', '.pnt-thread-card:not(.pnt-thread-card--detail)', function (e) {
        if ($(e.target).closest('.pnt-action-btn, .pnt-btn-icon, .pnt-repost-btn, button, a, textarea, input, select, label').length) return;
        const id = $(this).data('thread-id');
        openThreadModal(id);
    });

    function openThreadModal(id) {
        const $modal = $('#pnt-thread-modal');
        const $body  = $('#pnt-modal-body');
        $body.html('<div class="pnt-loading-spinner"></div>');
        $modal.fadeIn(150);
        $('body').css('overflow', 'hidden');

        $.post(ajax, { action:'pn_get_thread_detail', nonce, thread_id: id })
         .done(res => {
             if (res.success) $body.html(res.data.html);
             else $body.html('<p style="padding:20px;color:#888">Could not load thread.</p>');
         });
    }

    $(document).on('click', '#pnt-modal-close, #pnt-thread-modal', function (e) {
        if (e.target === this || $(e.target).is('#pnt-modal-close')) {
            $('#pnt-thread-modal').fadeOut(150);
            $('body').css('overflow', '');
        }
    });

    // ESC key
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            $('#pnt-thread-modal, #pnt-repost-modal').fadeOut(150);
            $('body').css('overflow', '');
        }
    });

    /* ── Like ────────────────────────────────────────────────── */
    $(document).on('click', '.pnt-like-btn', function (e) {
        e.stopPropagation();
        if (!requireApproval()) return;
        const $btn     = $(this);
        const itemId   = $btn.data('item-id');
        const itemType = $btn.data('item-type') || 'thread';

        $btn.prop('disabled', true);
        $.post(ajax, { action:'pn_toggle_like', nonce, item_id: itemId, item_type: itemType })
         .done(res => {
             if (res.success) {
                 $btn.toggleClass('pnt-liked', res.data.liked);
                 $btn.find('svg').attr('fill', res.data.liked ? 'var(--pnt-red)' : 'none')
                                 .attr('stroke', res.data.liked ? 'var(--pnt-red)' : 'currentColor');
                 $btn.find('.pnt-action-count').text(formatCount(res.data.count));
             }
         })
         .always(() => $btn.prop('disabled', false));
    });

    /* ── Repost / Quote flow ─────────────────────────────────── */
    let pendingRepostId = null;

    $(document).on('click', '.pnt-repost-btn', function (e) {
        e.stopPropagation();
        if (!requireApproval()) return;
        pendingRepostId = $(this).data('thread-id');
        $('#pnt-quote-compose').hide();
        $('#pnt-quote-body').val('');
        $('#pnt-repost-modal').fadeIn(150);
        $('body').css('overflow', 'hidden');
    });

    $(document).on('click', '#pnt-repost-plain', function () {
        submitRepost('');
    });

    $(document).on('click', '#pnt-quote-open', function () {
        $('#pnt-quote-compose').slideDown(160);
    });

    $(document).on('click', '#pnt-quote-submit', function () {
        submitRepost($('#pnt-quote-body').val().trim());
    });

    function submitRepost(quoteBody) {
        const $btn = $('#pnt-repost-plain, #pnt-quote-submit').filter(':visible').first();
        $btn.prop('disabled', true);
        $.post(ajax, { action:'pn_toggle_repost', nonce, thread_id: pendingRepostId, quote_body: quoteBody })
         .done(res => {
             if (res.success) {
                 const $card = $('[data-thread-id="' + pendingRepostId + '"] .pnt-repost-btn').first();
                 $card.toggleClass('pnt-reposted', res.data.reposted);
                 $card.find('svg').attr('stroke', res.data.reposted ? 'var(--pnt-accent)' : 'currentColor');
                 $card.find('.pnt-action-count').text(formatCount(res.data.count));
                 toast(res.data.reposted ? 'Reposted! 🔁' : 'Repost removed.', res.data.reposted ? 'success' : '');
                 if (res.data.reposted && res.data.html) $('#pnt-thread-list').prepend(res.data.html);
             }
         })
         .fail(() => toast('Error.', 'error'))
         .always(() => {
             $btn.prop('disabled', false);
             $('#pnt-repost-modal').fadeOut(150);
             $('body').css('overflow', '');
         });
    }

    $(document).on('click', '.pnt-repost-cancel, #pnt-repost-modal', function (e) {
        if (e.target === this || $(e.target).is('.pnt-repost-cancel')) {
            $('#pnt-repost-modal').fadeOut(150);
            $('body').css('overflow', '');
        }
    });

    /* ── Comment ─────────────────────────────────────────────── */
    $(document).on('click', '.pnt-comment-btn', function (e) {
        e.stopPropagation();
        if (!approved) { toast(cfg.strings.pendingApproval, 'error'); return; }
        const id = $(this).data('thread-id');
        openThreadModal(id);
    });

    // Submit comment form (inside modal or detail page)
    $(document).on('submit', '.pnt-comment-form', function (e) {
        e.preventDefault();
        if (!requireApproval()) return;
        const $form    = $(this);
        const threadId = $form.data('thread-id');
        const body     = $form.find('.pnt-comment-input').val().trim();
        const parentId = $form.data('parent-id') || 0;
        const imgFile  = $form.find('.pnt-comment-img-input')[0] && $form.find('.pnt-comment-img-input')[0].files[0];

        if (!body && !imgFile) return;

        const $btn = $form.find('button[type="submit"]');
        $btn.prop('disabled', true);

        const fd = new FormData();
        fd.append('action', 'pn_post_comment');
        fd.append('nonce', nonce);
        fd.append('thread_id', threadId);
        fd.append('body', body);
        fd.append('parent_id', parentId);
        if (imgFile) fd.append('media', imgFile);

        $.ajax({ url: ajax, method: 'POST', data: fd, processData: false, contentType: false })
         .done(res => {
             if (res.success) {
                 $form.find('.pnt-comment-input').val('');
                 $form.find('.pnt-comment-img-input').val('');
                 $form.find('.pnt-comment-img-preview').hide().empty();
                 const $section = $form.closest('.pnt-comments-section');
                 $section.replaceWith(res.data.html);
                 // Update comment count on card
                 $('[data-thread-id="' + threadId + '"] .pnt-comment-btn .pnt-action-count').each(function () {
                     const cur = parseInt($(this).text()) || 0;
                     $(this).text(cur + 1);
                 });
                 toast('Reply posted!', 'success');
             } else {
                 toast(res.data.msg || 'Error.', 'error');
             }
         })
         .fail(() => toast('Server error.', 'error'))
         .always(() => $btn.prop('disabled', false));
    });

    // Reply to comment — prepopulate parent_id
    $(document).on('click', '.pnt-reply-to-comment', function (e) {
        e.stopPropagation();
        const commentId = $(this).data('comment-id');
        const threadId  = $(this).data('thread-id');
        const name      = $(this).data('name');
        const $section  = $(this).closest('.pnt-comments-section');
        const $form     = $section.find('.pnt-comment-form');
        $form.data('parent-id', commentId);
        $form.find('.pnt-comment-input').val('@' + name + ' ').focus().trigger('input');
    });

    // Comment image preview
    $(document).on('change', '.pnt-comment-img-input', function () {
        const file = this.files[0];
        if (!file) return;
        if (file.size > cfg.imgMax) { toast(cfg.strings.imgTooLarge, 'error'); this.value = ''; return; }
        const reader = new FileReader();
        reader.onload = e => {
            $(this).closest('.pnt-comment-input-wrap')
                   .find('.pnt-comment-img-preview')
                   .html('<img src="' + e.target.result + '" alt="">')
                   .show();
        };
        reader.readAsDataURL(file);
    });

    /* ── Delete thread ───────────────────────────────────────── */
    $(document).on('click', '.pnt-delete-thread', function (e) {
        e.stopPropagation();
        if (!confirm(cfg.strings.confirmDelete)) return;
        const id   = $(this).data('id');
        const $card= $(this).closest('.pnt-thread-card');
        $.post(ajax, { action:'pn_delete_thread', nonce, thread_id: id })
         .done(res => {
             if (res.success) {
                 $card.fadeOut(300, function () { $(this).remove(); });
                 // Close modal if open
                 $('#pnt-thread-modal').fadeOut(150);
                 toast('Thread deleted.', '');
             } else { toast('Cannot delete.', 'error'); }
         });
    });

    /* ── Delete comment ──────────────────────────────────────── */
    $(document).on('click', '.pnt-delete-comment', function (e) {
        e.stopPropagation();
        const id = $(this).data('id');
        const $c = $(this).closest('.pnt-comment');
        $.post(ajax, { action:'pn_delete_comment', nonce, comment_id: id })
         .done(res => {
             if (res.success) $c.fadeOut(200, function () { $(this).remove(); });
         });
    });

    /* ── Follow / Unfollow ───────────────────────────────────── */
    $(document).on('click', '.pnt-follow-btn', function (e) {
        e.stopPropagation();
        if (!requireApproval()) return;
        const $btn    = $(this);
        const userId  = $btn.data('user-id');
        $btn.prop('disabled', true);
        $.post(ajax, { action:'pn_toggle_follow', nonce, user_id: userId })
         .done(res => {
             if (res.success) {
                 const following = res.data.following;
                 $btn.toggleClass('pnt-following', following)
                     .text(following ? 'Following' : 'Follow');
                 $('[data-follower-count]').text(res.data.count + ' followers');
                 toast(following ? 'Following! 👤' : 'Unfollowed.', following ? 'success' : '');
             }
         })
         .always(() => $btn.prop('disabled', false));
    });

    /* ── Share / Copy link ───────────────────────────────────── */
    $(document).on('click', '.pnt-share-btn', function (e) {
        e.stopPropagation();
        const threadId = $(this).data('thread-id');
        const url      = cfg.feedUrl + '?thread=' + threadId;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(url).then(() => toast('Link copied! 🔗', 'success'));
        } else {
            const $tmp = $('<input>').val(url).appendTo('body').select();
            document.execCommand('copy');
            $tmp.remove();
            toast('Link copied! 🔗', 'success');
        }
    });

    /* ── Notifications ───────────────────────────────────────── */
    $(document).on('click', '#pnt-notif-btn', function (e) {
        e.stopPropagation();
        const $panel = $('#pnt-notif-panel');
        if ($panel.is(':visible')) { $panel.hide(); return; }
        $panel.show();
        loadNotifications();
    });

    $(document).on('click', '#pnt-notif-close', function () {
        $('#pnt-notif-panel').hide();
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('#pnt-notif-btn, #pnt-notif-panel').length)
            $('#pnt-notif-panel').hide();
    });

    function loadNotifications() {
        $.post(ajax, { action:'pn_get_notifications', nonce })
         .done(res => {
             if (!res.success) return;
             const items = res.data;
             const $list = $('#pnt-notif-list');
             if (!items.length) {
                 $list.html('<div class="pnt-notif-empty">No notifications yet.</div>');
                 return;
             }
             let html = '';
             items.forEach(n => {
                 const cls = n.is_read ? '' : ' pnt-notif-item--unread';
                 const link = n.link ? ' href="' + n.link + '"' : '';
                 const tag  = n.link ? 'a' : 'div';
                 html += '<' + tag + ' class="pnt-notif-item' + cls + '"' + link + '>'
                       + '<span class="pnt-notif-icon">' + n.icon + '</span>'
                       + '<span class="pnt-notif-text">' + n.text + '</span>'
                       + '<span class="pnt-notif-time">' + n.time + '</span>'
                       + '</' + tag + '>';
             });
             $list.html(html);
             // Mark as read
             $.post(ajax, { action:'pn_mark_notifs_read', nonce });
             $('#pnt-notif-badge').remove();
         });
    }

    /* ── Profile page: thread/repost tabs ───────────────────── */
    $(document).on('click', '.pnt-profile-tab', function () {
        const target = $(this).data('tab');
        $('.pnt-profile-tab').removeClass('pnt-profile-tab--active');
        $(this).addClass('pnt-profile-tab--active');
        $('.pnt-profile-tab-content').removeClass('pnt-profile-tab-content--active');
        $('#pnt-tab-' + target).addClass('pnt-profile-tab-content--active');

        // If threads/reposts, load via AJAX
        if (target === 'threads' || target === 'reposts') {
            const uid = $(this).data('uid');
            loadProfileThreads(uid, 1, target, true);
        }
    });

    function loadProfileThreads(uid, page, type, replace) {
        const $list = $('#pnt-profile-threads-list');
        if (replace) $list.html('<div class="pnt-loading-spinner"></div>');
        $.post(ajax, { action:'pn_get_profile_threads', nonce, profile_uid: uid, page, type })
         .done(res => {
             if (replace) $list.empty();
             if (res.success && res.data.html) $list.append(res.data.html);
             else if (replace) $list.html('<div class="pnt-empty-state"><p>No threads yet.</p></div>');
         });
    }

    /* ── Auto-open thread from URL param ─────────────────────── */
    const urlThread = new URLSearchParams(window.location.search).get('thread');
    if (urlThread) {
        $(document).ready(() => setTimeout(() => openThreadModal(parseInt(urlThread)), 400));
    }

    /* ── Password toggle (auth pages) ───────────────────────── */
    $(document).on('click', '.pnt-eye-toggle', function () {
        const $input = $(this).siblings('input');
        const type   = $input.attr('type') === 'password' ? 'text' : 'password';
        $input.attr('type', type);
        $(this).text(type === 'password' ? '👁' : '🙈');
    });

    /* ── Auto-resize textareas ───────────────────────────────── */
    $(document).on('input', 'textarea.pnt-compose-textarea, textarea.pnt-comment-input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

})(jQuery);
