/**
 * PrepsNext Athlete Profiles — Frontend JavaScript
 */
(function ($) {
    'use strict';

    // ── Tab Navigation ────────────────────────────────────────────────────
    $(document).on('click', '.pn-tab', function (e) {
        e.preventDefault();
        var target = $(this).data('tab');
        var section = '#pn-' + target;

        // Update tabs
        $('.pn-tab').removeClass('active');
        $(this).addClass('active');

        // Update sections
        $('.pn-tab-section').removeClass('active');
        $(section).addClass('active');

        // Smooth scroll to content if needed
        var tabsTop = $('.pn-profile-tabs').offset().top;
        var scrollTop = $(window).scrollTop();
        if (scrollTop > tabsTop + 60) {
            $('html, body').animate({ scrollTop: tabsTop - 10 }, 250);
        }

        // Update URL hash without page jump
        if (history.replaceState) {
            history.replaceState(null, null, '#pn-' + target);
        }
    });

    // ── Handle URL hash on page load ─────────────────────────────────────
    function initTabFromHash() {
        var hash = window.location.hash;
        if (hash && hash.startsWith('#pn-')) {
            var tabId = hash.replace('#pn-', '');
            var tab = $('.pn-tab[data-tab="' + tabId + '"]');
            if (tab.length) {
                tab.trigger('click');
            }
        }
    }

    // ── Video Modal ───────────────────────────────────────────────────────
    var modal = $('#pn-video-modal');

    function getEmbedUrl(url) {
        // YouTube
        var ytMatch = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
        if (ytMatch) {
            return 'https://www.youtube.com/embed/' + ytMatch[1] + '?autoplay=1&rel=0';
        }
        // Vimeo
        var vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
        if (vimeoMatch) {
            return 'https://player.vimeo.com/video/' + vimeoMatch[1] + '?autoplay=1';
        }
        // Direct video
        if (url.match(/\.(mp4|webm|ogg)$/i)) {
            return null; // use <video> tag
        }
        return url;
    }

    $(document).on('click', '.pn-media-thumb[data-video]', function () {
        var videoUrl = $(this).data('video');
        if (!videoUrl) return;
        openVideoModal(videoUrl);
    });

    $(document).on('click', '.pn-play-btn', function (e) {
        e.stopPropagation();
        var thumb = $(this).closest('.pn-media-thumb');
        var videoUrl = thumb.data('video');
        if (videoUrl) openVideoModal(videoUrl);
    });

    function openVideoModal(url) {
        var embedUrl = getEmbedUrl(url);
        var $container = modal.find('.pn-modal-video').empty();

        if (embedUrl) {
            $container.html('<iframe src="' + embedUrl + '" allowfullscreen allow="autoplay; encrypted-media"></iframe>');
        } else {
            $container.html('<video controls autoplay playsinline webkit-playsinline><source src="' + url + '" type="video/mp4"></video>');
        }

        modal.addClass('open');
        $('body').css('overflow', 'hidden');
    }

    function closeVideoModal() {
        modal.removeClass('open');
        modal.find('.pn-modal-video').empty();
        $('body').css('overflow', '');
    }

    $(document).on('click', '.pn-modal-close, .pn-modal-backdrop', closeVideoModal);
    $(document).on('keydown', function (e) { if (e.key === 'Escape') closeVideoModal(); });

    // ── Sticky Tabs ───────────────────────────────────────────────────────
    function updateStickyTabs() {
        var tabs = document.getElementById('pn-tabs');
        if (!tabs) return;
        var hero = document.getElementById('pn-hero');
        if (!hero) return;
        var heroBottom = hero.getBoundingClientRect().bottom;
        if (heroBottom <= 0) {
            tabs.classList.add('pn-tabs-sticky');
        } else {
            tabs.classList.remove('pn-tabs-sticky');
        }
    }

    // ── Scroll Spy ────────────────────────────────────────────────────────
    function scrollSpy() {
        var sections = $('.pn-tab-section.active');
        // Basic implementation – highlight active tab on scroll
        var scrollPos = $(window).scrollTop() + 120;

        $('.pn-tab-section').each(function () {
            var id = $(this).attr('id');
            var tab = $('.pn-tab[data-tab="' + id.replace('pn-', '') + '"]');
            if (!tab.length) return;
            var top = $(this).offset().top;
            var bottom = top + $(this).outerHeight();
            if (scrollPos >= top && scrollPos < bottom) {
                $('.pn-tab').removeClass('active');
                tab.addClass('active');
            }
        });
    }

    // ── Animate stats on scroll ───────────────────────────────────────────
    function animateStats() {
        $('.pn-stat-val').each(function () {
            var $el = $(this);
            if ($el.data('animated')) return;
            var rect = this.getBoundingClientRect();
            if (rect.top < window.innerHeight - 50) {
                $el.data('animated', true);
                var target = $el.text();
                $el.addClass('pn-stat-animated');
            }
        });
    }

    // ── Event listeners ───────────────────────────────────────────────────
    $(window).on('scroll', function () {
        updateStickyTabs();
        animateStats();
    });

    // ── Lazy load images ──────────────────────────────────────────────────
    if ('IntersectionObserver' in window) {
        var imgObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    imgObserver.unobserve(img);
                }
            });
        }, { threshold: 0.1, rootMargin: '100px' });

        $('img[data-src]').each(function () {
            imgObserver.observe(this);
        });
    }

    // ── Social link tooltips ──────────────────────────────────────────────
    $(document).on('mouseenter', '.pn-social-link', function () {
        var label = $(this).find('span').text();
        // Just enhance the title attribute
        if (!$(this).attr('title')) {
            $(this).attr('title', 'Visit on ' + label);
        }
    });

    // ── Share buttons (if added) ─────────────────────────────────────────
    $(document).on('click', '.pn-share-btn', function (e) {
        e.preventDefault();
        var type = $(this).data('share');
        var url  = encodeURIComponent(window.location.href);
        var text = encodeURIComponent(document.title);
        var shareUrl = '';

        if (type === 'twitter') {
            shareUrl = 'https://twitter.com/intent/tweet?url=' + url + '&text=' + text;
        } else if (type === 'facebook') {
            shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
        } else if (type === 'copy') {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(window.location.href).then(function () {
                    var btn = $('.pn-share-btn[data-share="copy"]');
                    btn.text('✓ Copied!');
                    setTimeout(function () { btn.text('Copy Link'); }, 2000);
                });
            }
            return;
        }

        if (shareUrl) {
            window.open(shareUrl, '_blank', 'width=600,height=400');
        }
    });

    // ── Media grid — first two are large ────────────────────────────────
    function layoutMediaGrid() {
        var tiles = $('.pn-media-tile');
        tiles.each(function (i) {
            if (i === 0 || i === 1) {
                $(this).addClass('pn-media-large');
            }
        });
    }

    // ── Init ──────────────────────────────────────────────────────────────
    $(document).ready(function () {
        initTabFromHash();
        updateStickyTabs();
        animateStats();
        layoutMediaGrid();
    });

})(jQuery);
