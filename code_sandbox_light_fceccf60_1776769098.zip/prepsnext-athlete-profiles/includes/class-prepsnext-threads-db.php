<?php
/**
 * PrepsNext Threads — Database Schema & Installer
 *
 * Creates / upgrades the custom tables used by the Threads social feed.
 * Called on plugin activation and on version bump.
 *
 * Tables (all prefixed with $wpdb->prefix):
 *   pn_threads         — posts/threads
 *   pn_thread_comments — comments on threads
 *   pn_thread_likes    — likes on threads OR comments
 *   pn_thread_reposts  — reposts of threads
 *   pn_thread_follows  — athlete-to-athlete follows
 *   pn_notifications   — in-app notification log
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Threads_DB {

    const SCHEMA_VERSION = '1.0';
    const OPTION_KEY     = 'prepsnext_threads_db_version';

    public static function install() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ── pn_threads ──────────────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_threads (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id       BIGINT(20) UNSIGNED NOT NULL,
            athlete_id    BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            body          TEXT NOT NULL,
            media_url     VARCHAR(512) DEFAULT NULL,
            media_type    ENUM('image','video','none') DEFAULT 'none',
            media_width   SMALLINT UNSIGNED DEFAULT NULL,
            media_height  SMALLINT UNSIGNED DEFAULT NULL,
            repost_of     BIGINT(20) UNSIGNED DEFAULT NULL,
            quote_body    TEXT DEFAULT NULL,
            sport_tag     VARCHAR(64) DEFAULT NULL,
            status        ENUM('published','deleted','pending') DEFAULT 'published',
            like_count    INT UNSIGNED DEFAULT 0,
            comment_count INT UNSIGNED DEFAULT 0,
            repost_count  INT UNSIGNED DEFAULT 0,
            view_count    INT UNSIGNED DEFAULT 0,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY athlete_id (athlete_id),
            KEY created_at (created_at),
            KEY status (status)
        ) $charset;" );

        // ── pn_thread_comments ──────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_thread_comments (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            thread_id     BIGINT(20) UNSIGNED NOT NULL,
            user_id       BIGINT(20) UNSIGNED NOT NULL,
            parent_id     BIGINT(20) UNSIGNED DEFAULT NULL,
            body          TEXT NOT NULL,
            media_url     VARCHAR(512) DEFAULT NULL,
            like_count    INT UNSIGNED DEFAULT 0,
            status        ENUM('published','deleted') DEFAULT 'published',
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY thread_id (thread_id),
            KEY user_id (user_id),
            KEY parent_id (parent_id)
        ) $charset;" );

        // ── pn_thread_likes ─────────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_thread_likes (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id       BIGINT(20) UNSIGNED NOT NULL,
            item_id       BIGINT(20) UNSIGNED NOT NULL,
            item_type     ENUM('thread','comment') DEFAULT 'thread',
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_item (user_id, item_id, item_type),
            KEY item_id (item_id)
        ) $charset;" );

        // ── pn_thread_reposts ───────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_thread_reposts (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id       BIGINT(20) UNSIGNED NOT NULL,
            thread_id     BIGINT(20) UNSIGNED NOT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_thread (user_id, thread_id),
            KEY thread_id (thread_id)
        ) $charset;" );

        // ── pn_thread_follows ───────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_thread_follows (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            follower_id   BIGINT(20) UNSIGNED NOT NULL,
            following_id  BIGINT(20) UNSIGNED NOT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY follow_pair (follower_id, following_id),
            KEY follower_id (follower_id),
            KEY following_id (following_id)
        ) $charset;" );

        // ── pn_notifications ────────────────────────────────────────────────
        dbDelta( "CREATE TABLE {$wpdb->prefix}pn_notifications (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id       BIGINT(20) UNSIGNED NOT NULL,
            actor_id      BIGINT(20) UNSIGNED NOT NULL,
            type          ENUM('like','comment','repost','follow','mention') NOT NULL,
            item_id       BIGINT(20) UNSIGNED DEFAULT NULL,
            item_type     ENUM('thread','comment') DEFAULT 'thread',
            is_read       TINYINT(1) DEFAULT 0,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY is_read (is_read),
            KEY created_at (created_at)
        ) $charset;" );

        update_option( self::OPTION_KEY, self::SCHEMA_VERSION );
    }

    public static function needs_install() {
        return get_option( self::OPTION_KEY ) !== self::SCHEMA_VERSION;
    }
}
