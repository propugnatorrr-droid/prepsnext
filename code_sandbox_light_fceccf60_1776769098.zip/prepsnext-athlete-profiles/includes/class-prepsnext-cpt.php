<?php
/**
 * Custom Post Type: pn_athlete
 *
 * IMPORTANT HOOK ORDER NOTE:
 * ::instance() is called from plugins_loaded so all add_action() calls here
 * happen BEFORE WordPress fires 'init'. That means register_post_type() will
 * be called at the correct time.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_CPT {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // 'init' has NOT fired yet when plugins_loaded runs, so this is safe.
        add_action( 'init', [ $this, 'register_post_type' ], 0 );

        // Admin list table columns
        add_filter( 'manage_pn_athlete_posts_columns',          [ $this, 'custom_columns' ] );
        add_action( 'manage_pn_athlete_posts_custom_column',    [ $this, 'custom_column_data' ], 10, 2 );
        add_filter( 'manage_edit-pn_athlete_sortable_columns',  [ $this, 'sortable_columns' ] );

        // Template loader
        add_filter( 'single_template',  [ $this, 'load_single_template' ] );
        add_filter( 'archive_template', [ $this, 'load_archive_template' ] );
    }

    // ── Called from activation hook (static, no instance needed) ────────────
    public static function register_post_type_static() {
        self::do_register_post_type();
    }

    // ── Called via add_action('init') during normal request ─────────────────
    public function register_post_type() {
        self::do_register_post_type();
    }

    // ── Shared registration logic ────────────────────────────────────────────
    private static function do_register_post_type() {
        if ( post_type_exists( 'pn_athlete' ) ) {
            return; // Already registered
        }

        $labels = [
            'name'               => __( 'Athlete Profiles', 'prepsnext' ),
            'singular_name'      => __( 'Athlete Profile', 'prepsnext' ),
            'menu_name'          => __( 'Athletes', 'prepsnext' ),
            'add_new'            => __( 'Add New Athlete', 'prepsnext' ),
            'add_new_item'       => __( 'Add New Athlete', 'prepsnext' ),
            'edit_item'          => __( 'Edit Athlete', 'prepsnext' ),
            'new_item'           => __( 'New Athlete', 'prepsnext' ),
            'view_item'          => __( 'View Athlete Profile', 'prepsnext' ),
            'search_items'       => __( 'Search Athletes', 'prepsnext' ),
            'not_found'          => __( 'No athletes found', 'prepsnext' ),
            'not_found_in_trash' => __( 'No athletes in trash', 'prepsnext' ),
            'all_items'          => __( 'All Athletes', 'prepsnext' ),
        ];

        register_post_type( 'pn_athlete', [
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => [ 'slug' => 'athletes', 'with_front' => false ],
            'capability_type'    => 'post',
            'has_archive'        => 'athletes',
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-groups',
            'supports'           => [ 'title', 'editor', 'thumbnail', 'author', 'excerpt' ],
            'show_in_rest'       => true,
        ] );
    }

    // ── Single profile template ──────────────────────────────────────────────
    public function load_single_template( $template ) {
        if ( ! is_singular( 'pn_athlete' ) ) {
            return $template;
        }
        // Theme override wins
        $theme = locate_template( [ 'prepsnext/single-athlete.php', 'single-pn_athlete.php' ] );
        if ( $theme ) {
            return $theme;
        }
        $plugin = PREPSNEXT_DIR . 'templates/single-athlete.php';
        return file_exists( $plugin ) ? $plugin : $template;
    }

    // ── Archive template ─────────────────────────────────────────────────────
    public function load_archive_template( $template ) {
        if ( ! is_post_type_archive( 'pn_athlete' ) ) {
            return $template;
        }
        $theme = locate_template( [ 'prepsnext/archive-athlete.php', 'archive-pn_athlete.php' ] );
        if ( $theme ) {
            return $theme;
        }
        $plugin = PREPSNEXT_DIR . 'templates/archive-athlete.php';
        return file_exists( $plugin ) ? $plugin : $template;
    }

    // ── Admin list columns ───────────────────────────────────────────────────
    public function custom_columns( $columns ) {
        $new = [];
        foreach ( $columns as $key => $val ) {
            $new[ $key ] = $val;
            if ( $key === 'title' ) {
                $new['pn_sport']      = __( 'Sport', 'prepsnext' );
                $new['pn_class_year'] = __( 'Class', 'prepsnext' );
                $new['pn_state']      = __( 'State', 'prepsnext' );
                $new['pn_school']     = __( 'School', 'prepsnext' );
                $new['pn_ranking']    = __( 'Ranking', 'prepsnext' );
                $new['pn_status']     = __( 'Status', 'prepsnext' );
            }
        }
        return $new;
    }

    public function custom_column_data( $column, $post_id ) {
        switch ( $column ) {

            case 'pn_sport':
                $terms = get_the_terms( $post_id, 'pn_sport' );
                if ( $terms && ! is_wp_error( $terms ) ) {
                    $sport = $terms[0]->name;
                    $icon  = ( strtolower( $sport ) === 'basketball' ) ? '🏀' : '🏈';
                    echo esc_html( $icon . ' ' . $sport );
                } else {
                    echo '—';
                }
                break;

            case 'pn_class_year':
                $terms = get_the_terms( $post_id, 'pn_class_year' );
                echo ( $terms && ! is_wp_error( $terms ) ) ? esc_html( $terms[0]->name ) : '—';
                break;

            case 'pn_state':
                $terms = get_the_terms( $post_id, 'pn_state' );
                echo ( $terms && ! is_wp_error( $terms ) ) ? esc_html( $terms[0]->name ) : '—';
                break;

            case 'pn_school':
                $val = get_post_meta( $post_id, '_pn_school_name', true );
                echo $val ? esc_html( $val ) : '—';
                break;

            case 'pn_ranking':
                $rank = get_post_meta( $post_id, '_pn_national_rank', true );
                echo $rank ? '#' . esc_html( $rank ) : '—';
                break;

            case 'pn_status':
                $status = get_post_meta( $post_id, '_pn_prospect_status', true );
                if ( $status === 'top_prospect' ) {
                    echo '<span class="pn-badge top">⭐ Top Prospect</span>';
                } elseif ( $status === 'stock_riser' ) {
                    echo '<span class="pn-badge riser">📈 Stock Riser</span>';
                } elseif ( $status === 'featured' ) {
                    echo '<span class="pn-badge featured">🔥 Featured</span>';
                } elseif ( $status === 'committed' ) {
                    echo '<span class="pn-badge riser">✅ Committed</span>';
                } elseif ( $status === 'signed' ) {
                    echo '<span class="pn-badge riser">📝 Signed</span>';
                } else {
                    echo '<span class="pn-badge standard">Standard</span>';
                }
                break;
        }
    }

    public function sortable_columns( $columns ) {
        $columns['pn_class_year'] = 'pn_class_year';
        $columns['pn_ranking']    = 'pn_ranking';
        return $columns;
    }
}
