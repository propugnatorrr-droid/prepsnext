<?php
/**
 * Admin Panel & Settings for PrepsNext
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Admin {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu_pages' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'wp_dashboard_setup', [ $this, 'add_dashboard_widget' ] );
    }

    public function add_menu_pages() {
        // Main settings page
        add_submenu_page(
            'edit.php?post_type=pn_athlete',
            __( 'PrepsNext Settings', 'prepsnext' ),
            __( 'Settings', 'prepsnext' ),
            'manage_options',
            'prepsnext-settings',
            [ $this, 'render_settings_page' ]
        );

        // Import/Export page
        add_submenu_page(
            'edit.php?post_type=pn_athlete',
            __( 'Import / Export', 'prepsnext' ),
            __( 'Import / Export', 'prepsnext' ),
            'manage_options',
            'prepsnext-import-export',
            [ $this, 'render_import_export_page' ]
        );

        // Rankings Manager
        add_submenu_page(
            'edit.php?post_type=pn_athlete',
            __( 'Rankings Manager', 'prepsnext' ),
            __( 'Rankings Manager', 'prepsnext' ),
            'manage_options',
            'prepsnext-rankings',
            [ $this, 'render_rankings_page' ]
        );
    }

    public function register_settings() {
        register_setting( 'prepsnext_settings_group', 'prepsnext_settings', [
            'sanitize_callback' => [ $this, 'sanitize_settings' ],
        ]);

        add_settings_section( 'pn_general', __( 'General Settings', 'prepsnext' ), null, 'prepsnext-settings' );
        add_settings_section( 'pn_display', __( 'Display Settings', 'prepsnext' ), null, 'prepsnext-settings' );
        add_settings_section( 'pn_contact', __( 'Contact Settings', 'prepsnext' ), null, 'prepsnext-settings' );
    }

    public function sanitize_settings( $input ) {
        $clean = [];
        $clean['accent_color']       = sanitize_hex_color( $input['accent_color'] ?? '#AAFF00' );
        $clean['dark_bg']            = sanitize_hex_color( $input['dark_bg']       ?? '#111111' );
        $clean['show_contact_form']  = ! empty( $input['show_contact_form'] )  ? 1 : 0;
        $clean['enable_athlete_reg'] = ! empty( $input['enable_athlete_reg'] ) ? 1 : 0;
        $clean['default_sport']      = sanitize_text_field( $input['default_sport'] ?? 'basketball' );
        $clean['contact_email']      = sanitize_email( $input['contact_email'] ?? '' );
        $clean['archive_per_page']   = absint( $input['archive_per_page'] ?? 24 );
        $clean['show_social_in_hero']= ! empty( $input['show_social_in_hero'] ) ? 1 : 0;
        $clean['profile_sidebar']    = ! empty( $input['profile_sidebar'] )    ? 1 : 0;
        $clean['custom_css']         = wp_strip_all_tags( $input['custom_css'] ?? '' );
        return $clean;
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $settings = get_option( 'prepsnext_settings', [] );
        ?>
        <div class="wrap pn-settings-wrap">
            <h1>⚙️ <?php _e('PrepsNext Athlete Profiles Settings','prepsnext'); ?></h1>

            <?php settings_errors(); ?>

            <form method="POST" action="options.php">
                <?php settings_fields('prepsnext_settings_group'); ?>

                <div class="pn-settings-card">
                    <h2><?php _e('🎨 Appearance','prepsnext'); ?></h2>
                    <div class="pn-settings-row">
                        <label><?php _e('Accent Color (Default: Lime)','prepsnext'); ?></label>
                        <input type="text" name="prepsnext_settings[accent_color]"
                               value="<?php echo esc_attr($settings['accent_color'] ?? '#AAFF00'); ?>"
                               class="pn-color-picker">
                    </div>
                    <div class="pn-settings-row">
                        <label><?php _e('Background Color','prepsnext'); ?></label>
                        <input type="text" name="prepsnext_settings[dark_bg]"
                               value="<?php echo esc_attr($settings['dark_bg'] ?? '#111111'); ?>"
                               class="pn-color-picker">
                    </div>
                    <div class="pn-settings-row">
                        <label><?php _e('Custom CSS','prepsnext'); ?></label>
                        <textarea name="prepsnext_settings[custom_css]" rows="6" cols="60"
                                  placeholder="/* Add custom CSS here */"><?php echo esc_textarea($settings['custom_css'] ?? ''); ?></textarea>
                    </div>
                </div>

                <div class="pn-settings-card">
                    <h2><?php _e('⚙️ Features','prepsnext'); ?></h2>
                    <div class="pn-settings-row">
                        <label><?php _e('Default Sport','prepsnext'); ?></label>
                        <select name="prepsnext_settings[default_sport]">
                            <option value="basketball" <?php selected($settings['default_sport']??'basketball','basketball'); ?>><?php _e('Basketball','prepsnext'); ?></option>
                            <option value="football"   <?php selected($settings['default_sport']??'','football'); ?>><?php _e('Football','prepsnext'); ?></option>
                        </select>
                    </div>
                    <div class="pn-settings-row">
                        <label><?php _e('Archive Athletes Per Page','prepsnext'); ?></label>
                        <input type="number" name="prepsnext_settings[archive_per_page]"
                               value="<?php echo esc_attr($settings['archive_per_page'] ?? 24); ?>"
                               min="6" max="100" step="6" style="width:80px;">
                    </div>
                    <div class="pn-settings-row">
                        <label>
                            <input type="checkbox" name="prepsnext_settings[show_contact_form]" value="1"
                                   <?php checked($settings['show_contact_form']??1, 1); ?>>
                            <?php _e('Show Contact Button on Profiles','prepsnext'); ?>
                        </label>
                    </div>
                    <div class="pn-settings-row">
                        <label>
                            <input type="checkbox" name="prepsnext_settings[enable_athlete_reg]" value="1"
                                   <?php checked($settings['enable_athlete_reg']??1, 1); ?>>
                            <?php _e('Enable Athlete Self-Registration','prepsnext'); ?>
                        </label>
                    </div>
                    <div class="pn-settings-row">
                        <label>
                            <input type="checkbox" name="prepsnext_settings[profile_sidebar]" value="1"
                                   <?php checked($settings['profile_sidebar']??1, 1); ?>>
                            <?php _e('Show Sidebar on Profile Pages','prepsnext'); ?>
                        </label>
                    </div>
                </div>

                <div class="pn-settings-card">
                    <h2><?php _e('📬 Contact','prepsnext'); ?></h2>
                    <div class="pn-settings-row">
                        <label><?php _e('Contact Email','prepsnext'); ?></label>
                        <input type="email" name="prepsnext_settings[contact_email]"
                               value="<?php echo esc_attr($settings['contact_email'] ?? get_option('admin_email')); ?>"
                               placeholder="contact@prepsnextmag.com" style="width:300px;">
                    </div>
                </div>

                <div class="pn-settings-card">
                    <h2><?php _e('🔗 Quick Links','prepsnext'); ?></h2>
                    <p>
                        <a href="<?php echo esc_url(get_post_type_archive_link('pn_athlete')); ?>" class="button" target="_blank">
                            <?php _e('View Athlete Archive','prepsnext'); ?> ↗
                        </a>
                        &nbsp;
                        <a href="<?php echo esc_url(admin_url('post-new.php?post_type=pn_athlete')); ?>" class="button button-primary">
                            + <?php _e('Add New Athlete','prepsnext'); ?>
                        </a>
                        &nbsp;
                        <a href="<?php echo esc_url(admin_url('admin.php?page=prepsnext-rankings')); ?>" class="button">
                            <?php _e('Rankings Manager','prepsnext'); ?>
                        </a>
                    </p>
                </div>

                <?php submit_button( __('Save Settings','prepsnext') ); ?>
            </form>
        </div>
        <?php

        // Output custom CSS
        $custom_css = $settings['custom_css'] ?? '';
        if ( $custom_css ) {
            add_action( 'wp_head', function() use ($custom_css) {
                echo '<style id="prepsnext-custom-css">' . wp_strip_all_tags($custom_css) . '</style>';
            });
        }
    }

    public function render_rankings_page() {
        global $wpdb;
        $athletes = get_posts([
            'post_type'      => 'pn_athlete',
            'numberposts'    => -1,
            'post_status'    => 'publish',
            'orderby'        => 'meta_value_num',
            'meta_key'       => '_pn_national_rank',
            'order'          => 'ASC',
        ]);
        ?>
        <div class="wrap">
            <h1>🏆 <?php _e('Rankings Manager','prepsnext'); ?></h1>
            <p class="description"><?php _e('Overview of all ranked athletes. Edit individual profiles to update rankings.','prepsnext'); ?></p>

            <?php
            // Group by sport
            $by_sport = [];
            foreach($athletes as $a) {
                $terms = get_the_terms($a->ID,'pn_sport');
                $sport = ($terms && !is_wp_error($terms)) ? $terms[0]->name : 'Other';
                $by_sport[$sport][] = $a;
            }
            foreach($by_sport as $sport_name => $sport_athletes):
            ?>
            <h2><?php echo esc_html($sport_name === 'Basketball' ? '🏀 ' : '🏈 '); echo esc_html($sport_name); ?></h2>
            <table class="wp-list-table widefat fixed striped" style="margin-bottom:30px;">
                <thead>
                    <tr>
                        <th width="60"><?php _e('Nat. Rank','prepsnext'); ?></th>
                        <th width="60"><?php _e('State Rank','prepsnext'); ?></th>
                        <th><?php _e('Athlete','prepsnext'); ?></th>
                        <th><?php _e('School','prepsnext'); ?></th>
                        <th><?php _e('Position','prepsnext'); ?></th>
                        <th><?php _e('Class','prepsnext'); ?></th>
                        <th><?php _e('Status','prepsnext'); ?></th>
                        <th width="80"><?php _e('Edit','prepsnext'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($sport_athletes as $a):
                        $nat  = get_post_meta($a->ID,'_pn_national_rank',true);
                        $st   = get_post_meta($a->ID,'_pn_state_rank',true);
                        $first= get_post_meta($a->ID,'_pn_first_name',true);
                        $last = get_post_meta($a->ID,'_pn_last_name',true);
                        $name = trim("$first $last") ?: $a->post_title;
                        $sch  = get_post_meta($a->ID,'_pn_school_name',true);
                        $pos  = get_post_meta($a->ID,'_pn_positions',true);
                        $cls_terms = get_the_terms($a->ID,'pn_class_year');
                        $cls  = ($cls_terms && !is_wp_error($cls_terms)) ? $cls_terms[0]->name : '';
                        $status = get_post_meta($a->ID,'_pn_prospect_status',true);
                    ?>
                    <tr>
                        <td><strong><?php echo $nat ? '#'.esc_html($nat) : '—'; ?></strong></td>
                        <td><?php echo $st ? '#'.esc_html($st) : '—'; ?></td>
                        <td><a href="<?php echo get_edit_post_link($a->ID); ?>"><?php echo esc_html($name); ?></a></td>
                        <td><?php echo esc_html($sch ?: '—'); ?></td>
                        <td><?php echo esc_html($pos ?: '—'); ?></td>
                        <td><?php echo esc_html($cls ?: '—'); ?></td>
                        <td><?php
                            $labels = ['top_prospect'=>'⭐ Top Prospect','stock_riser'=>'📈 Stock Riser',
                                       'committed'=>'✅ Committed','signed'=>'📝 Signed','featured'=>'🔥 Featured'];
                            echo isset($labels[$status]) ? esc_html($labels[$status]) : esc_html($status ?: '—');
                        ?></td>
                        <td><a href="<?php echo get_edit_post_link($a->ID); ?>" class="button button-small">Edit</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endforeach; ?>

            <?php if(empty($athletes)): ?>
            <div class="notice notice-info"><p><?php _e('No ranked athletes yet. Edit athlete profiles to add rankings.','prepsnext'); ?></p></div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_import_export_page() {

        // ── Import result notices ──────────────────────────────────────────
        $import_status   = sanitize_text_field( $_GET['pn_import']   ?? '' );
        $import_count    = absint( $_GET['pn_imported'] ?? 0 );
        $import_skipped  = absint( $_GET['pn_skipped']  ?? 0 );

        ?>
        <div class="wrap">
            <h1>📥 <?php _e('Import / Export','prepsnext'); ?></h1>

            <?php if ( $import_status === 'done' ): ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        ✅ <strong><?php printf( __('Import complete! %d athlete(s) imported.','prepsnext'), $import_count ); ?></strong>
                        <?php if ( $import_skipped ): printf( __(' %d row(s) skipped (missing name or parse error).','prepsnext'), $import_skipped ); endif; ?>
                        &nbsp;<a href="<?php echo esc_url(admin_url('edit.php?post_type=pn_athlete')); ?>"><?php _e('View Athletes →','prepsnext'); ?></a>
                    </p>
                </div>
            <?php elseif ( $import_status === 'no_file' ): ?>
                <div class="notice notice-error is-dismissible"><p><?php _e('No file was uploaded. Please choose a CSV file and try again.','prepsnext'); ?></p></div>
            <?php elseif ( $import_status === 'bad_file' ): ?>
                <div class="notice notice-error is-dismissible"><p><?php _e('Could not read the uploaded file. Please check the file and try again.','prepsnext'); ?></p></div>
            <?php elseif ( $import_status === 'empty' ): ?>
                <div class="notice notice-error is-dismissible"><p><?php _e('The CSV file appears to be empty or has no header row.','prepsnext'); ?></p></div>
            <?php endif; ?>

            <div class="pn-settings-card">
                <h2><?php _e('Export Athlete Profiles','prepsnext'); ?></h2>
                <p><?php _e('Export all athlete data as CSV for backup or analysis.','prepsnext'); ?></p>
                <a href="<?php echo esc_url(admin_url('admin-post.php?action=pn_export_athletes&nonce='.wp_create_nonce('pn_export'))); ?>"
                   class="button button-primary">
                    <?php _e('📥 Export Athletes CSV','prepsnext'); ?>
                </a>
            </div>

            <div class="pn-settings-card">
                <h2><?php _e('📤 Import Athlete Profiles','prepsnext'); ?></h2>
                <p><?php _e('Import athletes from a CSV file using the PrepsNext import template.','prepsnext'); ?></p>

                <h3 style="margin-top:12px;"><?php _e('Required CSV columns (header row):','prepsnext'); ?></h3>
                <p style="font-family:monospace;font-size:12px;background:#f6f7f7;padding:10px;border-radius:4px;line-height:1.8;word-break:break-all;">
                    first_name, last_name, sport, class_year, state, city,
                    school_name, school_location, team_name, positions, jersey_number,
                    conference, division, height, weight, prospect_status,
                    national_rank, state_rank, committed_to, bio,
                    gpa, sat_score, act_score, intended_major, ncaa_eligible,
                    college_offers, college_interests,
                    stat_ppg, stat_rpg, stat_apg, stat_spg, stat_bpg, stat_fg_pct, stat_three_pct, stat_ft_pct,
                    stat_pass_yards, stat_pass_tds, stat_rush_yards, stat_rush_tds,
                    stat_rec_yards, stat_rec_tds, stat_tackles, stat_sacks, stat_ints,
                    social_instagram, social_twitter, social_hudl
                </p>
                <p class="description"><?php _e('Columns are matched by name (case-insensitive). Extra columns are ignored. <strong>college_offers</strong> and <strong>college_interests</strong> should be pipe-separated (e.g. <code>Florida|FSU|Miami</code>).','prepsnext'); ?></p>

                <form method="POST" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:16px;">
                    <?php wp_nonce_field('pn_import'); ?>
                    <input type="hidden" name="action" value="pn_import_athletes">
                    <p>
                        <label><strong><?php _e('Choose CSV file:','prepsnext'); ?></strong></label><br>
                        <input type="file" name="pn_import_file" accept=".csv" style="margin-top:6px;">
                    </p>
                    <p>
                        <input type="submit" class="button button-primary" value="<?php _e('⬆️ Import Athletes from CSV','prepsnext'); ?>">
                    </p>
                </form>
            </div>
        </div>
        <?php
    }

    public function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'prepsnext_overview',
            '🏆 PrepsNext Athletes Overview',
            [ $this, 'render_dashboard_widget' ]
        );
    }

    public function render_dashboard_widget() {
        $total     = wp_count_posts('pn_athlete')->publish;
        $bball     = count(get_posts(['post_type'=>'pn_athlete','numberposts'=>-1,'tax_query'=>[['taxonomy'=>'pn_sport','field'=>'slug','terms'=>'basketball']]]));
        $football  = count(get_posts(['post_type'=>'pn_athlete','numberposts'=>-1,'tax_query'=>[['taxonomy'=>'pn_sport','field'=>'slug','terms'=>'football']]]));
        $top_prospects = count(get_posts(['post_type'=>'pn_athlete','numberposts'=>-1,'meta_query'=>[['key'=>'_pn_prospect_status','value'=>'top_prospect']]]));
        ?>
        <div class="pn-dashboard-stats">
            <div class="pn-ds-item">
                <div class="pn-ds-num"><?php echo intval($total); ?></div>
                <div class="pn-ds-label">Total Athletes</div>
            </div>
            <div class="pn-ds-item">
                <div class="pn-ds-num"><?php echo intval($bball); ?></div>
                <div class="pn-ds-label">🏀 Basketball</div>
            </div>
            <div class="pn-ds-item">
                <div class="pn-ds-num"><?php echo intval($football); ?></div>
                <div class="pn-ds-label">🏈 Football</div>
            </div>
            <div class="pn-ds-item">
                <div class="pn-ds-num"><?php echo intval($top_prospects); ?></div>
                <div class="pn-ds-label">⭐ Top Prospects</div>
            </div>
        </div>
        <p>
            <a href="<?php echo esc_url(admin_url('edit.php?post_type=pn_athlete')); ?>" class="button">
                View All Athletes
            </a>
            <a href="<?php echo esc_url(admin_url('post-new.php?post_type=pn_athlete')); ?>" class="button button-primary" style="margin-left:8px;">
                + Add Athlete
            </a>
        </p>
        <?php
    }
}
