<?php
/**
 * Athlete User Registration & Profile Claim
 * Allows athletes to register and link their WP user account to a profile
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_User_Profile {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'show_user_profile',         [ $this, 'user_profile_fields' ] );
        add_action( 'edit_user_profile',         [ $this, 'user_profile_fields' ] );
        add_action( 'personal_options_update',   [ $this, 'save_user_profile_fields' ] );
        add_action( 'edit_user_profile_update',  [ $this, 'save_user_profile_fields' ] );
        add_action( 'user_register',             [ $this, 'on_user_register' ] );

        // Shortcode for athlete registration / profile claim form
        add_shortcode( 'prepsnext_register', [ $this, 'registration_shortcode' ] );
        add_shortcode( 'prepsnext_claim',    [ $this, 'claim_profile_shortcode' ] );

        // Handle form submissions
        add_action( 'init', [ $this, 'handle_form_submissions' ] );
    }

    /**
     * Add athlete profile fields to WP user admin
     */
    public function user_profile_fields( $user ) {
        $linked_profile = get_user_meta($user->ID,'_pn_linked_athlete_id',true);
        $role           = get_user_meta($user->ID,'_pn_athlete_sport',true);
        $verified       = get_user_meta($user->ID,'_pn_athlete_verified',true);
        ?>
        <h2><?php _e('PrepsNext Athlete Info','prepsnext'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="pn_linked_athlete_id"><?php _e('Linked Athlete Profile','prepsnext'); ?></label></th>
                <td>
                    <?php
                    $athletes = get_posts(['post_type'=>'pn_athlete','numberposts'=>-1,'post_status'=>'publish']);
                    ?>
                    <select name="pn_linked_athlete_id" id="pn_linked_athlete_id">
                        <option value=""><?php _e('— None —','prepsnext'); ?></option>
                        <?php foreach($athletes as $a):
                            $first = get_post_meta($a->ID,'_pn_first_name',true);
                            $last  = get_post_meta($a->ID,'_pn_last_name',true);
                            $name  = trim("$first $last") ?: $a->post_title;
                        ?>
                        <option value="<?php echo $a->ID; ?>" <?php selected($linked_profile,$a->ID); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($linked_profile): ?>
                    <a href="<?php echo get_edit_post_link($linked_profile); ?>" class="button button-small" style="margin-left:8px;">
                        <?php _e('Edit Profile','prepsnext'); ?>
                    </a>
                    <a href="<?php echo get_permalink($linked_profile); ?>" class="button button-small" target="_blank">
                        <?php _e('View Profile','prepsnext'); ?>
                    </a>
                    <?php endif; ?>
                    <p class="description"><?php _e('Link this WordPress user account to an athlete profile.','prepsnext'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="pn_athlete_sport"><?php _e('Primary Sport','prepsnext'); ?></label></th>
                <td>
                    <select name="pn_athlete_sport" id="pn_athlete_sport">
                        <option value=""><?php _e('— Select —','prepsnext'); ?></option>
                        <option value="basketball" <?php selected($role,'basketball'); ?>>🏀 Basketball</option>
                        <option value="football"   <?php selected($role,'football'); ?>>🏈 Football</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label><?php _e('Verified Athlete','prepsnext'); ?></label></th>
                <td>
                    <label>
                        <input type="checkbox" name="pn_athlete_verified" value="1" <?php checked($verified,'1'); ?>>
                        <?php _e('✅ Mark as Verified Athlete','prepsnext'); ?>
                    </label>
                    <p class="description"><?php _e('Shows a verified badge on the athlete profile.','prepsnext'); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    public function save_user_profile_fields( $user_id ) {
        if ( ! current_user_can('edit_user', $user_id) ) return;

        update_user_meta($user_id, '_pn_linked_athlete_id', absint($_POST['pn_linked_athlete_id'] ?? 0));
        update_user_meta($user_id, '_pn_athlete_sport',     sanitize_text_field($_POST['pn_athlete_sport'] ?? ''));
        update_user_meta($user_id, '_pn_athlete_verified',  isset($_POST['pn_athlete_verified']) ? '1' : '');
    }

    public function on_user_register( $user_id ) {
        // Set default role for athlete registrations
        $settings = get_option('prepsnext_settings', []);
        if (!empty($settings['enable_athlete_reg'])) {
            // New registrations get Subscriber role by default - admin promotes them
        }
    }

    /**
     * [prepsnext_register] shortcode
     * Athlete sign-up form
     */
    public function registration_shortcode( $atts ) {
        if ( is_user_logged_in() ) {
            return '<p>' . sprintf(
                __('You are already logged in. <a href="%s">View your account</a>.','prepsnext'),
                esc_url(admin_url())
            ) . '</p>';
        }

        $settings = get_option('prepsnext_settings', []);
        if (empty($settings['enable_athlete_reg'])) {
            return '<p>' . __('Athlete registration is currently disabled.','prepsnext') . '</p>';
        }

        $error   = get_transient('pn_reg_error_'.session_id());
        $success = get_transient('pn_reg_success_'.session_id());
        delete_transient('pn_reg_error_'.session_id());
        delete_transient('pn_reg_success_'.session_id());

        ob_start();
        ?>
        <div class="pn-register-form pn-profile-wrapper">
            <div class="pn-form-card">
                <h2 class="pn-form-title">🏆 Create Your Athlete Account</h2>
                <p class="pn-form-subtitle">Join PrepsNext and build your recruiting profile</p>

                <?php if($error): ?>
                <div class="pn-alert pn-alert-error"><?php echo esc_html($error); ?></div>
                <?php endif; ?>

                <?php if($success): ?>
                <div class="pn-alert pn-alert-success"><?php echo esc_html($success); ?></div>
                <?php else: ?>

                <form method="POST" class="pn-form">
                    <?php wp_nonce_field('pn_register','pn_register_nonce'); ?>
                    <input type="hidden" name="pn_action" value="register">

                    <div class="pn-form-row pn-form-half">
                        <div class="pn-form-field">
                            <label><?php _e('First Name *','prepsnext'); ?></label>
                            <input type="text" name="pn_first_name" required>
                        </div>
                        <div class="pn-form-field">
                            <label><?php _e('Last Name *','prepsnext'); ?></label>
                            <input type="text" name="pn_last_name" required>
                        </div>
                    </div>

                    <div class="pn-form-field">
                        <label><?php _e('Email Address *','prepsnext'); ?></label>
                        <input type="email" name="pn_email" required>
                    </div>

                    <div class="pn-form-field">
                        <label><?php _e('Password *','prepsnext'); ?></label>
                        <input type="password" name="pn_password" required minlength="8">
                    </div>

                    <div class="pn-form-field">
                        <label><?php _e('Primary Sport *','prepsnext'); ?></label>
                        <select name="pn_sport" required>
                            <option value="">Select Sport</option>
                            <option value="basketball">🏀 Basketball</option>
                            <option value="football">🏈 Football</option>
                        </select>
                    </div>

                    <div class="pn-form-row pn-form-half">
                        <div class="pn-form-field">
                            <label><?php _e('City','prepsnext'); ?></label>
                            <input type="text" name="pn_city" placeholder="Orlando">
                        </div>
                        <div class="pn-form-field">
                            <label><?php _e('State','prepsnext'); ?></label>
                            <input type="text" name="pn_state" placeholder="FL">
                        </div>
                    </div>

                    <div class="pn-form-field pn-form-agree">
                        <label>
                            <input type="checkbox" name="pn_agree" value="1" required>
                            <?php _e('I agree to the Terms of Service and Privacy Policy','prepsnext'); ?>
                        </label>
                    </div>

                    <button type="submit" class="pn-btn pn-btn-primary pn-btn-full">
                        🚀 Create My Account
                    </button>

                    <p class="pn-form-login-link">
                        Already have an account? <a href="<?php echo esc_url(wp_login_url()); ?>">Sign In</a>
                    </p>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * [prepsnext_claim] shortcode
     * Allow logged-in users to claim their profile
     */
    public function claim_profile_shortcode( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<p>' . sprintf(
                __('<a href="%s">Log in</a> to claim your athlete profile.','prepsnext'),
                esc_url(wp_login_url(get_permalink()))
            ) . '</p>';
        }

        $user_id        = get_current_user_id();
        $linked_profile = get_user_meta($user_id,'_pn_linked_athlete_id',true);
        $error   = get_transient('pn_claim_error_'.$user_id);
        $success = get_transient('pn_claim_success_'.$user_id);
        delete_transient('pn_claim_error_'.$user_id);
        delete_transient('pn_claim_success_'.$user_id);

        ob_start();
        ?>
        <div class="pn-claim-form pn-profile-wrapper">
            <div class="pn-form-card">
                <?php if($linked_profile): ?>
                <div class="pn-alert pn-alert-success">
                    ✅ Your account is linked to a profile.
                    <a href="<?php echo get_permalink($linked_profile); ?>">View Your Profile →</a>
                </div>
                <?php else: ?>
                <h2 class="pn-form-title">🔗 Claim Your Athlete Profile</h2>
                <p class="pn-form-subtitle">Search for your existing profile or request a new one</p>

                <?php if($error): ?><div class="pn-alert pn-alert-error"><?php echo esc_html($error); ?></div><?php endif; ?>
                <?php if($success): ?><div class="pn-alert pn-alert-success"><?php echo esc_html($success); ?></div><?php endif; ?>

                <form method="POST" class="pn-form">
                    <?php wp_nonce_field('pn_claim','pn_claim_nonce'); ?>
                    <input type="hidden" name="pn_action" value="claim">

                    <div class="pn-form-field">
                        <label>Find Your Profile</label>
                        <?php
                        $athletes = get_posts(['post_type'=>'pn_athlete','numberposts'=>-1,'post_status'=>'publish']);
                        ?>
                        <select name="pn_athlete_profile_id" required>
                            <option value="">— Search your name —</option>
                            <?php foreach($athletes as $a):
                                $first = get_post_meta($a->ID,'_pn_first_name',true);
                                $last  = get_post_meta($a->ID,'_pn_last_name',true);
                                $name  = trim("$first $last") ?: $a->post_title;
                                $school = get_post_meta($a->ID,'_pn_school_name',true);
                            ?>
                            <option value="<?php echo $a->ID; ?>"><?php echo esc_html("$name".($school?" – $school":'')); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pn-form-field">
                        <label>Verification (School Email or Note)</label>
                        <input type="text" name="pn_claim_note" placeholder="Enter your school email to verify identity">
                    </div>

                    <button type="submit" class="pn-btn pn-btn-primary pn-btn-full">Submit Claim Request</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Handle form submissions
     */
    public function handle_form_submissions() {
        if ( empty($_POST['pn_action']) ) return;

        $action = $_POST['pn_action'];

        if ( $action === 'register' ) {
            $this->handle_registration();
        } elseif ( $action === 'claim' ) {
            $this->handle_claim();
        }
    }

    private function handle_registration() {
        if ( ! wp_verify_nonce($_POST['pn_register_nonce']??'','pn_register') ) return;

        $first    = sanitize_text_field($_POST['pn_first_name'] ?? '');
        $last     = sanitize_text_field($_POST['pn_last_name']  ?? '');
        $email    = sanitize_email($_POST['pn_email']           ?? '');
        $password = $_POST['pn_password']                       ?? '';
        $sport    = sanitize_text_field($_POST['pn_sport']      ?? '');
        $city     = sanitize_text_field($_POST['pn_city']       ?? '');
        $state    = sanitize_text_field($_POST['pn_state']      ?? '');
        $sid      = session_id();

        if ( !$first || !$last || !$email || !$password ) {
            set_transient('pn_reg_error_'.$sid,'Please fill in all required fields.',300);
            return;
        }

        if ( email_exists($email) ) {
            set_transient('pn_reg_error_'.$sid,'This email is already registered.',300);
            return;
        }

        $username = sanitize_user( strtolower($first.'.'.$last) );
        if ( username_exists($username) ) {
            $username .= rand(10,99);
        }

        $user_id = wp_create_user($username, $password, $email);

        if ( is_wp_error($user_id) ) {
            set_transient('pn_reg_error_'.$sid,$user_id->get_error_message(),300);
            return;
        }

        // Save basic info
        wp_update_user(['ID'=>$user_id,'first_name'=>$first,'last_name'=>$last,'display_name'=>"$first $last"]);
        update_user_meta($user_id,'_pn_athlete_sport', $sport);
        update_user_meta($user_id,'_pn_reg_city',  $city);
        update_user_meta($user_id,'_pn_reg_state', $state);

        // Notify admin
        $admin_email = get_option('admin_email');
        wp_mail($admin_email,
            "New Athlete Registration: $first $last",
            "New athlete account registered:\n\nName: $first $last\nEmail: $email\nSport: $sport\nCity: $city, $state\n\nLog in to review: " . admin_url('users.php')
        );

        set_transient('pn_reg_success_'.$sid,"Welcome $first! Your account has been created. An admin will review and link your profile shortly.",300);
    }

    private function handle_claim() {
        if ( ! is_user_logged_in() ) return;
        if ( ! wp_verify_nonce($_POST['pn_claim_nonce']??'','pn_claim') ) return;

        $user_id    = get_current_user_id();
        $profile_id = absint($_POST['pn_athlete_profile_id'] ?? 0);
        $note       = sanitize_text_field($_POST['pn_claim_note'] ?? '');

        if (!$profile_id) {
            set_transient('pn_claim_error_'.$user_id,'Please select a profile.',300);
            return;
        }

        // Save pending claim for admin to approve
        update_user_meta($user_id,'_pn_claim_pending_profile',$profile_id);
        update_user_meta($user_id,'_pn_claim_note',$note);

        $admin_email = get_option('admin_email');
        $user = get_userdata($user_id);
        $profile = get_post($profile_id);
        wp_mail($admin_email,
            "Athlete Profile Claim: " . $user->display_name,
            "User {$user->display_name} ({$user->user_email}) has requested to claim profile:\n\n{$profile->post_title}\n\nNote: $note\n\nApprove at: " . admin_url('user-edit.php?user_id='.$user_id)
        );

        set_transient('pn_claim_success_'.$user_id,"Your claim request has been submitted! An admin will review and approve it shortly.",300);
    }
}
