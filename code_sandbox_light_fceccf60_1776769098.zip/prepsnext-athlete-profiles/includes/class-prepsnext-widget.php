<?php
/**
 * PrepsNext — New Athletes Sidebar Widget
 *
 * Displays a vertical list of the most recently published athlete profiles,
 * showing each athlete's mugshot/headshot, full name, and sport.
 *
 * Usage: Appearance → Widgets → drag "New Athletes" into any sidebar.
 *
 * Widget options:
 *   - Title         : Custom widget heading (default: "New Athletes")
 *   - Number to show: How many athletes to display (1–20, default: 5)
 *   - Sport filter  : Optionally limit to Basketball, Football, or All Sports
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_New_Athletes_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'prepsnext_new_athletes',            // Base ID
            __( 'New Athletes', 'prepsnext' ),    // Name shown in the widget admin
            [
                'description' => __( 'Displays the most recently added athlete profiles with mugshot, name, and sport.', 'prepsnext' ),
                'classname'   => 'pn-new-athletes-widget',
            ]
        );
    }

    // ── Front-end display ─────────────────────────────────────────────────────

    public function widget( $args, $instance ) {
        $title  = ! empty( $instance['title'] )  ? apply_filters( 'widget_title', $instance['title'] ) : __( 'New Athletes', 'prepsnext' );
        $number = isset( $instance['number'] )    ? absint( $instance['number'] ) : 5;
        $sport  = ! empty( $instance['sport'] )   ? sanitize_text_field( $instance['sport'] ) : '';

        if ( $number < 1 )  $number = 1;
        if ( $number > 20 ) $number = 20;

        // Query the most recently published athletes
        $query_args = [
            'post_type'      => 'pn_athlete',
            'numberposts'    => $number,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'tax_query'      => [],
        ];

        if ( $sport ) {
            $query_args['tax_query'][] = [
                'taxonomy' => 'pn_sport',
                'field'    => 'slug',
                'terms'    => $sport,
            ];
        }

        $athletes = get_posts( $query_args );

        if ( empty( $athletes ) ) return;

        // ── Wrapper open (provided by the active theme)
        echo wp_kses_post( $args['before_widget'] );

        if ( $title ) {
            echo wp_kses_post( $args['before_title'] . $title . $args['after_title'] );
        }

        echo '<ul class="pn-naw-list">';

        foreach ( $athletes as $athlete ) {
            $pid = $athlete->ID;

            // Name
            $first = get_post_meta( $pid, '_pn_first_name', true );
            $last  = get_post_meta( $pid, '_pn_last_name',  true );
            $name  = trim( "$first $last" );
            if ( ! $name ) $name = get_the_title( $pid );

            // Mugshot — prefer headshot meta, fall back to action photo, then post thumbnail
            $headshot_id = get_post_meta( $pid, '_pn_headshot_id', true );
            $action_id   = get_post_meta( $pid, '_pn_action_image_id', true );

            if ( $headshot_id ) {
                $thumb_url = wp_get_attachment_image_url( $headshot_id, 'thumbnail' );
            } elseif ( $action_id ) {
                $thumb_url = wp_get_attachment_image_url( $action_id, 'thumbnail' );
            } else {
                $thumb_url = get_the_post_thumbnail_url( $pid, 'thumbnail' );
            }

            // Sport
            $sport_terms = get_the_terms( $pid, 'pn_sport' );
            $sport_name  = ( $sport_terms && ! is_wp_error( $sport_terms ) ) ? $sport_terms[0]->name : '';
            $sport_slug  = ( $sport_terms && ! is_wp_error( $sport_terms ) ) ? $sport_terms[0]->slug : '';
            $sport_icon  = ( strtolower( $sport_slug ) === 'football' ) ? '🏈' : '🏀';

            $permalink = get_permalink( $pid );

            ?>
            <li class="pn-naw-item">
                <a href="<?php echo esc_url( $permalink ); ?>" class="pn-naw-link" aria-label="<?php echo esc_attr( $name ); ?>">

                    <span class="pn-naw-mugshot">
                        <?php if ( $thumb_url ) : ?>
                            <img src="<?php echo esc_url( $thumb_url ); ?>"
                                 alt="<?php echo esc_attr( $name ); ?>"
                                 class="pn-naw-photo"
                                 loading="lazy"
                                 width="52" height="52">
                        <?php else : ?>
                            <span class="pn-naw-photo-placeholder" aria-hidden="true">
                                <?php echo ( strtolower( $sport_slug ) === 'football' ) ? '🏈' : '🏀'; ?>
                            </span>
                        <?php endif; ?>
                    </span>

                    <span class="pn-naw-details">
                        <span class="pn-naw-name"><?php echo esc_html( $name ); ?></span>
                        <?php if ( $sport_name ) : ?>
                            <span class="pn-naw-sport">
                                <span aria-hidden="true"><?php echo $sport_icon; ?></span>
                                <?php echo esc_html( $sport_name ); ?>
                            </span>
                        <?php endif; ?>
                    </span>

                    <span class="pn-naw-arrow" aria-hidden="true">›</span>

                </a>
            </li>
            <?php
        }

        echo '</ul>';

        // Link to the full athlete archive
        $archive_url = get_post_type_archive_link( 'pn_athlete' );
        if ( $archive_url ) {
            echo '<p class="pn-naw-footer"><a href="' . esc_url( $archive_url ) . '" class="pn-naw-view-all">'
               . esc_html__( 'View All Athletes →', 'prepsnext' )
               . '</a></p>';
        }

        echo wp_kses_post( $args['after_widget'] );
    }

    // ── Back-end widget form (admin) ──────────────────────────────────────────

    public function form( $instance ) {
        $title  = isset( $instance['title'] )  ? $instance['title']          : __( 'New Athletes', 'prepsnext' );
        $number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
        $sport  = isset( $instance['sport'] )  ? $instance['sport']           : '';
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
                <?php esc_html_e( 'Title:', 'prepsnext' ); ?>
            </label>
            <input class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
                   type="text"
                   value="<?php echo esc_attr( $title ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>">
                <?php esc_html_e( 'Number of athletes to show:', 'prepsnext' ); ?>
            </label>
            <input class="tiny-text"
                   id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>"
                   type="number"
                   step="1" min="1" max="20"
                   value="<?php echo esc_attr( $number ); ?>"
                   size="3">
            <span class="description">(1–20)</span>
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'sport' ) ); ?>">
                <?php esc_html_e( 'Filter by sport:', 'prepsnext' ); ?>
            </label>
            <select class="widefat"
                    id="<?php echo esc_attr( $this->get_field_id( 'sport' ) ); ?>"
                    name="<?php echo esc_attr( $this->get_field_name( 'sport' ) ); ?>">
                <option value="" <?php selected( $sport, '' ); ?>><?php esc_html_e( 'All Sports', 'prepsnext' ); ?></option>
                <option value="basketball" <?php selected( $sport, 'basketball' ); ?>><?php esc_html_e( '🏀 Basketball', 'prepsnext' ); ?></option>
                <option value="football"   <?php selected( $sport, 'football' );   ?>><?php esc_html_e( '🏈 Football', 'prepsnext' ); ?></option>
            </select>
        </p>
        <?php
    }

    // ── Sanitize / save widget settings ──────────────────────────────────────

    public function update( $new_instance, $old_instance ) {
        $instance           = $old_instance;
        $instance['title']  = sanitize_text_field( $new_instance['title'] );
        $instance['number'] = min( 20, max( 1, absint( $new_instance['number'] ) ) );
        $instance['sport']  = in_array( $new_instance['sport'], [ '', 'basketball', 'football' ], true )
                              ? $new_instance['sport']
                              : '';
        return $instance;
    }
}

/**
 * Register the widget with WordPress.
 * Called from prepsnext_boot() via the widgets_init hook.
 */
function prepsnext_register_new_athletes_widget() {
    register_widget( 'PrepsNext_New_Athletes_Widget' );
}
add_action( 'widgets_init', 'prepsnext_register_new_athletes_widget' );
