<?php
/**
 * PrepsNext Threads — Core Engine
 *
 * Handles: posting, editing, deleting threads; comments; likes; reposts;
 * follows; notifications; image upload & auto-crop; user approval gating.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Threads {

    /* Image constraints */
    const IMG_MAX_BYTES  = 5242880;   // 5 MB
    const IMG_WIDTH      = 1080;
    const IMG_HEIGHT     = 1080;
    const ALLOWED_MIME   = [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ];

    private static $instance = null;
    public static function instance() {
        if ( is_null( self::$instance ) ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Register pages after WP is fully loaded to ensure get_page_by_path() works reliably
        add_action( 'wp_loaded',          [ $this, 'register_pages' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        // Redirect logged-in users away from auth pages before any output
        add_action( 'template_redirect',  [ $this, 'maybe_redirect_logged_in' ] );
        add_shortcode( 'prepsnext_feed',            [ $this, 'sc_feed' ] );
        add_shortcode( 'prepsnext_thread_login',    [ $this, 'sc_login' ] );
        add_shortcode( 'prepsnext_thread_register', [ $this, 'sc_register' ] );
        add_shortcode( 'prepsnext_nav_buttons',     [ $this, 'sc_nav_buttons' ] );
        add_shortcode( 'prepsnext_ticker',          [ $this, 'sc_ticker' ] );
    }

    /* ══════════════════════════════════════════════════════════════
       PAGE REGISTRATION
       ══════════════════════════════════════════════════════════════ */

    public function register_pages() {
        // Only auto-create pages in a normal (non-AJAX, non-cron, non-REST) request
        if ( wp_doing_ajax() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) return;

        // Use a transient so we only check DB once per hour, not on every page load
        if ( get_transient( 'pn_threads_pages_created' ) ) return;

        $pages = [
            'prepsnext-feed'     => [ 'title' => 'PrepsNext Feed',     'shortcode' => '[prepsnext_feed]' ],
            'prepsnext-login'    => [ 'title' => 'Athlete Login',       'shortcode' => '[prepsnext_thread_login]' ],
            'prepsnext-register' => [ 'title' => 'Athlete Sign Up',     'shortcode' => '[prepsnext_thread_register]' ],
        ];

        $all_exist = true;
        foreach ( $pages as $slug => $data ) {
            if ( ! get_page_by_path( $slug ) ) {
                $all_exist = false;
                wp_insert_post([
                    'post_title'   => $data['title'],
                    'post_name'    => $slug,
                    'post_content' => $data['shortcode'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ]);
            }
        }

        // Cache for 1 hour to avoid repeated DB lookups
        set_transient( 'pn_threads_pages_created', 1, HOUR_IN_SECONDS );
    }

    /**
     * Redirect already-logged-in users away from auth pages.
     * Must be on template_redirect (before any output) to avoid
     * "headers already sent" errors.
     */
    public function maybe_redirect_logged_in() {
        if ( ! is_user_logged_in() ) return;
        global $post;
        if ( ! $post ) return;
        if ( has_shortcode( $post->post_content, 'prepsnext_thread_login' ) ||
             has_shortcode( $post->post_content, 'prepsnext_thread_register' ) ) {
            wp_safe_redirect( home_url( '/prepsnext-feed/' ) );
            exit;
        }
    }

    /* ══════════════════════════════════════════════════════════════
       ASSET ENQUEUE
       ══════════════════════════════════════════════════════════════ */

    public function enqueue_assets() {
        $post = get_post();
        $load = $post && (
            has_shortcode( $post->post_content, 'prepsnext_feed' ) ||
            has_shortcode( $post->post_content, 'prepsnext_thread_login' ) ||
            has_shortcode( $post->post_content, 'prepsnext_thread_register' ) ||
            get_query_var('pn_thread_id') ||
            get_query_var('pn_profile_uid')
        );
        if ( ! $load ) return;

        wp_enqueue_style( 'prepsnext-fonts',
            'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800;900&family=Barlow:wght@400;500;600;700&display=swap',
            [], null );
        wp_enqueue_style( 'prepsnext-threads',
            PREPSNEXT_URL . 'assets/css/threads.css', [], PREPSNEXT_VERSION );
        wp_enqueue_script( 'prepsnext-threads',
            PREPSNEXT_URL . 'assets/js/threads.js',
            [ 'jquery' ], PREPSNEXT_VERSION, true );
        wp_localize_script( 'prepsnext-threads', 'pnThreads', [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'pn_threads_nonce' ),
            'userId'     => get_current_user_id(),
            'isApproved' => self::current_user_approved() ? 1 : 0,
            'feedUrl'    => home_url( '/prepsnext-feed/' ),
            'loginUrl'   => home_url( '/prepsnext-login/' ),
            'registerUrl'=> home_url( '/prepsnext-register/' ),
            'imgMax'     => self::IMG_MAX_BYTES,
            'imgW'       => self::IMG_WIDTH,
            'imgH'       => self::IMG_HEIGHT,
            'strings'    => [
                'confirmDelete'  => __( 'Delete this thread?', 'prepsnext' ),
                'posting'        => __( 'Posting…', 'prepsnext' ),
                'imgTooLarge'    => __( 'Image exceeds 5 MB limit.', 'prepsnext' ),
                'imgBadType'     => __( 'Only JPG, PNG, GIF, or WebP allowed.', 'prepsnext' ),
                'loginRequired'  => __( 'You must be logged in to interact.', 'prepsnext' ),
                'pendingApproval'=> __( 'Your account is pending admin approval.', 'prepsnext' ),
            ],
        ] );
    }

    /* ══════════════════════════════════════════════════════════════
       SHORTCODE — NAV BUTTONS  [prepsnext_nav_buttons]
       ══════════════════════════════════════════════════════════════ */

    public function sc_nav_buttons( $atts ) {
        $atts = shortcode_atts( [
            'layout' => 'row',   // row | stack
            'size'   => 'md',    // sm | md | lg
        ], $atts, 'prepsnext_nav_buttons' );

        $logged_in   = is_user_logged_in();
        $feed_url    = esc_url( home_url( '/prepsnext-feed/' ) );
        $login_url   = esc_url( home_url( '/prepsnext-login/' ) );
        $reg_url     = esc_url( home_url( '/prepsnext-register/' ) );

        // Size map
        $sizes = [
            'sm' => [ 'pad' => '7px 14px',  'font' => '12px', 'radius' => '20px', 'icon' => 14 ],
            'md' => [ 'pad' => '10px 20px', 'font' => '14px', 'radius' => '24px', 'icon' => 16 ],
            'lg' => [ 'pad' => '13px 28px', 'font' => '16px', 'radius' => '28px', 'icon' => 18 ],
        ];
        $s = $sizes[ $atts['size'] ] ?? $sizes['md'];
        $is_stack = ( $atts['layout'] === 'stack' );

        ob_start();
        ?>
        <div class="pn-nb-wrap pn-nb-<?php echo esc_attr( $atts['layout'] ); ?>">

            <!-- Feed -->
            <a href="<?php echo $feed_url; ?>" class="pn-nb-btn pn-nb-feed">
                <svg width="<?php echo $s['icon']; ?>" height="<?php echo $s['icon']; ?>" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                <span>Feed</span>
                <span class="pn-nb-live-dot"></span>
            </a>

            <?php if ( ! $logged_in ) : ?>

            <!-- Log In -->
            <a href="<?php echo $login_url; ?>" class="pn-nb-btn pn-nb-login">
                <svg width="<?php echo $s['icon']; ?>" height="<?php echo $s['icon']; ?>" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                <span>Log In</span>
            </a>

            <!-- Sign Up -->
            <a href="<?php echo $reg_url; ?>" class="pn-nb-btn pn-nb-signup">
                <svg width="<?php echo $s['icon']; ?>" height="<?php echo $s['icon']; ?>" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
                <span>Sign Up Free</span>
            </a>

            <?php else : ?>

            <!-- Logged in: show profile link -->
            <?php
            $me = self::get_user_display( get_current_user_id() );
            $profile_url = esc_url( $me['profile_url'] ?: $feed_url );
            ?>
            <a href="<?php echo $profile_url; ?>" class="pn-nb-btn pn-nb-profile">
                <?php if ( $me['avatar'] ) : ?>
                <img src="<?php echo esc_url( $me['avatar'] ); ?>" class="pn-nb-avatar" alt="<?php echo esc_attr( $me['name'] ); ?>">
                <?php else : ?>
                <span class="pn-nb-avatar-placeholder"><?php echo esc_html( mb_strtoupper( mb_substr( $me['name'], 0, 1 ) ) ); ?></span>
                <?php endif; ?>
                <span><?php echo esc_html( $me['name'] ); ?></span>
            </a>

            <?php endif; ?>

        </div>

        <style>
        /* ── Nav Buttons Shortcode ── */
        .pn-nb-wrap {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
            font-family: 'Barlow', 'Helvetica Neue', Arial, sans-serif;
        }
        .pn-nb-stack {
            flex-direction: column;
            align-items: stretch;
        }
        .pn-nb-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: <?php echo $s['pad']; ?>;
            border-radius: <?php echo $s['radius']; ?>;
            font-size: <?php echo $s['font']; ?>;
            font-weight: 700;
            text-decoration: none !important;
            white-space: nowrap;
            border: 1.5px solid transparent;
            transition: all 0.18s ease;
            cursor: pointer;
            line-height: 1.2;
            letter-spacing: 0.02em;
        }
        .pn-nb-stack .pn-nb-btn {
            width: 100%;
        }
        /* Feed */
        .pn-nb-feed {
            background: rgba(170,255,0,0.10);
            border-color: rgba(170,255,0,0.35);
            color: #AAFF00 !important;
        }
        .pn-nb-feed:hover {
            background: rgba(170,255,0,0.20);
            border-color: #AAFF00;
            box-shadow: 0 0 14px rgba(170,255,0,0.30);
            transform: translateY(-1px);
        }
        /* Login */
        .pn-nb-login {
            background: transparent;
            border-color: rgba(255,255,255,0.25);
            color: rgba(255,255,255,0.85) !important;
        }
        .pn-nb-login:hover {
            background: rgba(255,255,255,0.08);
            border-color: rgba(255,255,255,0.55);
            color: #fff !important;
            transform: translateY(-1px);
        }
        /* Sign Up */
        .pn-nb-signup {
            background: #AAFF00;
            border-color: #AAFF00;
            color: #0a0a0a !important;
            font-weight: 800;
            box-shadow: 0 2px 12px rgba(170,255,0,0.35);
        }
        .pn-nb-signup:hover {
            background: #c4ff33;
            border-color: #c4ff33;
            box-shadow: 0 4px 20px rgba(170,255,0,0.55);
            transform: translateY(-2px);
            color: #0a0a0a !important;
        }
        .pn-nb-signup:active { transform: translateY(0); }
        /* Profile (logged in) */
        .pn-nb-profile {
            background: rgba(255,255,255,0.06);
            border-color: rgba(255,255,255,0.15);
            color: #f0f0f0 !important;
        }
        .pn-nb-profile:hover {
            background: rgba(255,255,255,0.12);
            border-color: rgba(170,255,0,0.40);
            color: #AAFF00 !important;
        }
        /* Live dot */
        .pn-nb-live-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #AAFF00;
            flex-shrink: 0;
            animation: pn-nb-pulse 2s ease-in-out infinite;
        }
        @keyframes pn-nb-pulse {
            0%   { box-shadow: 0 0 0 0   rgba(170,255,0,0.7); }
            70%  { box-shadow: 0 0 0 7px rgba(170,255,0,0);   }
            100% { box-shadow: 0 0 0 0   rgba(170,255,0,0);   }
        }
        /* Avatar */
        .pn-nb-avatar {
            width: 22px; height: 22px;
            border-radius: 50%;
            object-fit: cover;
            border: 1.5px solid rgba(170,255,0,0.4);
        }
        .pn-nb-avatar-placeholder {
            width: 22px; height: 22px;
            border-radius: 50%;
            background: rgba(170,255,0,0.15);
            border: 1.5px solid rgba(170,255,0,0.4);
            display: flex; align-items: center; justify-content: center;
            font-size: 11px; font-weight: 800; color: #AAFF00;
        }
        /* Mobile full-width stacking */
        @media (max-width: 480px) {
            .pn-nb-wrap {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }
            .pn-nb-btn {
                width: 100%;
                justify-content: center;
                padding: 12px 20px;
                font-size: 15px;
                border-radius: 14px;
            }
        }
        </style>
        <?php
        return ob_get_clean();
    }

    /* ══════════════════════════════════════════════════════════════
       SHORTCODE — TICKER  [prepsnext_ticker]
       ══════════════════════════════════════════════════════════════ */

    public function sc_ticker( $atts ) {
        $atts = shortcode_atts( [
            'limit'    => 8,
            'interval' => 5000,
        ], $atts, 'prepsnext_ticker' );

        $limit    = min( absint( $atts['limit'] ), 20 );
        $interval = absint( $atts['interval'] );
        $feed_url = esc_url( home_url( '/prepsnext-feed/' ) );

        // Pre-fetch slides server-side so there's no blank flash on load
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_threads
             WHERE status = 'published' AND repost_of IS NULL
             ORDER BY created_at DESC LIMIT %d",
            $limit
        ) );

        $slides_data = [];
        if ( $rows ) {
            foreach ( $rows as $t ) {
                $user  = self::get_user_display( $t->user_id );
                $body  = trim( preg_replace( '/\s+/', ' ', strip_tags( $t->body ) ) );
                $slides_data[] = [
                    'name'        => $user['name'],
                    'avatar'      => $user['avatar'],
                    'status'      => $user['status'],
                    'profile_url' => $user['profile_url'],
                    'body'        => $body,
                    'link'        => home_url( '/prepsnext-feed/?thread=' . $t->id ),
                ];
            }
        }

        $badge_map = [
            'top_prospect' => '⭐', 'featured'    => '🔥',
            'stock_riser'  => '📈', 'committed'   => '✅',
            'signed'       => '📝', 'under_radar' => '🕵️',
        ];

        ob_start();
        ?>
        <div class="pn-ticker-sc" id="pn-ticker-sc" role="region" aria-label="Recent athlete posts">

            <!-- Brand pill -->
            <a href="<?php echo $feed_url; ?>" class="pn-ticker-sc__brand">
                <span>🏆</span>
                <span class="pn-ticker-sc__live-label">LIVE</span>
                <span class="pn-ticker-sc__live-dot"></span>
            </a>

            <div class="pn-ticker-sc__divider"></div>

            <!-- Slide window -->
            <div class="pn-ticker-sc__window">
                <div class="pn-ticker-sc__track" id="pn-ticker-sc-track">

                    <?php if ( empty( $slides_data ) ) : ?>
                    <div class="pn-ticker-sc__slide pn-ticker-sc__slide--active">
                        <a href="<?php echo $feed_url; ?>" class="pn-ticker-sc__text" style="font-style:italic;color:rgba(255,255,255,0.4)">
                            🏆 Be the first athlete to post on PrepsNext!
                        </a>
                    </div>
                    <?php else : ?>
                    <?php foreach ( $slides_data as $i => $slide ) :
                        $body_short = mb_strlen( $slide['body'] ) > 55 ? mb_substr( $slide['body'], 0, 55 ) . '…' : $slide['body'];
                        $badge      = isset( $badge_map[ $slide['status'] ] ) ? $badge_map[ $slide['status'] ] : '';
                    ?>
                    <div class="pn-ticker-sc__slide<?php echo $i === 0 ? ' pn-ticker-sc__slide--active' : ''; ?>">
                        <?php if ( $slide['avatar'] ) : ?>
                        <img src="<?php echo esc_url( $slide['avatar'] ); ?>" class="pn-ticker-sc__avatar" alt="" loading="lazy">
                        <?php else : ?>
                        <span class="pn-ticker-sc__avatar-ph"><?php echo esc_html( mb_strtoupper( mb_substr( $slide['name'], 0, 1 ) ) ); ?></span>
                        <?php endif; ?>
                        <a href="<?php echo esc_url( $slide['profile_url'] ?: $feed_url ); ?>" class="pn-ticker-sc__name"><?php echo esc_html( $slide['name'] ); ?></a>
                        <?php if ( $badge ) : ?><span class="pn-ticker-sc__badge"><?php echo $badge; ?></span><?php endif; ?>
                        <span class="pn-ticker-sc__sep">·</span>
                        <a href="<?php echo esc_url( $slide['link'] ); ?>" class="pn-ticker-sc__text"><?php echo esc_html( $body_short ); ?></a>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>

                </div>
            </div>

            <!-- Arrows -->
            <?php if ( count( $slides_data ) > 1 ) : ?>
            <div class="pn-ticker-sc__nav">
                <button class="pn-ticker-sc__arrow" id="pn-ticker-sc-prev" aria-label="Previous">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <button class="pn-ticker-sc__arrow" id="pn-ticker-sc-next" aria-label="Next">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="9 6 15 12 9 18"/></svg>
                </button>
            </div>
            <?php endif; ?>

            <!-- Dots -->
            <?php if ( count( $slides_data ) > 1 ) : ?>
            <div class="pn-ticker-sc__dots" id="pn-ticker-sc-dots">
                <?php foreach ( $slides_data as $i => $slide ) : ?>
                <button class="pn-ticker-sc__dot<?php echo $i === 0 ? ' pn-ticker-sc__dot--active' : ''; ?>" data-index="<?php echo $i; ?>" aria-label="Post <?php echo $i + 1; ?>"></button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

        </div>

        <style>
        /* ── Ticker Shortcode ──────────────────────────────── */
        .pn-ticker-sc {
            display: flex;
            align-items: center;
            gap: 0;
            height: 40px;
            background: rgba(14,14,14,0.96);
            border: 1px solid rgba(170,255,0,0.20);
            border-radius: 26px;
            padding: 0 6px;
            font-family: 'Barlow', 'Helvetica Neue', Arial, sans-serif;
            font-size: 13px;
            overflow: hidden;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.5), 0 0 0 1px rgba(170,255,0,0.05);
            backdrop-filter: blur(10px);
        }
        /* Brand pill */
        .pn-ticker-sc__brand {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px 3px 5px;
            background: rgba(170,255,0,0.10);
            border: 1px solid rgba(170,255,0,0.25);
            border-radius: 20px;
            text-decoration: none !important;
            flex-shrink: 0;
            font-size: 12px;
            transition: background 0.18s;
        }
        .pn-ticker-sc__brand:hover { background: rgba(170,255,0,0.20); }
        .pn-ticker-sc__live-label {
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.08em;
            color: #AAFF00;
            text-transform: uppercase;
        }
        .pn-ticker-sc__live-dot {
            width: 6px; height: 6px;
            border-radius: 50%;
            background: #AAFF00;
            animation: pn-sc-pulse 2s ease-in-out infinite;
        }
        @keyframes pn-sc-pulse {
            0%,100% { opacity:1; transform:scale(1);    }
            50%      { opacity:.4; transform:scale(.7); }
        }
        /* Divider */
        .pn-ticker-sc__divider {
            width: 1px; height: 20px;
            background: rgba(255,255,255,0.10);
            flex-shrink: 0;
            margin: 0 8px;
        }
        /* Window */
        .pn-ticker-sc__window {
            flex: 1;
            overflow: hidden;
            height: 100%;
            display: flex;
            align-items: center;
            min-width: 0;
            position: relative;
        }
        .pn-ticker-sc__track {
            width: 100%;
            height: 100%;
            position: relative;
            display: flex;
            align-items: center;
        }
        /* Slides */
        .pn-ticker-sc__slide {
            display: none;
            align-items: center;
            gap: 6px;
            width: 100%;
            white-space: nowrap;
            overflow: hidden;
            opacity: 0;
            transition: opacity 0.32s ease;
        }
        .pn-ticker-sc__slide--active {
            display: flex;
            opacity: 1;
        }
        /* Avatar */
        .pn-ticker-sc__avatar {
            width: 22px; height: 22px;
            border-radius: 50%;
            object-fit: cover;
            border: 1.5px solid rgba(170,255,0,0.35);
            flex-shrink: 0;
        }
        .pn-ticker-sc__avatar-ph {
            width: 22px; height: 22px;
            border-radius: 50%;
            background: rgba(170,255,0,0.15);
            border: 1.5px solid rgba(170,255,0,0.35);
            display: inline-flex;
            align-items: center; justify-content: center;
            font-size: 10px; font-weight: 800;
            color: #AAFF00;
            flex-shrink: 0;
        }
        /* Name */
        .pn-ticker-sc__name {
            font-weight: 700;
            font-size: 12px;
            color: #AAFF00 !important;
            text-decoration: none !important;
            flex-shrink: 0;
            max-width: 75px;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .pn-ticker-sc__name:hover { text-decoration: underline !important; }
        /* Badge */
        .pn-ticker-sc__badge { font-size: 11px; flex-shrink: 0; }
        /* Sep */
        .pn-ticker-sc__sep { color: rgba(255,255,255,0.22); font-size: 10px; flex-shrink: 0; }
        /* Text */
        .pn-ticker-sc__text {
            color: rgba(240,240,240,0.75) !important;
            font-size: 12px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            flex: 1;
            min-width: 0;
            text-decoration: none !important;
        }
        .pn-ticker-sc__text:hover { color: #fff !important; }
        /* Nav */
        .pn-ticker-sc__nav {
            display: flex;
            gap: 1px;
            flex-shrink: 0;
            margin-left: 4px;
        }
        .pn-ticker-sc__arrow {
            width: 22px; height: 22px;
            border-radius: 50%;
            background: transparent;
            border: none;
            display: flex;
            align-items: center; justify-content: center;
            color: rgba(255,255,255,0.35);
            cursor: pointer;
            transition: background 0.15s, color 0.15s;
            padding: 0;
            flex-shrink: 0;
        }
        .pn-ticker-sc__arrow:hover { background: rgba(255,255,255,0.08); color: #AAFF00; }
        /* Dots */
        .pn-ticker-sc__dots {
            display: flex;
            gap: 3px;
            flex-shrink: 0;
            padding: 0 6px 0 4px;
        }
        .pn-ticker-sc__dot {
            width: 4px; height: 4px;
            border-radius: 50%;
            background: rgba(255,255,255,0.18);
            border: none;
            cursor: pointer;
            padding: 0;
            transition: background 0.2s, transform 0.2s;
        }
        .pn-ticker-sc__dot--active {
            background: #AAFF00;
            transform: scale(1.35);
        }
        /* Mobile — full width, taller touch targets */
        @media (max-width: 600px) {
            .pn-ticker-sc {
                max-width: 100%;
                height: 44px;
                border-radius: 14px;
            }
        }
        </style>

        <script>
        (function () {
            var INTERVAL = <?php echo $interval; ?>;
            var track    = document.getElementById('pn-ticker-sc-track');
            var dotsWrap = document.getElementById('pn-ticker-sc-dots');
            var prevBtn  = document.getElementById('pn-ticker-sc-prev');
            var nextBtn  = document.getElementById('pn-ticker-sc-next');
            if (!track) return;

            var slides  = track.querySelectorAll('.pn-ticker-sc__slide');
            var current = 0;
            var timer   = null;
            var paused  = false;

            if (slides.length <= 1) return; // nothing to cycle

            function goTo(index) {
                slides[current].classList.remove('pn-ticker-sc__slide--active');
                slides[current].style.display = 'none';
                current = (index + slides.length) % slides.length;
                slides[current].style.display = 'flex';
                slides[current].style.opacity = '0';
                slides[current].classList.add('pn-ticker-sc__slide--active');
                void slides[current].offsetWidth;
                slides[current].style.opacity = '1';
                // dots
                if (dotsWrap) {
                    dotsWrap.querySelectorAll('.pn-ticker-sc__dot').forEach(function(d,i){
                        d.classList.toggle('pn-ticker-sc__dot--active', i === current);
                    });
                }
            }
            function startTimer() {
                clearInterval(timer);
                timer = setInterval(function(){ if(!paused) goTo(current+1); }, INTERVAL);
            }
            // arrows
            if (prevBtn) prevBtn.addEventListener('click', function(){ goTo(current-1); clearInterval(timer); startTimer(); });
            if (nextBtn) nextBtn.addEventListener('click', function(){ goTo(current+1); clearInterval(timer); startTimer(); });
            // dots
            if (dotsWrap) {
                dotsWrap.querySelectorAll('.pn-ticker-sc__dot').forEach(function(d){
                    d.addEventListener('click', function(){ goTo(parseInt(this.dataset.index)); clearInterval(timer); startTimer(); });
                });
            }
            // pause on hover
            var wrap = document.getElementById('pn-ticker-sc');
            if (wrap) {
                wrap.addEventListener('mouseenter', function(){ paused = true;  });
                wrap.addEventListener('mouseleave', function(){ paused = false; });
                // keyboard
                wrap.setAttribute('tabindex','0');
                wrap.addEventListener('keydown', function(e){
                    if(e.key==='ArrowLeft')  { goTo(current-1); clearInterval(timer); startTimer(); }
                    if(e.key==='ArrowRight') { goTo(current+1); clearInterval(timer); startTimer(); }
                });
            }
            startTimer();
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /* ══════════════════════════════════════════════════════════════
       USER HELPERS
       ══════════════════════════════════════════════════════════════ */

    public static function current_user_approved() {
        if ( ! is_user_logged_in() ) return false;
        $uid = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) return true;
        return (bool) get_user_meta( $uid, 'pn_athlete_approved', true );
    }

    public static function get_athlete_post_for_user( $user_id ) {
        $posts = get_posts([
            'post_type'   => 'pn_athlete',
            'numberposts' => 1,
            'meta_query'  => [[ 'key' => '_pn_linked_user_id', 'value' => $user_id ]],
        ]);
        return $posts[0] ?? null;
    }

    public static function get_user_display( $user_id ) {
        $athlete = self::get_athlete_post_for_user( $user_id );
        if ( $athlete ) {
            $pid   = $athlete->ID;
            $first = get_post_meta( $pid, '_pn_first_name', true );
            $last  = get_post_meta( $pid, '_pn_last_name',  true );
            $name  = trim( "$first $last" ) ?: $athlete->post_title;
            $headshot_id  = get_post_meta( $pid, '_pn_headshot_id', true );
            $action_img_id = get_post_meta( $pid, '_pn_action_image_id', true );
            if ( $headshot_id ) {
                $avatar = wp_get_attachment_image_url( $headshot_id, 'thumbnail' );
            } elseif ( $action_img_id ) {
                $avatar = wp_get_attachment_image_url( $action_img_id, 'thumbnail' );
            } else {
                $avatar = '';
            }
            $sport_terms   = get_the_terms( $pid, 'pn_sport' );
            $sport         = ( $sport_terms && ! is_wp_error( $sport_terms ) ) ? $sport_terms[0]->name : '';
            $status        = get_post_meta( $pid, '_pn_prospect_status', true );
            $nat_rank      = get_post_meta( $pid, '_pn_national_rank', true );
            $profile_url   = get_permalink( $pid );
            $athlete_id    = $pid;
        } else {
            $user       = get_userdata( $user_id );
            $name       = $user ? $user->display_name : 'Unknown';
            $avatar     = get_avatar_url( $user_id, [ 'size' => 96 ] );
            $sport      = '';
            $status     = '';
            $nat_rank   = '';
            $profile_url= '';
            $athlete_id = 0;
        }
        return compact( 'name', 'avatar', 'sport', 'status', 'nat_rank', 'profile_url', 'athlete_id' );
    }

    public static function badge_html( $status, $nat_rank = '' ) {
        $badges = [
            'top_prospect' => [ 'label' => 'Top Prospect', 'class' => 'pnt-badge--gold',      'icon' => '⭐' ],
            'featured'     => [ 'label' => 'Featured',     'class' => 'pnt-badge--featured',   'icon' => '🔥' ],
            'stock_riser'  => [ 'label' => 'Rising',       'class' => 'pnt-badge--riser',      'icon' => '📈' ],
            'committed'    => [ 'label' => 'Committed',    'class' => 'pnt-badge--committed',  'icon' => '✅' ],
            'signed'       => [ 'label' => 'Signed',       'class' => 'pnt-badge--signed',     'icon' => '📝' ],
            'under_radar'  => [ 'label' => 'Under Radar',  'class' => 'pnt-badge--radar',      'icon' => '🕵️' ],
        ];
        if ( ! isset( $badges[ $status ] ) ) return '';
        $b = $badges[ $status ];
        return '<span class="pnt-badge ' . esc_attr( $b['class'] ) . '" title="' . esc_attr( $b['label'] ) . '">'
             . $b['icon'] . ' <span>' . esc_html( $b['label'] ) . '</span></span>';
    }

    /* ══════════════════════════════════════════════════════════════
       THREAD CRUD
       ══════════════════════════════════════════════════════════════ */

    public static function create_thread( $user_id, $body, $media_url = '', $media_type = 'none', $media_w = null, $media_h = null, $repost_of = null, $quote_body = '', $sport_tag = '' ) {
        global $wpdb;
        $athlete = self::get_athlete_post_for_user( $user_id );
        $athlete_id = $athlete ? $athlete->ID : 0;

        $wpdb->insert( $wpdb->prefix . 'pn_threads', [
            'user_id'    => $user_id,
            'athlete_id' => $athlete_id,
            'body'       => wp_kses_post( $body ),
            'media_url'  => $media_url ?: null,
            'media_type' => $media_type,
            'media_width'=> $media_w,
            'media_height'=> $media_h,
            'repost_of'  => $repost_of ?: null,
            'quote_body' => $quote_body ? wp_kses_post( $quote_body ) : null,
            'sport_tag'  => $sport_tag ? sanitize_text_field( $sport_tag ) : null,
            'status'     => 'published',
        ]);
        $thread_id = (int) $wpdb->insert_id;

        // If this is a repost, bump original repost_count
        if ( $repost_of ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}pn_threads SET repost_count = repost_count + 1 WHERE id = %d", $repost_of
            ));
            self::create_notification( self::get_thread_owner( $repost_of ), $user_id, 'repost', $repost_of, 'thread' );
        }

        return $thread_id;
    }

    public static function delete_thread( $thread_id, $user_id ) {
        global $wpdb;
        $thread = self::get_thread( $thread_id );
        if ( ! $thread ) return false;
        if ( (int) $thread->user_id !== (int) $user_id && ! current_user_can( 'manage_options' ) ) return false;
        $wpdb->update( $wpdb->prefix . 'pn_threads', [ 'status' => 'deleted' ], [ 'id' => $thread_id ] );
        return true;
    }

    public static function get_thread( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_threads WHERE id = %d", $id
        ));
    }

    public static function get_feed( $page = 1, $per_page = 20, $filter = 'all', $sport = '' ) {
        global $wpdb;
        $offset = ( $page - 1 ) * $per_page;
        $where  = "WHERE t.status = 'published'";
        if ( $sport ) $where .= $wpdb->prepare( " AND t.sport_tag = %s", $sport );

        if ( $filter === 'following' && is_user_logged_in() ) {
            $uid = get_current_user_id();
            $where .= " AND t.user_id IN (
                SELECT following_id FROM {$wpdb->prefix}pn_thread_follows WHERE follower_id = $uid
                UNION SELECT $uid
            )";
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT t.* FROM {$wpdb->prefix}pn_threads t $where ORDER BY t.created_at DESC LIMIT %d OFFSET %d",
            $per_page, $offset
        ));
    }

    public static function get_user_threads( $user_id, $page = 1, $per_page = 20, $include_reposts = false ) {
        global $wpdb;
        $offset    = ( $page - 1 ) * $per_page;
        $repost_clause = $include_reposts ? '' : "AND repost_of IS NULL";
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_threads WHERE user_id = %d AND status = 'published' $repost_clause ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $user_id, $per_page, $offset
        ));
    }

    public static function get_thread_owner( $thread_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}pn_threads WHERE id = %d", $thread_id
        ));
    }

    /* ══════════════════════════════════════════════════════════════
       COMMENTS
       ══════════════════════════════════════════════════════════════ */

    public static function create_comment( $thread_id, $user_id, $body, $parent_id = null, $media_url = '' ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'pn_thread_comments', [
            'thread_id' => $thread_id,
            'user_id'   => $user_id,
            'parent_id' => $parent_id ?: null,
            'body'      => wp_kses_post( $body ),
            'media_url' => $media_url ?: null,
        ]);
        $comment_id = (int) $wpdb->insert_id;

        // Bump comment counter on parent thread
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}pn_threads SET comment_count = comment_count + 1 WHERE id = %d", $thread_id
        ));

        // Notify thread owner
        $owner = self::get_thread_owner( $thread_id );
        if ( $owner !== $user_id ) {
            self::create_notification( $owner, $user_id, 'comment', $comment_id, 'comment' );
        }

        // If reply to another comment, notify that commenter too
        if ( $parent_id ) {
            $parent_owner = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT user_id FROM {$wpdb->prefix}pn_thread_comments WHERE id = %d", $parent_id
            ));
            if ( $parent_owner && $parent_owner !== $user_id ) {
                self::create_notification( $parent_owner, $user_id, 'comment', $comment_id, 'comment' );
            }
        }

        return $comment_id;
    }

    public static function get_comments( $thread_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_thread_comments WHERE thread_id = %d AND status = 'published' ORDER BY created_at ASC",
            $thread_id
        ));
    }

    public static function delete_comment( $comment_id, $user_id ) {
        global $wpdb;
        $c = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_thread_comments WHERE id = %d", $comment_id
        ));
        if ( ! $c ) return false;
        if ( (int) $c->user_id !== (int) $user_id && ! current_user_can( 'manage_options' ) ) return false;
        $wpdb->update( $wpdb->prefix . 'pn_thread_comments', [ 'status' => 'deleted' ], [ 'id' => $comment_id ] );
        // Decrement thread comment count
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}pn_threads SET comment_count = GREATEST(comment_count - 1, 0) WHERE id = %d", $c->thread_id
        ));
        return true;
    }

    /* ══════════════════════════════════════════════════════════════
       LIKES
       ══════════════════════════════════════════════════════════════ */

    public static function toggle_like( $user_id, $item_id, $item_type = 'thread' ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pn_thread_likes';
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE user_id=%d AND item_id=%d AND item_type=%s",
            $user_id, $item_id, $item_type
        ));

        if ( $exists ) {
            // Unlike
            $wpdb->delete( $table, [ 'user_id' => $user_id, 'item_id' => $item_id, 'item_type' => $item_type ] );
            $delta = -1;
            $liked = false;
        } else {
            // Like
            $wpdb->insert( $table, [ 'user_id' => $user_id, 'item_id' => $item_id, 'item_type' => $item_type ] );
            $delta = 1;
            $liked = true;

            // Notify owner
            if ( $item_type === 'thread' ) {
                $owner = self::get_thread_owner( $item_id );
                if ( $owner !== $user_id ) self::create_notification( $owner, $user_id, 'like', $item_id, 'thread' );
            }
        }

        // Update denormalised counter
        if ( $item_type === 'thread' ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}pn_threads SET like_count = GREATEST(like_count + %d, 0) WHERE id = %d",
                $delta, $item_id
            ));
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT like_count FROM {$wpdb->prefix}pn_threads WHERE id = %d", $item_id
            ));
        } else {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}pn_thread_comments SET like_count = GREATEST(like_count + %d, 0) WHERE id = %d",
                $delta, $item_id
            ));
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT like_count FROM {$wpdb->prefix}pn_thread_comments WHERE id = %d", $item_id
            ));
        }
        return [ 'liked' => $liked, 'count' => $count ];
    }

    public static function user_liked( $user_id, $item_id, $item_type = 'thread' ) {
        global $wpdb;
        return (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pn_thread_likes WHERE user_id=%d AND item_id=%d AND item_type=%s",
            $user_id, $item_id, $item_type
        ));
    }

    public static function user_reposted( $user_id, $thread_id ) {
        global $wpdb;
        return (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pn_thread_reposts WHERE user_id=%d AND thread_id=%d",
            $user_id, $thread_id
        ));
    }

    /* ══════════════════════════════════════════════════════════════
       FOLLOWS
       ══════════════════════════════════════════════════════════════ */

    public static function toggle_follow( $follower_id, $following_id ) {
        global $wpdb;
        $table  = $wpdb->prefix . 'pn_thread_follows';
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE follower_id=%d AND following_id=%d", $follower_id, $following_id
        ));
        if ( $exists ) {
            $wpdb->delete( $table, [ 'follower_id' => $follower_id, 'following_id' => $following_id ] );
            return false; // unfollowed
        } else {
            $wpdb->insert( $table, [ 'follower_id' => $follower_id, 'following_id' => $following_id ] );
            self::create_notification( $following_id, $follower_id, 'follow', 0, 'thread' );
            return true; // followed
        }
    }

    public static function is_following( $follower_id, $following_id ) {
        global $wpdb;
        return (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pn_thread_follows WHERE follower_id=%d AND following_id=%d",
            $follower_id, $following_id
        ));
    }

    public static function get_follower_count( $user_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pn_thread_follows WHERE following_id=%d", $user_id
        ));
    }

    public static function get_following_count( $user_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pn_thread_follows WHERE follower_id=%d", $user_id
        ));
    }

    /* ══════════════════════════════════════════════════════════════
       NOTIFICATIONS
       ══════════════════════════════════════════════════════════════ */

    public static function create_notification( $user_id, $actor_id, $type, $item_id, $item_type ) {
        if ( ! $user_id || $user_id === $actor_id ) return;
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'pn_notifications', compact( 'user_id','actor_id','type','item_id','item_type' ) );
    }

    public static function get_notifications( $user_id, $limit = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_notifications WHERE user_id=%d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ));
    }

    public static function unread_notification_count( $user_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pn_notifications WHERE user_id=%d AND is_read=0", $user_id
        ));
    }

    public static function mark_notifications_read( $user_id ) {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'pn_notifications', [ 'is_read' => 1 ], [ 'user_id' => $user_id ] );
    }

    /* ══════════════════════════════════════════════════════════════
       IMAGE UPLOAD & AUTO-CROP
       ══════════════════════════════════════════════════════════════ */

    public static function handle_image_upload( $file_array ) {
        if ( empty( $file_array['tmp_name'] ) ) return new WP_Error( 'no_file', 'No file uploaded.' );
        if ( $file_array['size'] > self::IMG_MAX_BYTES )
            return new WP_Error( 'too_large', 'Image exceeds 5 MB.' );
        if ( ! in_array( $file_array['type'], self::ALLOWED_MIME, true ) )
            return new WP_Error( 'bad_type', 'Invalid image type.' );

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Move to uploads
        $overrides = [ 'test_form' => false ];
        $moved     = wp_handle_upload( $file_array, $overrides );
        if ( isset( $moved['error'] ) ) return new WP_Error( 'upload_error', $moved['error'] );

        // Auto-crop to IMG_WIDTH x IMG_HEIGHT (square centre crop)
        $editor = wp_get_image_editor( $moved['file'] );
        if ( ! is_wp_error( $editor ) ) {
            $editor->resize( self::IMG_WIDTH, self::IMG_HEIGHT, true );
            $editor->save( $moved['file'] );
        }

        // Insert into media library
        $attachment_id = wp_insert_attachment([
            'post_mime_type' => $moved['type'],
            'post_title'     => sanitize_file_name( basename( $moved['file'] ) ),
            'post_status'    => 'inherit',
        ], $moved['file'] );

        wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $moved['file'] ) );

        return [
            'attachment_id' => $attachment_id,
            'url'           => $moved['url'],
            'width'         => self::IMG_WIDTH,
            'height'        => self::IMG_HEIGHT,
        ];
    }

    /* ══════════════════════════════════════════════════════════════
       SHORTCODE RENDERERS
       ══════════════════════════════════════════════════════════════ */

    public function sc_feed( $atts ) {
        ob_start();
        include PREPSNEXT_DIR . 'templates/threads-feed.php';
        return ob_get_clean();
    }

    public function sc_login( $atts ) {
        // Redirect handled by maybe_redirect_logged_in() on template_redirect hook.
        // We still show a link here as a fallback in case shortcode is embedded in unusual contexts.
        if ( is_user_logged_in() ) {
            return '<p>' . wp_kses_post( sprintf(
                /* translators: %s: feed URL */
                __( 'You are already logged in. <a href="%s">Go to the feed →</a>', 'prepsnext' ),
                esc_url( home_url( '/prepsnext-feed/' ) )
            ) ) . '</p>';
        }
        ob_start();
        include PREPSNEXT_DIR . 'templates/threads-login.php';
        return ob_get_clean();
    }

    public function sc_register( $atts ) {
        // Redirect handled by maybe_redirect_logged_in() on template_redirect hook.
        if ( is_user_logged_in() ) {
            return '<p>' . wp_kses_post( sprintf(
                __( 'You are already registered and logged in. <a href="%s">Go to the feed →</a>', 'prepsnext' ),
                esc_url( home_url( '/prepsnext-feed/' ) )
            ) ) . '</p>';
        }
        ob_start();
        include PREPSNEXT_DIR . 'templates/threads-register.php';
        return ob_get_clean();
    }

    /* ══════════════════════════════════════════════════════════════
       RENDER HELPERS  (used by templates & AJAX)
       ══════════════════════════════════════════════════════════════ */

    public static function render_thread_card( $thread, $current_uid = 0, $is_detail = false ) {
        $user  = self::get_user_display( $thread->user_id );
        $liked = $current_uid ? self::user_liked( $current_uid, $thread->id, 'thread' ) : false;
        $reposted = $current_uid ? self::user_reposted( $current_uid, $thread->id ) : false;
        $is_owner = ( $current_uid && (int) $thread->user_id === $current_uid );
        $time  = self::time_ago( $thread->created_at );
        $approved = self::current_user_approved();

        // Check if this is a repost
        $original = null;
        if ( $thread->repost_of ) {
            $original = self::get_thread( $thread->repost_of );
        }

        $sport_icons = [ 'basketball' => '🏀', 'football' => '🏈' ];
        $sport_slug  = strtolower( $user['sport'] );
        $sport_icon  = $sport_icons[ $sport_slug ] ?? '🏆';
        ?>
        <article class="pnt-thread-card<?php echo $is_detail ? ' pnt-thread-card--detail' : ''; ?>" data-thread-id="<?php echo esc_attr( $thread->id ); ?>">

            <?php if ( $thread->repost_of && $original ): ?>
            <div class="pnt-repost-label">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
                <?php echo esc_html( $user['name'] ); ?> reposted
            </div>
            <?php endif; ?>

            <div class="pnt-thread-inner">
                <div class="pnt-thread-left">
                    <?php if ( $user['profile_url'] && $user['avatar'] ): ?>
                    <a href="<?php echo esc_url( $user['profile_url'] ); ?>" class="pnt-avatar-link">
                        <img src="<?php echo esc_url( $user['avatar'] ); ?>" alt="<?php echo esc_attr( $user['name'] ); ?>" class="pnt-avatar">
                    </a>
                    <?php else: ?>
                    <div class="pnt-avatar pnt-avatar--placeholder"><?php echo esc_html( mb_strtoupper( mb_substr( $user['name'], 0, 1 ) ) ); ?></div>
                    <?php endif; ?>
                    <?php if ( ! $is_detail ): ?><div class="pnt-thread-line"></div><?php endif; ?>
                </div>

                <div class="pnt-thread-right">
                    <div class="pnt-thread-header">
                        <div class="pnt-author-info">
                            <a href="<?php echo esc_url( $user['profile_url'] ?: '#' ); ?>" class="pnt-author-name">
                                <?php echo esc_html( $user['name'] ); ?>
                            </a>
                            <?php echo self::badge_html( $user['status'], $user['nat_rank'] ); ?>
                            <?php if ( $user['sport'] ): ?>
                            <span class="pnt-sport-tag"><?php echo $sport_icon; ?> <?php echo esc_html( $user['sport'] ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="pnt-thread-meta">
                            <span class="pnt-time"><?php echo esc_html( $time ); ?></span>
                            <?php if ( $is_owner || current_user_can( 'manage_options' ) ): ?>
                            <button class="pnt-btn-icon pnt-delete-thread" data-id="<?php echo esc_attr( $thread->id ); ?>" title="Delete">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ( $thread->sport_tag ): ?>
                    <span class="pnt-hashtag"><?php echo esc_html( '#' . $thread->sport_tag ); ?></span>
                    <?php endif; ?>

                    <div class="pnt-thread-body"><?php echo nl2br( wp_kses_post( $thread->body ) ); ?></div>

                    <?php if ( $thread->media_url && $thread->media_type === 'image' ): ?>
                    <div class="pnt-thread-media">
                        <img src="<?php echo esc_url( $thread->media_url ); ?>" alt="" class="pnt-thread-img" loading="lazy">
                    </div>
                    <?php endif; ?>

                    <?php if ( $thread->repost_of && $original ):
                        $orig_user = self::get_user_display( $original->user_id ); ?>
                    <div class="pnt-quote-thread">
                        <div class="pnt-quote-header">
                            <?php if ( $orig_user['avatar'] ): ?><img src="<?php echo esc_url( $orig_user['avatar'] ); ?>" class="pnt-avatar pnt-avatar--xs" alt=""><?php endif; ?>
                            <a href="<?php echo esc_url( $orig_user['profile_url'] ?: '#' ); ?>" class="pnt-author-name pnt-author-name--sm"><?php echo esc_html( $orig_user['name'] ); ?></a>
                            <?php echo self::badge_html( $orig_user['status'] ); ?>
                            <span class="pnt-time pnt-time--sm"><?php echo esc_html( self::time_ago( $original->created_at ) ); ?></span>
                        </div>
                        <div class="pnt-quote-body"><?php echo nl2br( wp_kses_post( $original->body ) ); ?></div>
                        <?php if ( $original->media_url && $original->media_type === 'image' ): ?>
                        <img src="<?php echo esc_url( $original->media_url ); ?>" class="pnt-quote-img" alt="" loading="lazy">
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="pnt-thread-actions">
                        <?php /* Comment */ ?>
                        <button class="pnt-action-btn pnt-comment-btn<?php echo $approved ? '' : ' pnt-action--locked'; ?>" data-thread-id="<?php echo esc_attr( $thread->id ); ?>">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                            <span class="pnt-action-count"><?php echo (int) $thread->comment_count; ?></span>
                        </button>

                        <?php /* Like */ ?>
                        <button class="pnt-action-btn pnt-like-btn<?php echo $liked ? ' pnt-liked' : ''; ?><?php echo $approved ? '' : ' pnt-action--locked'; ?>" data-item-id="<?php echo esc_attr( $thread->id ); ?>" data-item-type="thread">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="<?php echo $liked ? 'var(--pnt-red)' : 'none'; ?>" stroke="<?php echo $liked ? 'var(--pnt-red)' : 'currentColor'; ?>" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                            <span class="pnt-action-count"><?php echo (int) $thread->like_count; ?></span>
                        </button>

                        <?php /* Repost */ ?>
                        <button class="pnt-action-btn pnt-repost-btn<?php echo $reposted ? ' pnt-reposted' : ''; ?><?php echo $approved ? '' : ' pnt-action--locked'; ?>" data-thread-id="<?php echo esc_attr( $thread->id ); ?>">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="<?php echo $reposted ? 'var(--pnt-accent)' : 'currentColor'; ?>" stroke-width="2"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
                            <span class="pnt-action-count"><?php echo (int) $thread->repost_count; ?></span>
                        </button>

                        <?php /* Share / Copy */ ?>
                        <button class="pnt-action-btn pnt-share-btn" data-thread-id="<?php echo esc_attr( $thread->id ); ?>">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                        </button>
                    </div>

                    <?php if ( $is_detail ):
                        self::render_comments_section( $thread->id, $current_uid );
                    endif; ?>
                </div>
            </div>
        </article>
        <?php
    }

    public static function render_comments_section( $thread_id, $current_uid = 0 ) {
        $comments = self::get_comments( $thread_id );
        $approved = self::current_user_approved();
        ?>
        <div class="pnt-comments-section" id="pnt-comments-<?php echo esc_attr( $thread_id ); ?>">
            <?php if ( $approved ): ?>
            <form class="pnt-comment-form" data-thread-id="<?php echo esc_attr( $thread_id ); ?>">
                <?php
                $me = $current_uid ? self::get_user_display( $current_uid ) : null;
                if ( $me && $me['avatar'] ): ?>
                <img src="<?php echo esc_url( $me['avatar'] ); ?>" class="pnt-avatar pnt-avatar--sm" alt="">
                <?php endif; ?>
                <div class="pnt-comment-input-wrap">
                    <textarea class="pnt-comment-input" placeholder="Reply to this thread…" rows="1" maxlength="500"></textarea>
                    <div class="pnt-comment-toolbar">
                        <label class="pnt-comment-img-label" title="Add image">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                            <input type="file" accept="image/jpeg,image/png,image/gif,image/webp" class="pnt-comment-img-input" style="display:none">
                        </label>
                        <button type="submit" class="pnt-btn pnt-btn--sm pnt-btn--accent">Reply</button>
                    </div>
                    <div class="pnt-comment-img-preview" style="display:none"></div>
                </div>
            </form>
            <?php elseif ( is_user_logged_in() ): ?>
            <p class="pnt-approval-notice">⏳ Your account is pending admin approval. You can read but not reply yet.</p>
            <?php else: ?>
            <p class="pnt-approval-notice"><a href="<?php echo esc_url( home_url('/prepsnext-login/') ); ?>">Log in</a> or <a href="<?php echo esc_url( home_url('/prepsnext-register/') ); ?>">sign up</a> to reply.</p>
            <?php endif; ?>

            <div class="pnt-comments-list">
                <?php foreach ( $comments as $c ):
                    $c_user = self::get_user_display( $c->user_id );
                    $c_liked = $current_uid ? self::user_liked( $current_uid, $c->id, 'comment' ) : false;
                    $c_is_owner = $current_uid && (int) $c->user_id === $current_uid;
                ?>
                <div class="pnt-comment<?php echo $c->parent_id ? ' pnt-comment--reply' : ''; ?>" data-comment-id="<?php echo esc_attr( $c->id ); ?>">
                    <?php if ( $c_user['avatar'] ): ?>
                    <a href="<?php echo esc_url( $c_user['profile_url'] ?: '#' ); ?>">
                        <img src="<?php echo esc_url( $c_user['avatar'] ); ?>" class="pnt-avatar pnt-avatar--sm" alt="">
                    </a>
                    <?php else: ?>
                    <div class="pnt-avatar pnt-avatar--sm pnt-avatar--placeholder"><?php echo esc_html( mb_strtoupper( mb_substr( $c_user['name'], 0, 1 ) ) ); ?></div>
                    <?php endif; ?>
                    <div class="pnt-comment-body-wrap">
                        <div class="pnt-comment-header">
                            <a href="<?php echo esc_url( $c_user['profile_url'] ?: '#' ); ?>" class="pnt-author-name pnt-author-name--sm">
                                <?php echo esc_html( $c_user['name'] ); ?>
                            </a>
                            <?php echo self::badge_html( $c_user['status'] ); ?>
                            <span class="pnt-time pnt-time--sm"><?php echo esc_html( self::time_ago( $c->created_at ) ); ?></span>
                            <?php if ( $c_is_owner || current_user_can('manage_options') ): ?>
                            <button class="pnt-btn-icon pnt-delete-comment" data-id="<?php echo esc_attr($c->id); ?>">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                            </button>
                            <?php endif; ?>
                        </div>
                        <div class="pnt-comment-text"><?php echo nl2br( wp_kses_post( $c->body ) ); ?></div>
                        <?php if ( $c->media_url ): ?>
                        <img src="<?php echo esc_url( $c->media_url ); ?>" class="pnt-comment-img" alt="" loading="lazy">
                        <?php endif; ?>
                        <div class="pnt-comment-actions">
                            <button class="pnt-action-btn pnt-action-btn--xs pnt-like-btn<?php echo $c_liked ? ' pnt-liked' : ''; ?><?php echo $approved ? '' : ' pnt-action--locked'; ?>" data-item-id="<?php echo esc_attr($c->id); ?>" data-item-type="comment">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="<?php echo $c_liked ? 'var(--pnt-red)' : 'none'; ?>" stroke="<?php echo $c_liked ? 'var(--pnt-red)' : 'currentColor'; ?>" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                                <span><?php echo (int) $c->like_count; ?></span>
                            </button>
                            <?php if ( $approved ): ?>
                            <button class="pnt-action-btn pnt-action-btn--xs pnt-reply-to-comment" data-comment-id="<?php echo esc_attr($c->id); ?>" data-thread-id="<?php echo esc_attr($thread_id); ?>" data-name="<?php echo esc_attr($c_user['name']); ?>">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/></svg>
                                Reply
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════════════════════════
       TIME HELPER
       ══════════════════════════════════════════════════════════════ */

    public static function time_ago( $datetime ) {
        $diff = time() - strtotime( $datetime );
        if ( $diff < 60 )        return $diff . 's';
        if ( $diff < 3600 )      return floor( $diff/60 ) . 'm';
        if ( $diff < 86400 )     return floor( $diff/3600 ) . 'h';
        if ( $diff < 604800 )    return floor( $diff/86400 ) . 'd';
        return date( 'M j', strtotime( $datetime ) );
    }
}
