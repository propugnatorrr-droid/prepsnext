<?php
/**
 * AJAX Handlers
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Ajax {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_ajax_pn_search_posts',        [ $this, 'search_posts' ] );
        add_action( 'wp_ajax_pn_get_athlete_card',    [ $this, 'get_athlete_card' ] );
        add_action( 'wp_ajax_nopriv_pn_get_athlete_card', [ $this, 'get_athlete_card' ] );
        add_action( 'admin_post_pn_export_athletes',  [ $this, 'export_athletes_csv' ] );
        add_action( 'admin_post_pn_import_athletes',  [ $this, 'import_athletes_csv' ] );
    }

    /**
     * Search posts for related post linking
     */
    public function search_posts() {
        check_ajax_referer( 'prepsnext_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error();

        $query = sanitize_text_field( $_POST['query'] ?? '' );
        if ( ! $query ) wp_send_json_success([]);

        $posts = get_posts([
            's'           => $query,
            'numberposts' => 20,
            'post_type'   => ['post', 'page'],
            'post_status' => 'publish',
        ]);

        $results = array_map(function($p) {
            return [
                'id'    => $p->ID,
                'title' => $p->post_title,
                'url'   => get_permalink($p->ID),
            ];
        }, $posts);

        wp_send_json_success( $results );
    }

    /**
     * Get athlete card HTML (used for hover cards on mentions)
     */
    public function get_athlete_card() {
        check_ajax_referer( 'prepsnext_nonce', 'nonce' );
        $pid = absint( $_POST['pid'] ?? 0 );
        if ( ! $pid ) wp_send_json_error();

        $post = get_post($pid);
        if ( ! $post || $post->post_type !== 'pn_athlete' ) wp_send_json_error();

        $first  = get_post_meta($pid,'_pn_first_name',true) ?: $post->post_title;
        $last   = get_post_meta($pid,'_pn_last_name',true);
        $school = get_post_meta($pid,'_pn_school_name',true);
        $pos    = get_post_meta($pid,'_pn_positions',true);
        $ht     = get_post_meta($pid,'_pn_height',true);
        $action_id = get_post_meta($pid,'_pn_action_image_id',true);
        $thumb  = $action_id ? wp_get_attachment_image_url($action_id,'thumbnail') : get_the_post_thumbnail_url($pid,'thumbnail');
        $sport_terms = get_the_terms($pid,'pn_sport');
        $sport  = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';
        $nat    = get_post_meta($pid,'_pn_national_rank',true);

        ob_start();
        ?>
        <div class="pn-hover-card">
            <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr("$first $last"); ?>"><br><?php endif; ?>
            <strong><?php echo esc_html("$first $last"); ?></strong><br>
            <?php if($school): ?><span><?php echo esc_html($school); ?></span><br><?php endif; ?>
            <?php if($sport): ?><span><?php echo esc_html($sport); ?></span><?php endif; ?>
            <?php if($pos): ?> · <span><?php echo esc_html($pos); ?></span><?php endif; ?><br>
            <?php if($nat): ?><span>#<?php echo esc_html($nat); ?> National</span><br><?php endif; ?>
            <a href="<?php echo get_permalink($pid); ?>">View Profile →</a>
        </div>
        <?php
        $html = ob_get_clean();
        wp_send_json_success(['html' => $html]);
    }

    /**
     * Export all athletes as CSV
     */
    public function export_athletes_csv() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        if ( ! wp_verify_nonce($_GET['nonce']??'','pn_export') ) wp_die('Invalid nonce');

        $athletes = get_posts([
            'post_type'   => 'pn_athlete',
            'numberposts' => -1,
            'post_status' => 'publish',
        ]);

        $filename = 'prepsnext-athletes-' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $out = fopen('php://output', 'w');

        // Headers
        fputcsv($out, [
            'ID', 'First Name', 'Last Name', 'Sport', 'Class Year', 'State', 'City',
            'School', 'School Location', 'Positions', 'Jersey', 'Height', 'Weight',
            'National Rank', 'State Rank', 'Status', 'Committed To', 'Profile URL'
        ]);

        foreach ($athletes as $a) {
            $pid = $a->ID;
            $sport_terms = get_the_terms($pid,'pn_sport');
            $class_terms = get_the_terms($pid,'pn_class_year');
            $state_terms = get_the_terms($pid,'pn_state');

            fputcsv($out, [
                $pid,
                get_post_meta($pid,'_pn_first_name',true),
                get_post_meta($pid,'_pn_last_name',true),
                ($sport_terms && !is_wp_error($sport_terms)) ? $sport_terms[0]->name : '',
                ($class_terms && !is_wp_error($class_terms)) ? $class_terms[0]->name : '',
                ($state_terms && !is_wp_error($state_terms)) ? $state_terms[0]->name : '',
                get_post_meta($pid,'_pn_city',true),
                get_post_meta($pid,'_pn_school_name',true),
                get_post_meta($pid,'_pn_school_location',true),
                get_post_meta($pid,'_pn_positions',true),
                get_post_meta($pid,'_pn_jersey_number',true),
                get_post_meta($pid,'_pn_height',true),
                get_post_meta($pid,'_pn_weight',true),
                get_post_meta($pid,'_pn_national_rank',true),
                get_post_meta($pid,'_pn_state_rank',true),
                get_post_meta($pid,'_pn_prospect_status',true),
                get_post_meta($pid,'_pn_committed_to',true),
                get_permalink($pid),
            ]);
        }

        fclose($out);
        exit;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CSV Import
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Handles CSV import from Admin → Import/Export page.
     *
     * Expected CSV columns (order-independent, matched by header name):
     *   post_title, first_name, last_name, sport, class_year, state, city,
     *   school_name, school_location, team_name, positions, jersey_number,
     *   conference, division, height, weight, wingspan, hand_size,
     *   dominant_hand, dominant_foot, vertical, forty_time, bench_press, shuttle,
     *   gpa, sat_score, act_score, grad_year, intended_major, academic_honors,
     *   ncaa_eligible, prospect_status, national_rank, state_rank, position_rank,
     *   rank_label, watchlist_rank, watchlist_label, stock_riser,
     *   committed_to, committed_date, signed, college_offers, college_interests,
     *   bio, contact_email, contact_phone,
     *   stat_ppg, stat_rpg, stat_apg, stat_spg, stat_bpg, stat_fg_pct,
     *   stat_three_pct, stat_ft_pct, stat_gp,
     *   stat_pass_yards, stat_pass_tds, stat_rush_yards, stat_rush_tds,
     *   stat_rec_yards, stat_rec_tds, stat_tackles, stat_sacks, stat_ints, stat_ff,
     *   social_instagram, social_twitter, social_tiktok, social_youtube,
     *   social_facebook, social_hudl, social_rivals, social_twofour7,
     *   social_espn, social_on3
     */
    public function import_athletes_csv() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        if ( ! check_admin_referer( 'pn_import' ) )   wp_die( 'Invalid nonce' );

        if ( empty( $_FILES['pn_import_file']['tmp_name'] ) ) {
            wp_redirect( add_query_arg( 'pn_import', 'no_file', wp_get_referer() ) );
            exit;
        }

        $file = $_FILES['pn_import_file']['tmp_name'];
        $handle = fopen( $file, 'r' );
        if ( ! $handle ) {
            wp_redirect( add_query_arg( 'pn_import', 'bad_file', wp_get_referer() ) );
            exit;
        }

        // Read header row and normalise to lowercase/trimmed keys
        $raw_headers = fgetcsv( $handle );
        if ( ! $raw_headers ) {
            fclose( $handle );
            wp_redirect( add_query_arg( 'pn_import', 'empty', wp_get_referer() ) );
            exit;
        }
        $headers = array_map( function( $h ) {
            return strtolower( trim( str_replace( [ ' ', '-' ], '_', $h ) ) );
        }, $raw_headers );

        $imported = 0;
        $skipped  = 0;

        while ( ( $row = fgetcsv( $handle ) ) !== false ) {
            if ( count( $row ) < 2 ) { $skipped++; continue; }

            // Map header => value
            $data = [];
            foreach ( $headers as $i => $key ) {
                $data[ $key ] = isset( $row[ $i ] ) ? trim( $row[ $i ] ) : '';
            }

            // Determine post title
            $first = sanitize_text_field( $data['first_name'] ?? '' );
            $last  = sanitize_text_field( $data['last_name']  ?? '' );
            $title = trim( "$first $last" );
            if ( ! $title ) {
                $title = sanitize_text_field( $data['post_title'] ?? '' );
            }
            if ( ! $title ) { $skipped++; continue; }

            // Create the post
            $post_id = wp_insert_post( [
                'post_type'   => 'pn_athlete',
                'post_title'  => $title,
                'post_name'   => sanitize_title( $title . '-' . wp_rand( 100, 999 ) ),
                'post_status' => 'publish',
            ] );

            if ( is_wp_error( $post_id ) ) { $skipped++; continue; }

            // ── Taxonomies ─────────────────────────────────────────────────
            $this->set_term( $post_id, 'pn_sport',      $data['sport']      ?? '' );
            $this->set_term( $post_id, 'pn_class_year', $data['class_year'] ?? '' );
            $this->set_term( $post_id, 'pn_state',      $data['state']      ?? '' );

            // Handle positions taxonomy (primary position)
            $pos_val = $data['positions'] ?? '';
            if ( $pos_val ) {
                // Store comma-list as meta; also set first position in taxonomy
                $first_pos = trim( explode( ',', $pos_val )[0] );
                $this->set_term( $post_id, 'pn_position', $first_pos );
            }

            // ── Simple text meta ───────────────────────────────────────────
            $meta_map = [
                'first_name'         => '_pn_first_name',
                'last_name'          => '_pn_last_name',
                'city'               => '_pn_city',
                'dob'                => '_pn_dob',
                'bio'                => '_pn_bio',
                'contact_email'      => '_pn_contact_email',
                'contact_phone'      => '_pn_contact_phone',
                'school_name'        => '_pn_school_name',
                'school_location'    => '_pn_school_location',
                'team_name'          => '_pn_team_name',
                'jersey_number'      => '_pn_jersey_number',
                'positions'          => '_pn_positions',
                'conference'         => '_pn_conference',
                'division'           => '_pn_division',
                'height'             => '_pn_height',
                'weight'             => '_pn_weight',
                'wingspan'           => '_pn_wingspan',
                'hand_size'          => '_pn_hand_size',
                'dominant_hand'      => '_pn_dominant_hand',
                'dominant_foot'      => '_pn_dominant_foot',
                'vertical'           => '_pn_vertical',
                'forty_time'         => '_pn_forty_time',
                'bench_press'        => '_pn_bench_press',
                'shuttle'            => '_pn_shuttle',
                'gpa'                => '_pn_gpa',
                'sat_score'          => '_pn_sat_score',
                'act_score'          => '_pn_act_score',
                'grad_year'          => '_pn_grad_year',
                'intended_major'     => '_pn_intended_major',
                'academic_honors'    => '_pn_academic_honors',
                'prospect_status'    => '_pn_prospect_status',
                'national_rank'      => '_pn_national_rank',
                'state_rank'         => '_pn_state_rank',
                'position_rank'      => '_pn_position_rank',
                'rank_label'         => '_pn_rank_label',
                'watchlist_rank'     => '_pn_watchlist_rank',
                'watchlist_label'    => '_pn_watchlist_label',
                'committed_to'       => '_pn_committed_to',
                'committed_date'     => '_pn_committed_date',
                'nli_date'           => '_pn_nli_date',
                'recruiting_profile_url' => '_pn_recruiting_profile_url',
                'athlete_tag'        => '_pn_athlete_tag',
            ];

            foreach ( $meta_map as $csv_key => $meta_key ) {
                if ( isset( $data[ $csv_key ] ) && $data[ $csv_key ] !== '' ) {
                    update_post_meta( $post_id, $meta_key, sanitize_text_field( $data[ $csv_key ] ) );
                }
            }

            // ── Checkbox / boolean meta ────────────────────────────────────
            foreach ( [ 'ncaa_eligible' => '_pn_ncaa_eligible', 'stock_riser' => '_pn_stock_riser', 'signed' => '_pn_signed' ] as $csv_key => $meta_key ) {
                $val = strtolower( $data[ $csv_key ] ?? '' );
                update_post_meta( $post_id, $meta_key, in_array( $val, [ '1', 'yes', 'true' ], true ) ? '1' : '' );
            }

            // ── College offers / interests (pipe or newline-separated) ─────
            foreach ( [ 'college_offers' => '_pn_college_offers', 'college_interests' => '_pn_college_interests' ] as $csv_key => $meta_key ) {
                $raw = $data[ $csv_key ] ?? '';
                if ( $raw ) {
                    $sep   = strpos( $raw, '|' ) !== false ? '|' : "\n";
                    $items = array_filter( array_map( 'trim', explode( $sep, $raw ) ) );
                    update_post_meta( $post_id, $meta_key, array_values( $items ) );
                }
            }

            // ── Basketball + Football stats ────────────────────────────────
            $stat_keys = [
                'ppg','rpg','apg','spg','bpg','fg_pct','three_pct','ft_pct','gp',
                'pass_yards','pass_tds','rush_yards','rush_tds',
                'rec_yards','rec_tds','tackles','sacks','ints','ff',
            ];
            $stats = [];
            foreach ( $stat_keys as $sk ) {
                $csv_col = 'stat_' . $sk;
                if ( isset( $data[ $csv_col ] ) && $data[ $csv_col ] !== '' ) {
                    $stats[ $sk ] = sanitize_text_field( $data[ $csv_col ] );
                }
            }
            if ( ! empty( $stats ) ) {
                update_post_meta( $post_id, '_pn_stats', $stats );
            }

            // ── Social links ───────────────────────────────────────────────
            $social_keys = [ 'instagram','twitter','tiktok','youtube','facebook','hudl','rivals','twofour7','espn','on3' ];
            foreach ( $social_keys as $sk ) {
                $csv_col = 'social_' . $sk;
                if ( ! empty( $data[ $csv_col ] ) ) {
                    update_post_meta( $post_id, '_pn_social_' . $sk, esc_url_raw( $data[ $csv_col ] ) );
                }
            }

            $imported++;
        }

        fclose( $handle );

        wp_redirect( add_query_arg(
            [ 'pn_import' => 'done', 'pn_imported' => $imported, 'pn_skipped' => $skipped ],
            wp_get_referer()
        ) );
        exit;
    }

    /**
     * Helper — assign a taxonomy term (by name or slug) to a post.
     * Creates the term if it doesn't exist yet.
     */
    private function set_term( $post_id, $taxonomy, $term_name ) {
        $term_name = trim( $term_name );
        if ( ! $term_name ) return;

        $term = get_term_by( 'name', $term_name, $taxonomy );
        if ( ! $term ) {
            $term = get_term_by( 'slug', sanitize_title( $term_name ), $taxonomy );
        }
        if ( ! $term ) {
            $result = wp_insert_term( $term_name, $taxonomy );
            if ( is_wp_error( $result ) ) return;
            $term_id = $result['term_id'];
        } else {
            $term_id = $term->term_id;
        }

        wp_set_object_terms( $post_id, $term_id, $taxonomy, true );
    }
}
