<?php
/**
 * Frontend Hooks & Filters
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Frontend {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_head',              [ $this, 'output_dynamic_css' ] );
        add_action( 'pre_get_posts',        [ $this, 'modify_archive_query' ] );
        add_filter( 'document_title_parts', [ $this, 'filter_title' ] );
        add_action( 'wp_head',              [ $this, 'output_schema' ] );
        add_filter( 'the_content',          [ $this, 'auto_link_athlete_mentions' ] );
        add_filter( 'post_class',           [ $this, 'add_post_class' ], 10, 3 );

        // Auto-flush rewrite rules once after plugin update
        add_action( 'init', [ $this, 'maybe_flush_rewrites' ], 999 );
    }

    /**
     * Flush rewrite rules once whenever plugin version changes.
     * This fixes the "Athletes not found / 404" problem on existing installs
     * without requiring manual deactivate/reactivate.
     */
    public function maybe_flush_rewrites() {
        $flushed = get_option( 'prepsnext_rewrites_flushed' );
        if ( $flushed !== PREPSNEXT_VERSION ) {
            flush_rewrite_rules( false );
            update_option( 'prepsnext_rewrites_flushed', PREPSNEXT_VERSION );
        }
    }

    /**
     * Output dynamic CSS from settings
     */
    public function output_dynamic_css() {
        if ( ! is_singular('pn_athlete') && ! is_post_type_archive('pn_athlete') ) return;

        $settings = get_option('prepsnext_settings', []);
        $accent   = $settings['accent_color'] ?? '#AAFF00';
        $dark_bg  = $settings['dark_bg']       ?? '#111111';
        $custom   = $settings['custom_css']    ?? '';

        echo '<style id="prepsnext-dynamic-css">
:root {
    --pn-accent: ' . esc_attr($accent) . ';
    --pn-dark:   ' . esc_attr($dark_bg) . ';
}
' . wp_strip_all_tags($custom) . '
</style>' . "\n";
    }

    /**
     * Modify archive query for filters
     */
    public function modify_archive_query( $query ) {
        if ( ! is_admin() && $query->is_main_query() && is_post_type_archive('pn_athlete') ) {
            $settings = get_option('prepsnext_settings', []);
            $per_page = intval($settings['archive_per_page'] ?? 24);
            $query->set('posts_per_page', $per_page);

            $tax_query = [];

            if ( ! empty($_GET['sport']) ) {
                $tax_query[] = [
                    'taxonomy' => 'pn_sport',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($_GET['sport']),
                ];
            }

            if ( ! empty($_GET['state']) ) {
                $tax_query[] = [
                    'taxonomy' => 'pn_state',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($_GET['state']),
                ];
            }

            if ( ! empty($_GET['class']) ) {
                $tax_query[] = [
                    'taxonomy' => 'pn_class_year',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($_GET['class']),
                ];
            }

            if ( ! empty($_GET['pos']) ) {
                $tax_query[] = [
                    'taxonomy' => 'pn_position',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($_GET['pos']),
                ];
            }

            if ( ! empty($tax_query) ) {
                $query->set('tax_query', $tax_query);
            }

            if ( ! empty($_GET['search']) ) {
                $query->set('s', sanitize_text_field($_GET['search']));
            }
        }
    }

    /**
     * Custom title for athlete profiles
     */
    public function filter_title( $parts ) {
        if ( is_singular('pn_athlete') ) {
            $pid    = get_the_ID();
            $first  = get_post_meta($pid,'_pn_first_name',true);
            $last   = get_post_meta($pid,'_pn_last_name',true);
            $sport_terms = get_the_terms($pid,'pn_sport');
            $sport  = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';
            if ($first && $last) {
                $parts['title'] = "$first $last - $sport Recruit Profile";
            }
        }
        return $parts;
    }

    /**
     * Output Schema.org markup for athlete profiles
     */
    public function output_schema() {
        if ( ! is_singular('pn_athlete') ) return;
        $pid   = get_the_ID();
        $first = get_post_meta($pid,'_pn_first_name',true);
        $last  = get_post_meta($pid,'_pn_last_name',true);
        if (!$first) return;

        $school      = get_post_meta($pid,'_pn_school_name',true);
        $height      = get_post_meta($pid,'_pn_height',true);
        $weight      = get_post_meta($pid,'_pn_weight',true);
        $action_id   = get_post_meta($pid,'_pn_action_image_id',true);
        $image_url   = $action_id ? wp_get_attachment_image_url($action_id,'large') : get_the_post_thumbnail_url($pid,'large');
        $sport_terms = get_the_terms($pid,'pn_sport');
        $sport       = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';

        $schema = [
            '@context'  => 'https://schema.org',
            '@type'     => 'Person',
            'name'      => trim("$first $last"),
            'url'       => get_permalink($pid),
            'jobTitle'  => $sport . ' Athlete',
            'affiliation'=> ['@type'=>'Organization','name'=> $school ?: ''],
        ];

        if ($image_url)  $schema['image'] = $image_url;
        if ($height)     $schema['height'] = $height;
        if ($weight)     $schema['weight'] = $weight;

        // Social media
        $social_links = [];
        $social_keys  = ['instagram','twitter','youtube','facebook','tiktok'];
        foreach ($social_keys as $sk) {
            $url = get_post_meta($pid,'_pn_social_'.$sk,true);
            if ($url) $social_links[] = $url;
        }
        if ($social_links) $schema['sameAs'] = $social_links;

        echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>' . "\n";
    }

    /**
     * Auto-link athlete tag mentions in post content
     * Usage: text like [[athlete:reese-savage]] gets converted to a link
     */
    public function auto_link_athlete_mentions( $content ) {
        if ( is_singular('pn_athlete') ) return $content;
        if ( ! is_singular() ) return $content;

        // Pattern: [[athlete:slug]]
        $content = preg_replace_callback(
            '/\[\[athlete:([a-z0-9_-]+)\]\]/i',
            function($matches) {
                $slug = sanitize_title($matches[1]);
                $post = get_page_by_path($slug, OBJECT, 'pn_athlete');
                if (!$post) return $matches[0];

                $pid   = $post->ID;
                $first = get_post_meta($pid,'_pn_first_name',true) ?: $post->post_title;
                $last  = get_post_meta($pid,'_pn_last_name',true);
                $name  = trim("$first $last");

                return '<a href="' . get_permalink($pid) . '" class="pn-athlete-mention" data-pid="'.$pid.'">'
                     . esc_html($name) . '</a>';
            },
            $content
        );

        return $content;
    }

    /**
     * Add sport class to athlete posts
     */
    public function add_post_class( $classes, $class, $post_id ) {
        if ( get_post_type($post_id) === 'pn_athlete' ) {
            $sport_terms = get_the_terms($post_id,'pn_sport');
            if ($sport_terms && !is_wp_error($sport_terms)) {
                $classes[] = 'pn-sport-' . sanitize_html_class($sport_terms[0]->slug);
            }
        }
        return $classes;
    }
}
