<?php
/**
 * Custom Taxonomies for Athlete Profiles
 *
 * ::instance() is called from plugins_loaded so add_action('init') here
 * fires correctly at the right time.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Taxonomies {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', [ $this, 'register_taxonomies' ], 0 );
        add_action( 'init', [ $this, 'seed_default_terms' ], 99 );
    }

    // ── Called from activation hook ──────────────────────────────────────────
    public static function register_taxonomies_static() {
        self::do_register_taxonomies();
    }

    public function register_taxonomies() {
        self::do_register_taxonomies();
    }

    private static function do_register_taxonomies() {

        // Sport
        if ( ! taxonomy_exists( 'pn_sport' ) ) {
            register_taxonomy( 'pn_sport', 'pn_athlete', [
                'labels'            => self::tax_labels( 'Sports', 'Sport' ),
                'public'            => true,
                'hierarchical'      => false,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => 'sport' ],
            ] );
        }

        // Position
        if ( ! taxonomy_exists( 'pn_position' ) ) {
            register_taxonomy( 'pn_position', 'pn_athlete', [
                'labels'            => self::tax_labels( 'Positions', 'Position' ),
                'public'            => true,
                'hierarchical'      => false,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => 'position' ],
            ] );
        }

        // State
        if ( ! taxonomy_exists( 'pn_state' ) ) {
            register_taxonomy( 'pn_state', 'pn_athlete', [
                'labels'            => self::tax_labels( 'States', 'State' ),
                'public'            => true,
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => 'athlete-state' ],
            ] );
        }

        // Class Year
        if ( ! taxonomy_exists( 'pn_class_year' ) ) {
            register_taxonomy( 'pn_class_year', 'pn_athlete', [
                'labels'            => self::tax_labels( 'Class Years', 'Class Year' ),
                'public'            => true,
                'hierarchical'      => false,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => 'class-year' ],
            ] );
        }

        // School
        if ( ! taxonomy_exists( 'pn_school_tax' ) ) {
            register_taxonomy( 'pn_school_tax', 'pn_athlete', [
                'labels'            => self::tax_labels( 'Schools', 'School' ),
                'public'            => true,
                'hierarchical'      => false,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => 'athlete-school' ],
            ] );
        }

        // College Interests
        if ( ! taxonomy_exists( 'pn_college_interest' ) ) {
            register_taxonomy( 'pn_college_interest', 'pn_athlete', [
                'labels'            => self::tax_labels( 'College Interests', 'College Interest' ),
                'public'            => false,
                'hierarchical'      => false,
                'show_ui'           => true,
                'show_admin_column' => false,
                'show_in_rest'      => true,
                'rewrite'           => false,
            ] );
        }
    }

    private static function tax_labels( $plural, $singular ) {
        return [
            'name'          => __( $plural,   'prepsnext' ),
            'singular_name' => __( $singular, 'prepsnext' ),
            'menu_name'     => __( $plural,   'prepsnext' ),
        ];
    }

    // ── Seed default terms (runs after init, only if missing) ───────────────
    public function seed_default_terms() {
        // Sports
        foreach ( [ 'Basketball', 'Football' ] as $sport ) {
            if ( ! term_exists( $sport, 'pn_sport' ) ) {
                wp_insert_term( $sport, 'pn_sport' );
            }
        }

        // Basketball positions
        foreach ( [ 'PG', 'SG', 'SF', 'PF', 'C', 'G', 'F', 'G/F', 'F/C' ] as $pos ) {
            if ( ! term_exists( $pos, 'pn_position' ) ) {
                wp_insert_term( $pos, 'pn_position' );
            }
        }

        // Football positions
        foreach ( [ 'QB', 'RB', 'WR', 'TE', 'OL', 'OT', 'OG', 'DE', 'DT', 'LB', 'CB', 'S', 'FS', 'SS', 'K', 'P', 'ATH' ] as $pos ) {
            if ( ! term_exists( $pos, 'pn_position' ) ) {
                wp_insert_term( $pos, 'pn_position' );
            }
        }

        // Class years
        $y = (int) date( 'Y' );
        for ( $i = $y; $i <= $y + 6; $i++ ) {
            $term = 'Class of ' . $i;
            if ( ! term_exists( $term, 'pn_class_year' ) ) {
                wp_insert_term( $term, 'pn_class_year' );
            }
        }
        if ( ! term_exists( 'Graduated', 'pn_class_year' ) ) {
            wp_insert_term( 'Graduated', 'pn_class_year' );
        }

        // US States
        $states = [
            'Alabama','Alaska','Arizona','Arkansas','California','Colorado',
            'Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho',
            'Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana',
            'Maine','Maryland','Massachusetts','Michigan','Minnesota',
            'Mississippi','Missouri','Montana','Nebraska','Nevada',
            'New Hampshire','New Jersey','New Mexico','New York',
            'North Carolina','North Dakota','Ohio','Oklahoma','Oregon',
            'Pennsylvania','Rhode Island','South Carolina','South Dakota',
            'Tennessee','Texas','Utah','Vermont','Virginia','Washington',
            'West Virginia','Wisconsin','Wyoming','Washington D.C.',
        ];
        foreach ( $states as $state ) {
            if ( ! term_exists( $state, 'pn_state' ) ) {
                wp_insert_term( $state, 'pn_state' );
            }
        }
    }
}
