<?php
/**
 * Shortcodes
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Shortcodes {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_shortcode( 'prepsnext_athlete',      [ $this, 'athlete_card_shortcode' ] );
        add_shortcode( 'prepsnext_athletes',     [ $this, 'athlete_list_shortcode' ] );
        add_shortcode( 'prepsnext_rankings',     [ $this, 'rankings_shortcode' ] );
        add_shortcode( 'prepsnext_top_athletes', [ $this, 'top_athletes_shortcode' ] );
    }

    /**
     * [prepsnext_athlete id="123"]
     * [prepsnext_athlete slug="reese-savage"]
     */
    public function athlete_card_shortcode( $atts ) {
        $atts = shortcode_atts([
            'id'    => 0,
            'slug'  => '',
            'style' => 'card', // card | mini | inline
        ], $atts, 'prepsnext_athlete' );

        $pid = 0;
        if ( $atts['id'] ) {
            $pid = absint($atts['id']);
        } elseif ( $atts['slug'] ) {
            $post = get_page_by_path($atts['slug'], OBJECT, 'pn_athlete');
            if ($post) $pid = $post->ID;
        }

        if ( ! $pid ) return '';
        $post = get_post($pid);
        if ( ! $post || $post->post_type !== 'pn_athlete' ) return '';

        $first  = get_post_meta($pid,'_pn_first_name',true) ?: $post->post_title;
        $last   = get_post_meta($pid,'_pn_last_name',true);
        $school = get_post_meta($pid,'_pn_school_name',true);
        $pos    = get_post_meta($pid,'_pn_positions',true);
        $ht     = get_post_meta($pid,'_pn_height',true);
        $wt     = get_post_meta($pid,'_pn_weight',true);
        $nat    = get_post_meta($pid,'_pn_national_rank',true);
        $state_r= get_post_meta($pid,'_pn_state_rank',true);
        $status = get_post_meta($pid,'_pn_prospect_status',true);
        $city   = get_post_meta($pid,'_pn_city',true);
        $action_id = get_post_meta($pid,'_pn_action_image_id',true);
        $thumb  = $action_id ? wp_get_attachment_image_url($action_id,'medium') : get_the_post_thumbnail_url($pid,'medium');

        $sport_terms = get_the_terms($pid,'pn_sport');
        $sport       = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';
        $sport_slug  = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->slug : '';
        $sport_icon  = strtolower($sport_slug) === 'football' ? '🏈' : '🏀';

        $class_terms = get_the_terms($pid,'pn_class_year');
        $class_year  = $class_terms && !is_wp_error($class_terms) ? $class_terms[0]->name : '';

        $state_terms = get_the_terms($pid,'pn_state');
        $state       = $state_terms && !is_wp_error($state_terms) ? $state_terms[0]->name : '';

        ob_start();

        if ($atts['style'] === 'mini') {
            // Inline mini badge
            ?>
            <a href="<?php echo get_permalink($pid); ?>" class="pn-inline-badge">
                <?php echo esc_html("$sport_icon $first $last"); ?>
                <?php if($school): ?><span class="pn-ib-school"><?php echo esc_html($school); ?></span><?php endif; ?>
            </a>
            <?php
        } elseif ($atts['style'] === 'inline') {
            ?>
            <div class="pn-inline-card">
                <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr("$first $last"); ?>" class="pn-ic-thumb"><?php endif; ?>
                <div class="pn-ic-info">
                    <a href="<?php echo get_permalink($pid); ?>" class="pn-ic-name"><?php echo esc_html("$first $last"); ?></a>
                    <?php if($school): ?><div class="pn-ic-school"><?php echo esc_html($school); ?></div><?php endif; ?>
                    <div class="pn-ic-meta"><?php echo esc_html(implode(' · ', array_filter([$sport,$pos,$ht,$class_year]))); ?></div>
                </div>
            </div>
            <?php
        } else {
            // Full card
            $badge_html = '';
            $status_map = [
                'top_prospect' => ['label'=>'TOP PROSPECT','class'=>'pn-badge--gold'],
                'featured'     => ['label'=>'FEATURED','class'=>'pn-badge--featured'],
                'stock_riser'  => ['label'=>'STOCK RISER','class'=>'pn-badge--riser'],
                'committed'    => ['label'=>'COMMITTED','class'=>'pn-badge--committed'],
            ];
            if (isset($status_map[$status])) {
                $badge_html = '<span class="pn-status-badge '.$status_map[$status]['class'].'">' . esc_html($status_map[$status]['label']) . '</span>';
            }
            ?>
            <div class="pn-shortcode-card pn-sport-<?php echo esc_attr($sport_slug); ?>">
                <?php if($thumb): ?>
                <div class="pn-sc-photo">
                    <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr("$first $last"); ?>">
                    <?php if($badge_html): ?><div class="pn-sc-badge"><?php echo $badge_html; ?></div><?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="pn-sc-body">
                    <div class="pn-sc-sport"><?php echo esc_html($sport_icon.' '.$sport); ?></div>
                    <h3 class="pn-sc-name">
                        <a href="<?php echo get_permalink($pid); ?>"><?php echo esc_html("$first $last"); ?></a>
                    </h3>
                    <?php if($school): ?><div class="pn-sc-school"><?php echo esc_html($school); ?></div><?php endif; ?>
                    <div class="pn-sc-meta">
                        <?php if($pos): ?><span><?php echo esc_html($pos); ?></span><?php endif; ?>
                        <?php if($ht): ?><span><?php echo esc_html($ht); ?></span><?php endif; ?>
                        <?php if($class_year): ?><span><?php echo esc_html($class_year); ?></span><?php endif; ?>
                    </div>
                    <?php if($nat || $state_r): ?>
                    <div class="pn-sc-ranks">
                        <?php if($nat): ?><span class="pn-cr-rank">#<?php echo esc_html($nat); ?> Nat.</span><?php endif; ?>
                        <?php if($state_r): ?><span class="pn-cr-rank">#<?php echo esc_html($state_r); ?> State</span><?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <a href="<?php echo get_permalink($pid); ?>" class="pn-btn pn-btn-primary pn-btn-sm" style="margin-top:12px;">
                        View Profile →
                    </a>
                </div>
            </div>
            <?php
        }

        return ob_get_clean();
    }

    /**
     * [prepsnext_athletes sport="basketball" limit="8" class_year="class-of-2026"]
     */
    public function athlete_list_shortcode( $atts ) {
        $atts = shortcode_atts([
            'sport'      => '',
            'limit'      => 8,
            'class_year' => '',
            'state'      => '',
            'status'     => '',
            'columns'    => 4,
        ], $atts, 'prepsnext_athletes' );

        $args = [
            'post_type'      => 'pn_athlete',
            'numberposts'    => absint($atts['limit']),
            'post_status'    => 'publish',
            'tax_query'      => [],
        ];

        if ($atts['sport']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_sport','field'=>'slug','terms'=>$atts['sport']];
        }
        if ($atts['class_year']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_class_year','field'=>'slug','terms'=>$atts['class_year']];
        }
        if ($atts['state']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_state','field'=>'slug','terms'=>$atts['state']];
        }
        if ($atts['status']) {
            $args['meta_query'][] = ['key'=>'_pn_prospect_status','value'=>$atts['status']];
        }

        $athletes = get_posts($args);
        if (empty($athletes)) return '<p class="pn-no-results">No athletes found.</p>';

        ob_start();
        echo '<div class="pn-athlete-grid" style="--columns:' . absint($atts['columns']) . ';">';
        foreach ($athletes as $a) {
            $pid = $a->ID;
            echo $this->athlete_card_shortcode(['id' => $pid, 'style' => 'card', 'slug' => '']);
        }
        echo '</div>';
        return ob_get_clean();
    }

    /**
     * [prepsnext_rankings sport="basketball" limit="10" type="national"]
     */
    public function rankings_shortcode( $atts ) {
        $atts = shortcode_atts([
            'sport'  => 'basketball',
            'limit'  => 10,
            'type'   => 'national', // national | state | position
            'state'  => '',
        ], $atts, 'prepsnext_rankings' );

        $meta_key = '_pn_national_rank';
        if ($atts['type'] === 'state')    $meta_key = '_pn_state_rank';
        if ($atts['type'] === 'position') $meta_key = '_pn_position_rank';

        $args = [
            'post_type'   => 'pn_athlete',
            'numberposts' => absint($atts['limit']),
            'post_status' => 'publish',
            'meta_key'    => $meta_key,
            'orderby'     => 'meta_value_num',
            'order'       => 'ASC',
            'meta_query'  => [['key'=>$meta_key,'compare'=>'EXISTS','type'=>'NUMERIC']],
            'tax_query'   => [],
        ];

        if ($atts['sport']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_sport','field'=>'slug','terms'=>$atts['sport']];
        }
        if ($atts['state']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_state','field'=>'slug','terms'=>$atts['state']];
        }

        $athletes = get_posts($args);
        if (empty($athletes)) return '<p>No ranked athletes found.</p>';

        $sport_icon = strtolower($atts['sport']) === 'football' ? '🏈' : '🏀';

        ob_start();
        ?>
        <div class="pn-rankings-table">
            <div class="pn-rt-header">
                <span><?php echo esc_html($sport_icon); ?> <?php echo esc_html(ucfirst($atts['sport'])); ?> Rankings</span>
            </div>
            <?php foreach($athletes as $i => $a):
                $pid = $a->ID;
                $rank = get_post_meta($pid, $meta_key, true);
                $first = get_post_meta($pid,'_pn_first_name',true) ?: $a->post_title;
                $last  = get_post_meta($pid,'_pn_last_name',true);
                $school= get_post_meta($pid,'_pn_school_name',true);
                $pos   = get_post_meta($pid,'_pn_positions',true);
                $ht    = get_post_meta($pid,'_pn_height',true);
                $state_terms = get_the_terms($pid,'pn_state');
                $state = ($state_terms && !is_wp_error($state_terms)) ? $state_terms[0]->name : '';
                $class_terms = get_the_terms($pid,'pn_class_year');
                $cls   = ($class_terms && !is_wp_error($class_terms)) ? $class_terms[0]->name : '';
                $action_id = get_post_meta($pid,'_pn_action_image_id',true);
                $thumb = $action_id ? wp_get_attachment_image_url($action_id,'thumbnail') : get_the_post_thumbnail_url($pid,'thumbnail');
            ?>
            <a href="<?php echo get_permalink($pid); ?>" class="pn-rt-row">
                <span class="pn-rt-rank">#<?php echo esc_html($rank ?: ($i+1)); ?></span>
                <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" class="pn-rt-thumb" alt=""><?php endif; ?>
                <div class="pn-rt-info">
                    <strong><?php echo esc_html("$first $last"); ?></strong>
                    <span><?php echo esc_html(implode(' · ', array_filter([$school, $pos, $ht, $cls]))); ?></span>
                </div>
                <?php if($state): ?><span class="pn-rt-state"><?php echo esc_html($state); ?></span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * [prepsnext_top_athletes limit="4" sport="basketball"]
     * Featured showcase block
     */
    public function top_athletes_shortcode( $atts ) {
        $atts = shortcode_atts([
            'limit'   => 4,
            'sport'   => '',
            'status'  => 'top_prospect',
        ], $atts );

        $args = [
            'post_type'   => 'pn_athlete',
            'numberposts' => absint($atts['limit']),
            'post_status' => 'publish',
            'meta_query'  => [['key'=>'_pn_prospect_status','value'=>$atts['status']]],
            'tax_query'   => [],
        ];

        if ($atts['sport']) {
            $args['tax_query'][] = ['taxonomy'=>'pn_sport','field'=>'slug','terms'=>$atts['sport']];
        }

        $athletes = get_posts($args);
        if (empty($athletes)) return '';

        ob_start();
        echo '<div class="pn-top-athletes-showcase">';
        echo '<h2 class="pn-showcase-title">⭐ Top Prospects</h2>';
        echo '<div class="pn-athlete-grid">';
        foreach($athletes as $a) {
            echo $this->athlete_card_shortcode(['id'=>$a->ID,'style'=>'card','slug'=>'']);
        }
        echo '</div>';
        echo '</div>';
        return ob_get_clean();
    }
}
