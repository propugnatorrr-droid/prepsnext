<?php
/**
 * Meta Boxes for Athlete Profiles
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Metaboxes {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'add_meta_boxes', [ $this, 'register_meta_boxes' ] );
        add_action( 'save_post_pn_athlete', [ $this, 'save_meta' ], 10, 2 );
    }

    public function register_meta_boxes() {
        $boxes = [
            [ 'pn_identity',    __( '🏆 Prospect Status & Rankings', 'prepsnext' ),    [ $this, 'render_identity_box' ] ],
            [ 'pn_basic_info',  __( '👤 Basic Info & Location', 'prepsnext' ),          [ $this, 'render_basic_info_box' ] ],
            [ 'pn_school',      __( '🏫 School & Team Info', 'prepsnext' ),             [ $this, 'render_school_box' ] ],
            [ 'pn_measurements',__( '📏 Physical Measurements', 'prepsnext' ),          [ $this, 'render_measurements_box' ] ],
            [ 'pn_academics',   __( '📚 Academic History', 'prepsnext' ),               [ $this, 'render_academics_box' ] ],
            [ 'pn_career',      __( '📅 Career History (Seasons)', 'prepsnext' ),       [ $this, 'render_career_box' ] ],
            [ 'pn_stats',       __( '📊 Performance Stats', 'prepsnext' ),              [ $this, 'render_stats_box' ] ],
            [ 'pn_recruiting',  __( '🎓 Recruiting & College Interests', 'prepsnext' ), [ $this, 'render_recruiting_box' ] ],
            [ 'pn_media',       __( '🎬 Media Gallery (Photos & Videos)', 'prepsnext' ),[ $this, 'render_media_box' ] ],
            [ 'pn_social',      __( '📱 Social Media Links', 'prepsnext' ),             [ $this, 'render_social_box' ] ],
            [ 'pn_related',     __( '📰 Related Blog Posts', 'prepsnext' ),             [ $this, 'render_related_box' ] ],
        ];

        foreach ( $boxes as $box ) {
            add_meta_box(
                $box[0], $box[1], $box[2],
                'pn_athlete', 'normal', 'high'
            );
        }
    }

    // ─── Identity / Status ───────────────────────────────────────────────────

    public function render_identity_box( $post ) {
        wp_nonce_field( 'pn_save_meta', 'pn_meta_nonce' );
        $status    = get_post_meta( $post->ID, '_pn_prospect_status', true );
        $nat_rank  = get_post_meta( $post->ID, '_pn_national_rank', true );
        $state_rank= get_post_meta( $post->ID, '_pn_state_rank', true );
        $pos_rank  = get_post_meta( $post->ID, '_pn_position_rank', true );
        $rank_label= get_post_meta( $post->ID, '_pn_rank_label', true );
        $watchlist = get_post_meta( $post->ID, '_pn_watchlist_rank', true );
        $is_stock  = get_post_meta( $post->ID, '_pn_stock_riser', true );
        $watch_label = get_post_meta( $post->ID, '_pn_watchlist_label', true );
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'Prospect Status', 'prepsnext' ); ?></label>
                <select name="pn_prospect_status">
                    <option value=""         <?php selected($status,''); ?>><?php _e('Standard', 'prepsnext'); ?></option>
                    <option value="top_prospect" <?php selected($status,'top_prospect'); ?>><?php _e('⭐ Top Prospect', 'prepsnext'); ?></option>
                    <option value="featured" <?php selected($status,'featured'); ?>><?php _e('🔥 Featured', 'prepsnext'); ?></option>
                    <option value="stock_riser" <?php selected($status,'stock_riser'); ?>><?php _e('📈 Stock Riser', 'prepsnext'); ?></option>
                    <option value="under_radar" <?php selected($status,'under_radar'); ?>><?php _e('🕵️ Under the Radar', 'prepsnext'); ?></option>
                    <option value="committed" <?php selected($status,'committed'); ?>><?php _e('✅ Committed', 'prepsnext'); ?></option>
                    <option value="signed"    <?php selected($status,'signed'); ?>><?php _e('📝 Signed', 'prepsnext'); ?></option>
                </select>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'National Rank #', 'prepsnext' ); ?></label>
                <input type="number" name="pn_national_rank" value="<?php echo esc_attr($nat_rank); ?>" placeholder="e.g. 15" min="1">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'State Rank #', 'prepsnext' ); ?></label>
                <input type="number" name="pn_state_rank" value="<?php echo esc_attr($state_rank); ?>" placeholder="e.g. 2" min="1">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Position Rank #', 'prepsnext' ); ?></label>
                <input type="number" name="pn_position_rank" value="<?php echo esc_attr($pos_rank); ?>" placeholder="e.g. 1" min="1">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Rank Label', 'prepsnext' ); ?><span class="pn-hint">(e.g. "Top Guards in Florida")</span></label>
                <input type="text" name="pn_rank_label" value="<?php echo esc_attr($rank_label); ?>" placeholder="Top Guards in Florida">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Watchlist Rank #', 'prepsnext' ); ?></label>
                <input type="number" name="pn_watchlist_rank" value="<?php echo esc_attr($watchlist); ?>" placeholder="e.g. 1" min="1">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Watchlist Label', 'prepsnext' ); ?><span class="pn-hint">(e.g. "Class of 2026 Watchlist")</span></label>
                <input type="text" name="pn_watchlist_label" value="<?php echo esc_attr($watch_label); ?>" placeholder="Class of 2026 Watchlist">
            </div>
            <div class="pn-meta-field">
                <label>
                    <input type="checkbox" name="pn_stock_riser" value="1" <?php checked($is_stock, '1'); ?>>
                    <?php _e( '📈 Mark as Stock Riser', 'prepsnext' ); ?>
                </label>
            </div>
        </div>
        <?php
    }

    // ─── Basic Info ──────────────────────────────────────────────────────────

    public function render_basic_info_box( $post ) {
        $first       = get_post_meta( $post->ID, '_pn_first_name',      true );
        $last        = get_post_meta( $post->ID, '_pn_last_name',       true );
        $city        = get_post_meta( $post->ID, '_pn_city',            true );
        $dob         = get_post_meta( $post->ID, '_pn_dob',             true );
        $bio         = get_post_meta( $post->ID, '_pn_bio',             true );
        $headshot    = get_post_meta( $post->ID, '_pn_headshot_id',     true );
        $action_img  = get_post_meta( $post->ID, '_pn_action_image_id', true );
        $contact_email = get_post_meta( $post->ID, '_pn_contact_email', true );
        $contact_phone = get_post_meta( $post->ID, '_pn_contact_phone', true );
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'First Name', 'prepsnext' ); ?></label>
                <input type="text" name="pn_first_name" value="<?php echo esc_attr($first); ?>" placeholder="Bronny">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Last Name', 'prepsnext' ); ?></label>
                <input type="text" name="pn_last_name" value="<?php echo esc_attr($last); ?>" placeholder="James">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'City', 'prepsnext' ); ?><span class="pn-hint">(State set via taxonomy)</span></label>
                <input type="text" name="pn_city" value="<?php echo esc_attr($city); ?>" placeholder="Orlando">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Date of Birth', 'prepsnext' ); ?></label>
                <input type="date" name="pn_dob" value="<?php echo esc_attr($dob); ?>">
            </div>
            <div class="pn-meta-field">
                <label>📧 <?php _e( 'Contact Email', 'prepsnext' ); ?><span class="pn-hint"><?php _e('Shown on profile','prepsnext'); ?></span></label>
                <input type="email" name="pn_contact_email" value="<?php echo esc_attr($contact_email); ?>" placeholder="athlete@example.com">
            </div>
            <div class="pn-meta-field">
                <label>📞 <?php _e( 'Contact Phone', 'prepsnext' ); ?><span class="pn-hint"><?php _e('Shown on profile','prepsnext'); ?></span></label>
                <input type="text" name="pn_contact_phone" value="<?php echo esc_attr($contact_phone); ?>" placeholder="(407) 555-0123">
            </div>
        </div>
        <div class="pn-meta-field pn-full-width">
            <label><?php _e( 'Player Bio / About', 'prepsnext' ); ?></label>
            <textarea name="pn_bio" rows="5" placeholder="Short biography about the athlete..."><?php echo esc_textarea($bio); ?></textarea>
        </div>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'Headshot / Portrait Photo', 'prepsnext' ); ?></label>
                <div class="pn-image-upload" data-field="pn_headshot_id">
                    <input type="hidden" name="pn_headshot_id" value="<?php echo esc_attr($headshot); ?>">
                    <div class="pn-image-preview">
                        <?php if ($headshot): $url = wp_get_attachment_image_url($headshot,'medium'); ?>
                            <img src="<?php echo esc_url($url); ?>" alt="">
                            <button type="button" class="pn-remove-image button"><?php _e('Remove','prepsnext'); ?></button>
                        <?php else: ?>
                            <button type="button" class="pn-upload-image button button-primary"><?php _e('Upload Headshot','prepsnext'); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Hero / Action Photo (Main Profile Image)', 'prepsnext' ); ?></label>
                <p class="pn-hint"><?php _e('This large action shot appears on the profile card.','prepsnext'); ?></p>
                <div class="pn-image-upload" data-field="pn_action_image_id">
                    <input type="hidden" name="pn_action_image_id" value="<?php echo esc_attr($action_img); ?>">
                    <div class="pn-image-preview">
                        <?php if ($action_img): $url = wp_get_attachment_image_url($action_img,'medium'); ?>
                            <img src="<?php echo esc_url($url); ?>" alt="">
                            <button type="button" class="pn-remove-image button"><?php _e('Remove','prepsnext'); ?></button>
                        <?php else: ?>
                            <button type="button" class="pn-upload-image button button-primary"><?php _e('Upload Action Image','prepsnext'); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // ─── School Info ─────────────────────────────────────────────────────────

    public function render_school_box( $post ) {
        $school      = get_post_meta( $post->ID, '_pn_school_name', true );
        $school_loc  = get_post_meta( $post->ID, '_pn_school_location', true );
        $school_logo = get_post_meta( $post->ID, '_pn_school_logo_id', true );
        $jersey      = get_post_meta( $post->ID, '_pn_jersey_number', true );
        $positions   = get_post_meta( $post->ID, '_pn_positions', true );
        $team_name   = get_post_meta( $post->ID, '_pn_team_name', true );
        $conference  = get_post_meta( $post->ID, '_pn_conference', true );
        $division    = get_post_meta( $post->ID, '_pn_division', true );
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'School Name', 'prepsnext' ); ?></label>
                <input type="text" name="pn_school_name" value="<?php echo esc_attr($school); ?>" placeholder="Mainland High School">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'School Location', 'prepsnext' ); ?><span class="pn-hint">(City, State)</span></label>
                <input type="text" name="pn_school_location" value="<?php echo esc_attr($school_loc); ?>" placeholder="Daytona Beach, FL">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Team Name', 'prepsnext' ); ?></label>
                <input type="text" name="pn_team_name" value="<?php echo esc_attr($team_name); ?>" placeholder="Mainland Buccaneers">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Jersey Number', 'prepsnext' ); ?></label>
                <input type="text" name="pn_jersey_number" value="<?php echo esc_attr($jersey); ?>" placeholder="#1">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Position(s)', 'prepsnext' ); ?><span class="pn-hint">(comma separated)</span></label>
                <input type="text" name="pn_positions" value="<?php echo esc_attr($positions); ?>" placeholder="PG, SG">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Conference', 'prepsnext' ); ?></label>
                <input type="text" name="pn_conference" value="<?php echo esc_attr($conference); ?>" placeholder="District 3">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Division / Class', 'prepsnext' ); ?></label>
                <input type="text" name="pn_division" value="<?php echo esc_attr($division); ?>" placeholder="Class 8A">
            </div>
        </div>
        <div class="pn-meta-field">
            <label><?php _e( 'School Logo / Mascot Image', 'prepsnext' ); ?></label>
            <div class="pn-image-upload" data-field="pn_school_logo_id">
                <input type="hidden" name="pn_school_logo_id" value="<?php echo esc_attr($school_logo); ?>">
                <div class="pn-image-preview">
                    <?php if ($school_logo): $url = wp_get_attachment_image_url($school_logo,'thumbnail'); ?>
                        <img src="<?php echo esc_url($url); ?>" alt="">
                        <button type="button" class="pn-remove-image button"><?php _e('Remove','prepsnext'); ?></button>
                    <?php else: ?>
                        <button type="button" class="pn-upload-image button button-primary"><?php _e('Upload School Logo','prepsnext'); ?></button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    // ─── Measurements ────────────────────────────────────────────────────────

    public function render_measurements_box( $post ) {
        $height    = get_post_meta( $post->ID, '_pn_height', true );
        $weight    = get_post_meta( $post->ID, '_pn_weight', true );
        $wingspan  = get_post_meta( $post->ID, '_pn_wingspan', true );
        $hand_size = get_post_meta( $post->ID, '_pn_hand_size', true );
        $dom_hand  = get_post_meta( $post->ID, '_pn_dominant_hand', true );
        $dom_foot  = get_post_meta( $post->ID, '_pn_dominant_foot', true );
        $vert      = get_post_meta( $post->ID, '_pn_vertical', true );
        $forty     = get_post_meta( $post->ID, '_pn_forty_time', true );
        $bench     = get_post_meta( $post->ID, '_pn_bench_press', true );
        $shuttle   = get_post_meta( $post->ID, '_pn_shuttle', true );
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'Height', 'prepsnext' ); ?></label>
                <input type="text" name="pn_height" value="<?php echo esc_attr($height); ?>" placeholder='6&apos;4"'>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Weight (lbs)', 'prepsnext' ); ?></label>
                <input type="text" name="pn_weight" value="<?php echo esc_attr($weight); ?>" placeholder="175 lbs">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Wingspan', 'prepsnext' ); ?></label>
                <input type="text" name="pn_wingspan" value="<?php echo esc_attr($wingspan); ?>" placeholder='6&apos;8"'>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Hand Size', 'prepsnext' ); ?></label>
                <input type="text" name="pn_hand_size" value="<?php echo esc_attr($hand_size); ?>" placeholder='9.5"'>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Dominant Hand', 'prepsnext' ); ?></label>
                <select name="pn_dominant_hand">
                    <option value=""      <?php selected($dom_hand,''); ?>><?php _e('Select','prepsnext'); ?></option>
                    <option value="Right" <?php selected($dom_hand,'Right'); ?>><?php _e('Right','prepsnext'); ?></option>
                    <option value="Left"  <?php selected($dom_hand,'Left'); ?>><?php _e('Left','prepsnext'); ?></option>
                    <option value="Both"  <?php selected($dom_hand,'Both'); ?>><?php _e('Both / Ambidextrous','prepsnext'); ?></option>
                </select>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Dominant Foot', 'prepsnext' ); ?></label>
                <select name="pn_dominant_foot">
                    <option value=""      <?php selected($dom_foot,''); ?>><?php _e('Select','prepsnext'); ?></option>
                    <option value="Right" <?php selected($dom_foot,'Right'); ?>><?php _e('Right','prepsnext'); ?></option>
                    <option value="Left"  <?php selected($dom_foot,'Left'); ?>><?php _e('Left','prepsnext'); ?></option>
                    <option value="Both"  <?php selected($dom_foot,'Both'); ?>><?php _e('Both / Ambidextrous','prepsnext'); ?></option>
                </select>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Vertical Leap', 'prepsnext' ); ?></label>
                <input type="text" name="pn_vertical" value="<?php echo esc_attr($vert); ?>" placeholder='36"'>
            </div>
            <div class="pn-meta-field">
                <label><?php _e( '40-Yard Dash', 'prepsnext' ); ?><span class="pn-hint">(Football)</span></label>
                <input type="text" name="pn_forty_time" value="<?php echo esc_attr($forty); ?>" placeholder="4.42s">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Bench Press (reps)', 'prepsnext' ); ?></label>
                <input type="text" name="pn_bench_press" value="<?php echo esc_attr($bench); ?>" placeholder="225 lbs x 12">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Shuttle Run', 'prepsnext' ); ?></label>
                <input type="text" name="pn_shuttle" value="<?php echo esc_attr($shuttle); ?>" placeholder="4.12s">
            </div>
        </div>
        <?php
    }

    // ─── Academics ───────────────────────────────────────────────────────────

    public function render_academics_box( $post ) {
        $gpa         = get_post_meta( $post->ID, '_pn_gpa', true );
        $sat         = get_post_meta( $post->ID, '_pn_sat_score', true );
        $act         = get_post_meta( $post->ID, '_pn_act_score', true );
        $grad_year   = get_post_meta( $post->ID, '_pn_grad_year', true );
        $major       = get_post_meta( $post->ID, '_pn_intended_major', true );
        $ncaa_eli    = get_post_meta( $post->ID, '_pn_ncaa_eligible', true );
        $honors      = get_post_meta( $post->ID, '_pn_academic_honors', true );
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field">
                <label><?php _e( 'GPA', 'prepsnext' ); ?></label>
                <input type="text" name="pn_gpa" value="<?php echo esc_attr($gpa); ?>" placeholder="3.8">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'SAT Score', 'prepsnext' ); ?></label>
                <input type="text" name="pn_sat_score" value="<?php echo esc_attr($sat); ?>" placeholder="1250">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'ACT Score', 'prepsnext' ); ?></label>
                <input type="text" name="pn_act_score" value="<?php echo esc_attr($act); ?>" placeholder="26">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Graduation Year', 'prepsnext' ); ?></label>
                <input type="number" name="pn_grad_year" value="<?php echo esc_attr($grad_year); ?>" placeholder="2026" min="2020" max="2035">
            </div>
            <div class="pn-meta-field">
                <label><?php _e( 'Intended Major', 'prepsnext' ); ?></label>
                <input type="text" name="pn_intended_major" value="<?php echo esc_attr($major); ?>" placeholder="Business, Kinesiology...">
            </div>
            <div class="pn-meta-field">
                <label>
                    <input type="checkbox" name="pn_ncaa_eligible" value="1" <?php checked($ncaa_eli,'1'); ?>>
                    <?php _e( 'NCAA Cleared / Eligible', 'prepsnext' ); ?>
                </label>
            </div>
        </div>
        <div class="pn-meta-field pn-full-width">
            <label><?php _e( 'Academic Honors / Awards', 'prepsnext' ); ?></label>
            <textarea name="pn_academic_honors" rows="3" placeholder="Honor Roll, National Honor Society..."><?php echo esc_textarea($honors); ?></textarea>
        </div>
        <?php
    }

    // ─── Career History ──────────────────────────────────────────────────────

    public function render_career_box( $post ) {
        $seasons = get_post_meta( $post->ID, '_pn_seasons', true );
        if ( ! is_array( $seasons ) ) {
            $seasons = [];
        }
        ?>
        <p class="pn-hint"><?php _e('Add one row per season/year. Drag to reorder.','prepsnext'); ?></p>
        <div id="pn-seasons-wrap">
            <?php foreach ( $seasons as $i => $season ) :
                $this->render_season_row( $i, $season );
            endforeach; ?>
        </div>
        <button type="button" id="pn-add-season" class="button button-primary">
            + <?php _e('Add Season','prepsnext'); ?>
        </button>
        <script type="text/template" id="pn-season-template">
            <?php $this->render_season_row( '{{INDEX}}', [] ); ?>
        </script>
        <?php
    }

    private function render_season_row( $i, $data ) {
        $year      = $data['year']       ?? '';
        $grade     = $data['grade']      ?? '';
        $school    = $data['school']     ?? '';
        $location  = $data['location']   ?? '';
        $position  = $data['position']   ?? '';
        $jersey    = $data['jersey']     ?? '';
        $height    = $data['height']     ?? '';
        $weight    = $data['weight']     ?? '';
        $record_w  = $data['record_w']   ?? '';
        $record_l  = $data['record_l']   ?? '';
        $league    = $data['league']     ?? '';
        $nat_rank  = $data['nat_rank']   ?? '';
        $state_rank= $data['state_rank'] ?? '';
        $notes     = $data['notes']      ?? '';
        ?>
        <div class="pn-season-row" data-index="<?php echo esc_attr($i); ?>">
            <div class="pn-season-header">
                <span class="pn-drag-handle">☰</span>
                <strong class="pn-season-title"><?php echo $grade ? esc_html($grade.' '.$year) : __('New Season','prepsnext'); ?></strong>
                <button type="button" class="pn-toggle-season button button-small">▼</button>
                <button type="button" class="pn-remove-season button button-small pn-danger">✕ <?php _e('Remove','prepsnext'); ?></button>
            </div>
            <div class="pn-season-body pn-meta-grid">
                <div class="pn-meta-field">
                    <label><?php _e('Year','prepsnext'); ?></label>
                    <input type="number" name="pn_seasons[<?php echo $i; ?>][year]" value="<?php echo esc_attr($year); ?>" placeholder="2024" min="2000" max="2035">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Grade Level','prepsnext'); ?></label>
                    <select name="pn_seasons[<?php echo $i; ?>][grade]">
                        <option value=""         <?php selected($grade,''); ?>><?php _e('Select','prepsnext'); ?></option>
                        <option value="Freshman"  <?php selected($grade,'Freshman'); ?>>Freshman</option>
                        <option value="Sophomore" <?php selected($grade,'Sophomore'); ?>>Sophomore</option>
                        <option value="Junior"    <?php selected($grade,'Junior'); ?>>Junior</option>
                        <option value="Senior"    <?php selected($grade,'Senior'); ?>>Senior</option>
                        <option value="Post-Grad" <?php selected($grade,'Post-Grad'); ?>>Post-Grad</option>
                    </select>
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('School Name','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][school]" value="<?php echo esc_attr($school); ?>" placeholder="Sierra Canyon">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('School Location','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][location]" value="<?php echo esc_attr($location); ?>" placeholder="Chatsworth, CA">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Position(s)','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][position]" value="<?php echo esc_attr($position); ?>" placeholder="SG, PG">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Jersey #','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][jersey]" value="<?php echo esc_attr($jersey); ?>" placeholder="#0">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Height','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][height]" value="<?php echo esc_attr($height); ?>" placeholder='6&apos;3"'>
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Weight (lbs)','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][weight]" value="<?php echo esc_attr($weight); ?>" placeholder="175">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Record (W)','prepsnext'); ?></label>
                    <input type="number" name="pn_seasons[<?php echo $i; ?>][record_w]" value="<?php echo esc_attr($record_w); ?>" placeholder="26" min="0">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('Record (L)','prepsnext'); ?></label>
                    <input type="number" name="pn_seasons[<?php echo $i; ?>][record_l]" value="<?php echo esc_attr($record_l); ?>" placeholder="5" min="0">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('League Record','prepsnext'); ?><span class="pn-hint">(e.g. 6-0, 1st)</span></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][league]" value="<?php echo esc_attr($league); ?>" placeholder="League: 6-0 (1st)">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('National Rank','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][nat_rank]" value="<?php echo esc_attr($nat_rank); ?>" placeholder="#2">
                </div>
                <div class="pn-meta-field">
                    <label><?php _e('State Rank','prepsnext'); ?></label>
                    <input type="text" name="pn_seasons[<?php echo $i; ?>][state_rank]" value="<?php echo esc_attr($state_rank); ?>" placeholder="#4">
                </div>
                <div class="pn-meta-field pn-full-width">
                    <label><?php _e('Season Notes','prepsnext'); ?></label>
                    <textarea name="pn_seasons[<?php echo $i; ?>][notes]" rows="2" placeholder="Any notable achievements..."><?php echo esc_textarea($notes); ?></textarea>
                </div>
            </div>
        </div>
        <?php
    }

    // ─── Stats ───────────────────────────────────────────────────────────────

    public function render_stats_box( $post ) {
        $sport = '';
        $terms = get_the_terms( $post->ID, 'pn_sport' );
        if ( $terms && ! is_wp_error($terms) ) $sport = strtolower($terms[0]->slug);

        $stats = get_post_meta( $post->ID, '_pn_stats', true );
        if ( ! is_array($stats) ) $stats = [];
        ?>
        <p class="pn-hint"><?php _e('Enter career averages or per-game stats. Leave blank if not applicable.','prepsnext'); ?></p>

        <h4 style="margin:10px 0 6px"><?php _e('🏀 Basketball Stats','prepsnext'); ?></h4>
        <div class="pn-meta-grid">
            <?php foreach (['ppg'=>'PPG','rpg'=>'RPG','apg'=>'APG','spg'=>'SPG','bpg'=>'BPG','fg_pct'=>'FG%','three_pct'=>'3P%','ft_pct'=>'FT%','gp'=>'Games Played'] as $k => $label): ?>
            <div class="pn-meta-field">
                <label><?php echo esc_html($label); ?></label>
                <input type="text" name="pn_stats[<?php echo $k; ?>]" value="<?php echo esc_attr($stats[$k] ?? ''); ?>" placeholder="—">
            </div>
            <?php endforeach; ?>
        </div>

        <h4 style="margin:14px 0 6px"><?php _e('🏈 Football Stats','prepsnext'); ?></h4>
        <div class="pn-meta-grid">
            <?php foreach (['pass_yards'=>'Pass Yds','pass_tds'=>'Pass TDs','rush_yards'=>'Rush Yds','rush_tds'=>'Rush TDs','rec_yards'=>'Rec Yds','rec_tds'=>'Rec TDs','tackles'=>'Tackles','sacks'=>'Sacks','ints'=>'INTs','ff'=>'Forced Fumbles'] as $k => $label): ?>
            <div class="pn-meta-field">
                <label><?php echo esc_html($label); ?></label>
                <input type="text" name="pn_stats[<?php echo $k; ?>]" value="<?php echo esc_attr($stats[$k] ?? ''); ?>" placeholder="—">
            </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    // ─── Recruiting ──────────────────────────────────────────────────────────

    public function render_recruiting_box( $post ) {
        $offers         = get_post_meta( $post->ID, '_pn_college_offers', true );
        $interests      = get_post_meta( $post->ID, '_pn_college_interests', true );
        $committed_to   = get_post_meta( $post->ID, '_pn_committed_to', true );
        $committed_date = get_post_meta( $post->ID, '_pn_committed_date', true );
        $signed         = get_post_meta( $post->ID, '_pn_signed', true );
        $nli_date       = get_post_meta( $post->ID, '_pn_nli_date', true );
        $recruiting_profile = get_post_meta( $post->ID, '_pn_recruiting_profile_url', true );

        // College logos (up to 8)
        $college_logos = get_post_meta( $post->ID, '_pn_college_logos', true );
        if ( ! is_array($college_logos) ) $college_logos = [];
        ?>
        <div class="pn-meta-grid">
            <div class="pn-meta-field pn-full-width">
                <label><?php _e('Scholarship Offers (one per line)','prepsnext'); ?></label>
                <textarea name="pn_college_offers" rows="4" placeholder="University of Florida&#10;Florida State&#10;Miami"><?php echo esc_textarea(is_array($offers) ? implode("\n",$offers) : $offers); ?></textarea>
            </div>
            <div class="pn-meta-field pn-full-width">
                <label><?php _e('College Interests / Visits (one per line)','prepsnext'); ?></label>
                <textarea name="pn_college_interests" rows="4" placeholder="UCF&#10;Notre Dame"><?php echo esc_textarea(is_array($interests) ? implode("\n",$interests) : $interests); ?></textarea>
            </div>
            <div class="pn-meta-field">
                <label><?php _e('Committed To','prepsnext'); ?></label>
                <input type="text" name="pn_committed_to" value="<?php echo esc_attr($committed_to); ?>" placeholder="University of...">
            </div>
            <div class="pn-meta-field">
                <label><?php _e('Commitment Date','prepsnext'); ?></label>
                <input type="date" name="pn_committed_date" value="<?php echo esc_attr($committed_date); ?>">
            </div>
            <div class="pn-meta-field">
                <label>
                    <input type="checkbox" name="pn_signed" value="1" <?php checked($signed,'1'); ?>>
                    <?php _e('Signed NLI','prepsnext'); ?>
                </label>
            </div>
            <div class="pn-meta-field">
                <label><?php _e('NLI Signing Date','prepsnext'); ?></label>
                <input type="date" name="pn_nli_date" value="<?php echo esc_attr($nli_date); ?>">
            </div>
            <div class="pn-meta-field pn-full-width">
                <label><?php _e('Recruiting Profile URL','prepsnext'); ?><span class="pn-hint">(247Sports, Rivals, ESPN, etc.)</span></label>
                <input type="url" name="pn_recruiting_profile_url" value="<?php echo esc_attr($recruiting_profile); ?>" placeholder="https://247sports.com/player/...">
            </div>
        </div>

        <h4 style="margin:14px 0 6px"><?php _e('College Interest Logos (up to 8)','prepsnext'); ?></h4>
        <p class="pn-hint"><?php _e('Upload logos that appear in the "School Interests" section of the profile card.','prepsnext'); ?></p>
        <div class="pn-college-logos-grid" id="pn-college-logos">
            <?php for ($j = 0; $j < 8; $j++):
                $logo_id  = $college_logos[$j]['id']   ?? '';
                $logo_name= $college_logos[$j]['name'] ?? '';
                ?>
                <div class="pn-college-logo-item">
                    <div class="pn-image-upload" data-field="pn_college_logos[<?php echo $j; ?>][id]">
                        <input type="hidden" name="pn_college_logos[<?php echo $j; ?>][id]" value="<?php echo esc_attr($logo_id); ?>">
                        <div class="pn-image-preview">
                            <?php if ($logo_id): $url = wp_get_attachment_image_url($logo_id,'thumbnail'); ?>
                                <img src="<?php echo esc_url($url); ?>" alt="">
                                <button type="button" class="pn-remove-image button"><?php _e('✕','prepsnext'); ?></button>
                            <?php else: ?>
                                <button type="button" class="pn-upload-image button"><?php _e('+ Logo','prepsnext'); ?></button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <input type="text" name="pn_college_logos[<?php echo $j; ?>][name]" value="<?php echo esc_attr($logo_name); ?>" placeholder="College name">
                </div>
            <?php endfor; ?>
        </div>
        <?php
    }

    // ─── Media Gallery ───────────────────────────────────────────────────────

    public function render_media_box( $post ) {
        $gallery = get_post_meta( $post->ID, '_pn_media_gallery', true );
        if ( ! is_array($gallery) ) $gallery = [];
        ?>
        <p class="pn-hint"><?php _e('Add photos and videos. Videos can be YouTube/Vimeo embeds or direct URLs. Drag to reorder.','prepsnext'); ?></p>
        <div id="pn-media-gallery">
            <?php foreach ( $gallery as $mi => $item ) : ?>
            <div class="pn-media-item" data-index="<?php echo $mi; ?>">
                <?php $this->render_media_item( $mi, $item ); ?>
            </div>
            <?php endforeach; ?>
        </div>
        <button type="button" id="pn-add-media-item" class="button button-primary">
            + <?php _e('Add Photo / Video','prepsnext'); ?>
        </button>
        <script type="text/template" id="pn-media-item-template">
            <?php $this->render_media_item('{{INDEX}}', []); ?>
        </script>
        <?php
    }

    private function render_media_item( $i, $data ) {
        $type       = $data['type']       ?? 'photo';
        $image_id   = $data['image_id']   ?? '';
        $video_url  = $data['video_url']  ?? '';
        $thumbnail_id = $data['thumbnail_id'] ?? '';
        $title      = $data['title']      ?? '';
        $views      = $data['views']      ?? '';
        $featured   = $data['featured']   ?? '';
        ?>
        <div class="pn-media-inner pn-meta-grid">
            <span class="pn-drag-handle">☰</span>
            <div class="pn-meta-field">
                <label><?php _e('Type','prepsnext'); ?></label>
                <select name="pn_media_gallery[<?php echo $i; ?>][type]" class="pn-media-type-select">
                    <option value="photo" <?php selected($type,'photo'); ?>><?php _e('Photo','prepsnext'); ?></option>
                    <option value="video" <?php selected($type,'video'); ?>><?php _e('Video','prepsnext'); ?></option>
                </select>
            </div>
            <div class="pn-meta-field">
                <label><?php _e('Title / Label','prepsnext'); ?></label>
                <input type="text" name="pn_media_gallery[<?php echo $i; ?>][title]" value="<?php echo esc_attr($title); ?>" placeholder="Guard Battle, Mixtape...">
            </div>
            <div class="pn-meta-field">
                <label><?php _e('View Count','prepsnext'); ?><span class="pn-hint">(e.g. 32.2K)</span></label>
                <input type="text" name="pn_media_gallery[<?php echo $i; ?>][views]" value="<?php echo esc_attr($views); ?>" placeholder="32.2K">
            </div>
            <div class="pn-meta-field pn-media-photo-field">
                <label><?php _e('Photo / Thumbnail','prepsnext'); ?></label>
                <div class="pn-image-upload" data-field="pn_media_gallery[<?php echo $i; ?>][image_id]">
                    <input type="hidden" name="pn_media_gallery[<?php echo $i; ?>][image_id]" value="<?php echo esc_attr($image_id); ?>">
                    <div class="pn-image-preview">
                        <?php if ($image_id): $url = wp_get_attachment_image_url($image_id,'thumbnail'); ?>
                            <img src="<?php echo esc_url($url); ?>" alt="">
                            <button type="button" class="pn-remove-image button">✕</button>
                        <?php else: ?>
                            <button type="button" class="pn-upload-image button">+ <?php _e('Upload','prepsnext'); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="pn-meta-field pn-media-video-field">
                <label><?php _e('Video URL','prepsnext'); ?><span class="pn-hint">(YouTube, Vimeo, or direct MP4)</span></label>
                <input type="url" name="pn_media_gallery[<?php echo $i; ?>][video_url]" value="<?php echo esc_attr($video_url); ?>" placeholder="https://youtube.com/watch?v=...">
            </div>
            <div class="pn-meta-field">
                <label>
                    <input type="checkbox" name="pn_media_gallery[<?php echo $i; ?>][featured]" value="1" <?php checked($featured,'1'); ?>>
                    <?php _e('Featured (shows first)','prepsnext'); ?>
                </label>
            </div>
            <div class="pn-meta-field">
                <button type="button" class="pn-remove-media-item button pn-danger">✕ <?php _e('Remove','prepsnext'); ?></button>
            </div>
        </div>
        <?php
    }

    // ─── Social Media ────────────────────────────────────────────────────────

    public function render_social_box( $post ) {
        $socials = [
            'instagram'  => [ 'label' => 'Instagram',       'icon' => '📸', 'placeholder' => 'https://instagram.com/username' ],
            'twitter'    => [ 'label' => 'Twitter / X',     'icon' => '🐦', 'placeholder' => 'https://twitter.com/username' ],
            'tiktok'     => [ 'label' => 'TikTok',          'icon' => '🎵', 'placeholder' => 'https://tiktok.com/@username' ],
            'youtube'    => [ 'label' => 'YouTube',         'icon' => '▶️', 'placeholder' => 'https://youtube.com/@channel' ],
            'facebook'   => [ 'label' => 'Facebook',        'icon' => '👍', 'placeholder' => 'https://facebook.com/profile' ],
            'hudl'       => [ 'label' => 'Hudl',            'icon' => '🎥', 'placeholder' => 'https://hudl.com/profile/...' ],
            'rivals'     => [ 'label' => 'Rivals Profile',  'icon' => '🏆', 'placeholder' => 'https://rivals.com/...' ],
            'twofour7'   => [ 'label' => '247Sports',       'icon' => '📊', 'placeholder' => 'https://247sports.com/player/...' ],
            'espn'       => [ 'label' => 'ESPN Recruiting', 'icon' => '📡', 'placeholder' => 'https://espn.com/...' ],
            'on3'        => [ 'label' => 'On3',             'icon' => '3️⃣', 'placeholder' => 'https://on3.com/...' ],
        ];
        ?>
        <div class="pn-meta-grid">
            <?php foreach ( $socials as $key => $info ):
                $val = get_post_meta( $post->ID, '_pn_social_' . $key, true );
                ?>
                <div class="pn-meta-field">
                    <label><?php echo esc_html($info['icon'] . ' ' . $info['label']); ?></label>
                    <input type="url" name="pn_social_<?php echo esc_attr($key); ?>"
                           value="<?php echo esc_attr($val); ?>"
                           placeholder="<?php echo esc_attr($info['placeholder']); ?>">
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    // ─── Related Blog Posts ──────────────────────────────────────────────────

    public function render_related_box( $post ) {
        $related_ids = get_post_meta( $post->ID, '_pn_related_posts', true );
        if ( ! is_array($related_ids) ) $related_ids = [];
        $athlete_tag = get_post_meta( $post->ID, '_pn_athlete_tag', true );
        ?>
        <div class="pn-meta-field">
            <label><?php _e('Athlete Tag Slug','prepsnext'); ?>
                <span class="pn-hint"><?php _e('Blog posts tagged with this slug will auto-link to this profile.','prepsnext'); ?></span>
            </label>
            <input type="text" name="pn_athlete_tag" value="<?php echo esc_attr($athlete_tag); ?>" placeholder="reese-savage">
        </div>
        <div class="pn-meta-field pn-full-width" style="margin-top:12px;">
            <label><?php _e('Manually Link Blog Posts (IDs or search below)','prepsnext'); ?></label>
            <div id="pn-related-posts">
                <?php foreach ( $related_ids as $rid ) :
                    $rtitle = get_the_title($rid);
                    if (!$rtitle) continue;
                    ?>
                    <div class="pn-related-post-item">
                        <input type="hidden" name="pn_related_posts[]" value="<?php echo esc_attr($rid); ?>">
                        <span><?php echo esc_html($rtitle); ?> (ID: <?php echo esc_html($rid); ?>)</span>
                        <button type="button" class="pn-remove-related button button-small pn-danger">✕</button>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="pn-related-search" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                <input type="text" id="pn-related-search-input" placeholder="<?php _e('Search post title...','prepsnext'); ?>" style="flex:1;min-width:200px;">
                <button type="button" id="pn-related-search-btn" class="button"><?php _e('Search','prepsnext'); ?></button>
            </div>
            <div id="pn-related-search-results" style="margin-top:8px;"></div>
        </div>
        <?php
    }

    // ─── Save Meta ───────────────────────────────────────────────────────────

    public function save_meta( $post_id, $post ) {
        // Verify nonce
        if ( ! isset( $_POST['pn_meta_nonce'] ) || ! wp_verify_nonce( $_POST['pn_meta_nonce'], 'pn_save_meta' ) ) return;
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Simple text fields
        $text_fields = [
            'pn_prospect_status', 'pn_national_rank', 'pn_state_rank', 'pn_position_rank',
            'pn_rank_label', 'pn_watchlist_rank', 'pn_watchlist_label',
            'pn_first_name', 'pn_last_name', 'pn_city', 'pn_dob', 'pn_bio',
            // ── Contact ──────────────────────────────────────────────
            'pn_contact_email', 'pn_contact_phone',
            // ── School / Team ────────────────────────────────────────
            'pn_school_name', 'pn_school_location', 'pn_team_name', 'pn_jersey_number',
            'pn_positions', 'pn_conference', 'pn_division',
            'pn_height', 'pn_weight', 'pn_wingspan', 'pn_hand_size',
            'pn_dominant_hand', 'pn_dominant_foot', 'pn_vertical', 'pn_forty_time',
            'pn_bench_press', 'pn_shuttle',
            'pn_gpa', 'pn_sat_score', 'pn_act_score', 'pn_grad_year',
            'pn_intended_major', 'pn_academic_honors',
            'pn_committed_to', 'pn_committed_date', 'pn_nli_date',
            'pn_recruiting_profile_url',
            'pn_athlete_tag',
        ];

        foreach ( $text_fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, '_' . $field, sanitize_text_field( $_POST[$field] ) );
            }
        }

        // Email gets proper email sanitisation (overwrite the text-field save above)
        if ( isset( $_POST['pn_contact_email'] ) ) {
            update_post_meta( $post_id, '_pn_contact_email', sanitize_email( $_POST['pn_contact_email'] ) );
        }

        // Checkbox fields
        $checkbox_fields = ['pn_stock_riser', 'pn_ncaa_eligible', 'pn_signed'];
        foreach ( $checkbox_fields as $field ) {
            update_post_meta( $post_id, '_' . $field, isset($_POST[$field]) ? '1' : '' );
        }

        // Textarea fields
        $textarea_fields = ['pn_bio', 'pn_academic_honors'];
        foreach ( $textarea_fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, '_' . $field, sanitize_textarea_field( $_POST[$field] ) );
            }
        }

        // Image ID fields
        $image_fields = ['pn_headshot_id', 'pn_action_image_id', 'pn_school_logo_id'];
        foreach ( $image_fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, '_' . $field, absint( $_POST[$field] ) );
            }
        }

        // College offers / interests (textarea → array)
        foreach ( ['pn_college_offers', 'pn_college_interests'] as $field ) {
            if ( isset( $_POST[$field] ) ) {
                $lines = array_filter( array_map( 'sanitize_text_field', explode("\n", $_POST[$field]) ) );
                update_post_meta( $post_id, '_' . $field, array_values($lines) );
            }
        }

        // Social media URLs
        $social_keys = ['instagram','twitter','tiktok','youtube','facebook','hudl','rivals','twofour7','espn','on3'];
        foreach ( $social_keys as $sk ) {
            if ( isset( $_POST['pn_social_' . $sk] ) ) {
                update_post_meta( $post_id, '_pn_social_' . $sk, esc_url_raw( $_POST['pn_social_' . $sk] ) );
            }
        }

        // Seasons
        if ( isset( $_POST['pn_seasons'] ) && is_array( $_POST['pn_seasons'] ) ) {
            $seasons = [];
            foreach ( $_POST['pn_seasons'] as $s ) {
                $seasons[] = [
                    'year'       => sanitize_text_field( $s['year']       ?? '' ),
                    'grade'      => sanitize_text_field( $s['grade']      ?? '' ),
                    'school'     => sanitize_text_field( $s['school']     ?? '' ),
                    'location'   => sanitize_text_field( $s['location']   ?? '' ),
                    'position'   => sanitize_text_field( $s['position']   ?? '' ),
                    'jersey'     => sanitize_text_field( $s['jersey']     ?? '' ),
                    'height'     => sanitize_text_field( $s['height']     ?? '' ),
                    'weight'     => sanitize_text_field( $s['weight']     ?? '' ),
                    'record_w'   => absint( $s['record_w']  ?? 0 ),
                    'record_l'   => absint( $s['record_l']  ?? 0 ),
                    'league'     => sanitize_text_field( $s['league']     ?? '' ),
                    'nat_rank'   => sanitize_text_field( $s['nat_rank']   ?? '' ),
                    'state_rank' => sanitize_text_field( $s['state_rank'] ?? '' ),
                    'notes'      => sanitize_textarea_field( $s['notes']  ?? '' ),
                ];
            }
            update_post_meta( $post_id, '_pn_seasons', $seasons );
        }

        // Stats
        if ( isset( $_POST['pn_stats'] ) && is_array( $_POST['pn_stats'] ) ) {
            $stats = array_map( 'sanitize_text_field', $_POST['pn_stats'] );
            update_post_meta( $post_id, '_pn_stats', $stats );
        }

        // Media gallery
        if ( isset( $_POST['pn_media_gallery'] ) && is_array( $_POST['pn_media_gallery'] ) ) {
            $gallery = [];
            foreach ( $_POST['pn_media_gallery'] as $item ) {
                $gallery[] = [
                    'type'         => sanitize_text_field( $item['type']         ?? 'photo' ),
                    'image_id'     => absint( $item['image_id']     ?? 0 ),
                    'video_url'    => esc_url_raw( $item['video_url']    ?? '' ),
                    'title'        => sanitize_text_field( $item['title']        ?? '' ),
                    'views'        => sanitize_text_field( $item['views']        ?? '' ),
                    'featured'     => isset($item['featured']) ? '1' : '',
                ];
            }
            update_post_meta( $post_id, '_pn_media_gallery', $gallery );
        }

        // College logos
        if ( isset( $_POST['pn_college_logos'] ) && is_array( $_POST['pn_college_logos'] ) ) {
            $logos = [];
            foreach ( $_POST['pn_college_logos'] as $logo ) {
                $logos[] = [
                    'id'   => absint( $logo['id']   ?? 0 ),
                    'name' => sanitize_text_field( $logo['name'] ?? '' ),
                ];
            }
            update_post_meta( $post_id, '_pn_college_logos', $logos );
        }

        // Related posts
        if ( isset( $_POST['pn_related_posts'] ) && is_array( $_POST['pn_related_posts'] ) ) {
            $related = array_map( 'absint', $_POST['pn_related_posts'] );
            update_post_meta( $post_id, '_pn_related_posts', array_filter($related) );
        } else {
            update_post_meta( $post_id, '_pn_related_posts', [] );
        }
    }
}
