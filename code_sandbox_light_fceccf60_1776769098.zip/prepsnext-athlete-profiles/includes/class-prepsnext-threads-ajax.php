<?php
/**
 * PrepsNext Threads — AJAX Endpoints
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PrepsNext_Threads_Ajax {

    private static $instance = null;
    public static function instance() {
        if ( is_null( self::$instance ) ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $actions = [
            'pn_post_thread',       'pn_delete_thread',
            'pn_post_comment',      'pn_delete_comment',
            'pn_toggle_like',       'pn_toggle_repost',
            'pn_toggle_follow',     'pn_get_feed',
            'pn_get_notifications', 'pn_mark_notifs_read',
            'pn_upload_thread_img', 'pn_get_thread_detail',
            'pn_get_profile_threads',
        ];
        foreach ( $actions as $action ) {
            add_action( 'wp_ajax_' . $action, [ $this, $action ] );
        }
        // Public (non-logged-in) — read only
        add_action( 'wp_ajax_nopriv_pn_get_feed',            [ $this, 'pn_get_feed' ] );
        add_action( 'wp_ajax_nopriv_pn_get_thread_detail',   [ $this, 'pn_get_thread_detail' ] );
        add_action( 'wp_ajax_nopriv_pn_get_profile_threads', [ $this, 'pn_get_profile_threads' ] );

        // Ticker — public, no nonce required (read-only, no sensitive data)
        add_action( 'wp_ajax_pn_get_ticker_slides',        [ $this, 'pn_get_ticker_slides' ] );
        add_action( 'wp_ajax_nopriv_pn_get_ticker_slides', [ $this, 'pn_get_ticker_slides' ] );

        // admin-post.php handlers for login & registration forms
        // (must use admin-post so wp_redirect can run before any output)
        add_action( 'admin_post_nopriv_pn_thread_login',    [ $this, 'handle_login' ] );
        add_action( 'admin_post_pn_thread_login',           [ $this, 'handle_login' ] );
        add_action( 'admin_post_nopriv_pn_thread_register', [ $this, 'handle_register' ] );
        add_action( 'admin_post_pn_thread_register',        [ $this, 'handle_register' ] );
    }

    /* ── Security helper ─────────────────────────────────────────── */
    private function check( $require_approved = true ) {
        if ( ! check_ajax_referer( 'pn_threads_nonce', 'nonce', false ) )
            wp_send_json_error( [ 'msg' => 'Invalid nonce.' ], 403 );
        if ( $require_approved && ! PrepsNext_Threads::current_user_approved() )
            wp_send_json_error( [ 'msg' => 'Account pending approval.' ], 403 );
    }

    /* ── POST THREAD ─────────────────────────────────────────────── */
    public function pn_post_thread() {
        $this->check();
        $uid      = get_current_user_id();
        $body     = sanitize_textarea_field( $_POST['body'] ?? '' );
        $sport    = sanitize_text_field( $_POST['sport_tag'] ?? '' );
        $repost   = absint( $_POST['repost_of'] ?? 0 );
        $quote_b  = sanitize_textarea_field( $_POST['quote_body'] ?? '' );

        if ( ! $body && ! $repost ) wp_send_json_error( [ 'msg' => 'Body required.' ] );
        if ( mb_strlen( $body ) > 500 ) wp_send_json_error( [ 'msg' => 'Max 500 characters.' ] );

        $media_url = ''; $media_type = 'none'; $media_w = null; $media_h = null;
        if ( ! empty( $_FILES['media'] ) && $_FILES['media']['error'] === UPLOAD_ERR_OK ) {
            $result = PrepsNext_Threads::handle_image_upload( $_FILES['media'] );
            if ( is_wp_error( $result ) ) wp_send_json_error( [ 'msg' => $result->get_error_message() ] );
            $media_url  = $result['url'];
            $media_type = 'image';
            $media_w    = $result['width'];
            $media_h    = $result['height'];
        }

        $thread_id = PrepsNext_Threads::create_thread( $uid, $body, $media_url, $media_type, $media_w, $media_h, $repost ?: null, $quote_b, $sport );
        $thread    = PrepsNext_Threads::get_thread( $thread_id );

        ob_start();
        PrepsNext_Threads::render_thread_card( $thread, $uid );
        $html = ob_get_clean();

        wp_send_json_success( [ 'html' => $html, 'thread_id' => $thread_id ] );
    }

    /* ── DELETE THREAD ───────────────────────────────────────────── */
    public function pn_delete_thread() {
        $this->check( false );
        if ( ! is_user_logged_in() ) wp_send_json_error( [ 'msg' => 'Not logged in.' ] );
        $id  = absint( $_POST['thread_id'] ?? 0 );
        $ok  = PrepsNext_Threads::delete_thread( $id, get_current_user_id() );
        $ok ? wp_send_json_success() : wp_send_json_error( [ 'msg' => 'Cannot delete.' ] );
    }

    /* ── POST COMMENT ────────────────────────────────────────────── */
    public function pn_post_comment() {
        $this->check();
        $uid      = get_current_user_id();
        $thread   = absint( $_POST['thread_id'] ?? 0 );
        $body     = sanitize_textarea_field( $_POST['body'] ?? '' );
        $parent   = absint( $_POST['parent_id'] ?? 0 ) ?: null;

        if ( ! $body ) wp_send_json_error( [ 'msg' => 'Body required.' ] );
        if ( mb_strlen( $body ) > 500 ) wp_send_json_error( [ 'msg' => 'Max 500 characters.' ] );

        $media_url = '';
        if ( ! empty( $_FILES['media'] ) && $_FILES['media']['error'] === UPLOAD_ERR_OK ) {
            $result = PrepsNext_Threads::handle_image_upload( $_FILES['media'] );
            if ( ! is_wp_error( $result ) ) $media_url = $result['url'];
        }

        $cid      = PrepsNext_Threads::create_comment( $thread, $uid, $body, $parent, $media_url );
        $comments = PrepsNext_Threads::get_comments( $thread );

        ob_start();
        PrepsNext_Threads::render_comments_section( $thread, $uid );
        $html = ob_get_clean();

        wp_send_json_success( [ 'html' => $html, 'comment_id' => $cid ] );
    }

    /* ── DELETE COMMENT ──────────────────────────────────────────── */
    public function pn_delete_comment() {
        $this->check( false );
        if ( ! is_user_logged_in() ) wp_send_json_error();
        $id = absint( $_POST['comment_id'] ?? 0 );
        $ok = PrepsNext_Threads::delete_comment( $id, get_current_user_id() );
        $ok ? wp_send_json_success() : wp_send_json_error();
    }

    /* ── TOGGLE LIKE ─────────────────────────────────────────────── */
    public function pn_toggle_like() {
        $this->check();
        $uid       = get_current_user_id();
        $item_id   = absint( $_POST['item_id'] ?? 0 );
        $item_type = in_array( $_POST['item_type'] ?? '', ['thread','comment'], true ) ? $_POST['item_type'] : 'thread';
        $result    = PrepsNext_Threads::toggle_like( $uid, $item_id, $item_type );
        wp_send_json_success( $result );
    }

    /* ── TOGGLE REPOST ───────────────────────────────────────────── */
    public function pn_toggle_repost() {
        $this->check();
        $uid       = get_current_user_id();
        $thread_id = absint( $_POST['thread_id'] ?? 0 );
        $quote     = sanitize_textarea_field( $_POST['quote_body'] ?? '' );

        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pn_thread_reposts WHERE user_id=%d AND thread_id=%d", $uid, $thread_id
        ));

        if ( $exists ) {
            // Undo repost — delete the repost thread
            $repost_post = $wpdb->get_row( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pn_threads WHERE user_id=%d AND repost_of=%d AND status='published'", $uid, $thread_id
            ));
            if ( $repost_post ) PrepsNext_Threads::delete_thread( $repost_post->id, $uid );
            $wpdb->delete( $wpdb->prefix . 'pn_thread_reposts', [ 'user_id' => $uid, 'thread_id' => $thread_id ] );
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}pn_threads SET repost_count = GREATEST(repost_count-1,0) WHERE id=%d", $thread_id
            ));
            $repost_count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT repost_count FROM {$wpdb->prefix}pn_threads WHERE id=%d", $thread_id
            ));
            wp_send_json_success( [ 'reposted' => false, 'count' => $repost_count ] );
        } else {
            // Create repost thread
            $new_id = PrepsNext_Threads::create_thread( $uid, $quote, '', 'none', null, null, $thread_id, $quote );
            $wpdb->insert( $wpdb->prefix . 'pn_thread_reposts', [ 'user_id' => $uid, 'thread_id' => $thread_id ] );
            $repost_count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT repost_count FROM {$wpdb->prefix}pn_threads WHERE id=%d", $thread_id
            ));
            wp_send_json_success( [ 'reposted' => true, 'count' => $repost_count ] );
        }
    }

    /* ── TOGGLE FOLLOW ───────────────────────────────────────────── */
    public function pn_toggle_follow() {
        $this->check();
        $follower  = get_current_user_id();
        $following = absint( $_POST['user_id'] ?? 0 );
        if ( ! $following || $following === $follower ) wp_send_json_error();
        $is_following = PrepsNext_Threads::toggle_follow( $follower, $following );
        $count        = PrepsNext_Threads::get_follower_count( $following );
        wp_send_json_success( [ 'following' => $is_following, 'count' => $count ] );
    }

    /* ── GET FEED (paginated) ────────────────────────────────────── */
    public function pn_get_feed() {
        check_ajax_referer( 'pn_threads_nonce', 'nonce' );
        $page   = absint( $_POST['page'] ?? 1 );
        $filter = sanitize_text_field( $_POST['filter'] ?? 'all' );
        $sport  = sanitize_text_field( $_POST['sport'] ?? '' );
        $uid    = get_current_user_id();

        $threads = PrepsNext_Threads::get_feed( $page, 20, $filter, $sport );
        if ( empty( $threads ) ) { wp_send_json_success( [ 'html' => '', 'has_more' => false ] ); return; }

        ob_start();
        foreach ( $threads as $t ) PrepsNext_Threads::render_thread_card( $t, $uid );
        $html = ob_get_clean();

        wp_send_json_success( [ 'html' => $html, 'has_more' => count( $threads ) === 20 ] );
    }

    /* ── GET THREAD DETAIL ───────────────────────────────────────── */
    public function pn_get_thread_detail() {
        check_ajax_referer( 'pn_threads_nonce', 'nonce' );
        $id     = absint( $_POST['thread_id'] ?? 0 );
        $uid    = get_current_user_id();
        $thread = PrepsNext_Threads::get_thread( $id );
        if ( ! $thread || $thread->status !== 'published' ) wp_send_json_error();

        ob_start();
        PrepsNext_Threads::render_thread_card( $thread, $uid, true );
        $html = ob_get_clean();
        wp_send_json_success( [ 'html' => $html ] );
    }

    /* ── GET PROFILE THREADS ─────────────────────────────────────── */
    public function pn_get_profile_threads() {
        check_ajax_referer( 'pn_threads_nonce', 'nonce' );
        $uid     = absint( $_POST['profile_uid'] ?? 0 );
        $page    = absint( $_POST['page'] ?? 1 );
        $type    = sanitize_text_field( $_POST['type'] ?? 'threads' ); // threads | reposts
        $me      = get_current_user_id();

        $threads = PrepsNext_Threads::get_user_threads( $uid, $page, 20, $type === 'reposts' );
        if ( empty( $threads ) ) { wp_send_json_success( [ 'html' => '', 'has_more' => false ] ); return; }

        ob_start();
        foreach ( $threads as $t ) PrepsNext_Threads::render_thread_card( $t, $me );
        $html = ob_get_clean();
        wp_send_json_success( [ 'html' => $html, 'has_more' => count( $threads ) === 20 ] );
    }

    /* ── NOTIFICATIONS ───────────────────────────────────────────── */
    public function pn_get_notifications() {
        $this->check( false );
        if ( ! is_user_logged_in() ) wp_send_json_error();
        $uid   = get_current_user_id();
        $notifs= PrepsNext_Threads::get_notifications( $uid );
        $icons = [ 'like'=>'❤️','comment'=>'💬','repost'=>'🔁','follow'=>'👤','mention'=>'@' ];
        $items = [];
        foreach ( $notifs as $n ) {
            $actor = PrepsNext_Threads::get_user_display( $n->actor_id );
            $items[] = [
                'icon'   => $icons[ $n->type ] ?? '🔔',
                'text'   => $actor['name'] . ' ' . self::notif_text( $n->type ),
                'time'   => PrepsNext_Threads::time_ago( $n->created_at ),
                'is_read'=> (bool) $n->is_read,
                'link'   => $n->item_type === 'thread' && $n->item_id ? home_url( '/prepsnext-feed/?thread=' . $n->item_id ) : '',
            ];
        }
        wp_send_json_success( $items );
    }

    public function pn_mark_notifs_read() {
        $this->check( false );
        if ( ! is_user_logged_in() ) wp_send_json_error();
        PrepsNext_Threads::mark_notifications_read( get_current_user_id() );
        wp_send_json_success();
    }

    /* ── IMAGE UPLOAD (standalone) ───────────────────────────────── */
    public function pn_upload_thread_img() {
        $this->check();
        if ( empty( $_FILES['file'] ) ) wp_send_json_error( [ 'msg' => 'No file.' ] );
        $result = PrepsNext_Threads::handle_image_upload( $_FILES['file'] );
        if ( is_wp_error( $result ) ) wp_send_json_error( [ 'msg' => $result->get_error_message() ] );
        wp_send_json_success( $result );
    }

    /* ── TICKER SLIDES ───────────────────────────────────────────── */

    public function pn_get_ticker_slides() {
        global $wpdb;
        $limit = min( absint( $_REQUEST['limit'] ?? 8 ), 20 );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pn_threads
             WHERE status = 'published' AND repost_of IS NULL
             ORDER BY created_at DESC
             LIMIT %d",
            $limit
        ) );

        if ( empty( $rows ) ) {
            wp_send_json_success( [ 'slides' => [] ] );
            return;
        }

        $slides = [];
        foreach ( $rows as $t ) {
            $user = PrepsNext_Threads::get_user_display( $t->user_id );

            // Truncate body for ticker
            $body = strip_tags( $t->body );
            $body = preg_replace( '/\s+/', ' ', $body );

            $slides[] = [
                'name'        => $user['name'],
                'avatar'      => $user['avatar'],
                'status'      => $user['status'],
                'profile_url' => $user['profile_url'],
                'body'        => $body,
                'link'        => home_url( '/prepsnext-feed/?thread=' . $t->id ),
                'time'        => PrepsNext_Threads::time_ago( $t->created_at ),
                'sport'       => $user['sport'],
            ];
        }

        wp_send_json_success( [ 'slides' => $slides ] );
    }

    /* ── LOGIN FORM HANDLER ──────────────────────────────────────── */

    public function handle_login() {
        $login_page = esc_url_raw( $_POST['login_page'] ?? home_url( '/prepsnext-login/' ) );
        $redirect   = esc_url_raw( $_POST['redirect_to'] ?? home_url( '/prepsnext-feed/' ) );

        if ( ! wp_verify_nonce( $_POST['pn_login_nonce'] ?? '', 'pn_thread_login' ) ) {
            wp_safe_redirect( add_query_arg( 'pn_login_error', 'nonce', $login_page ) );
            exit;
        }

        $creds = [
            'user_login'    => sanitize_text_field( $_POST['username'] ?? '' ),
            'user_password' => $_POST['password'] ?? '',
            'remember'      => ! empty( $_POST['remember'] ),
        ];
        $user = wp_signon( $creds, is_ssl() );

        if ( is_wp_error( $user ) ) {
            wp_safe_redirect( add_query_arg( [
                'pn_login_error' => 'invalid',
                'pn_login_user'  => rawurlencode( $creds['user_login'] ),
            ], $login_page ) );
            exit;
        }

        wp_safe_redirect( $redirect );
        exit;
    }

    /* ── REGISTER FORM HANDLER ───────────────────────────────────── */

    public function handle_register() {
        $reg_page = esc_url_raw( $_POST['register_page'] ?? home_url( '/prepsnext-register/' ) );

        if ( ! wp_verify_nonce( $_POST['pn_reg_nonce'] ?? '', 'pn_thread_register' ) ) {
            wp_safe_redirect( add_query_arg( 'pn_reg_error', 'nonce', $reg_page ) );
            exit;
        }

        $username  = sanitize_user( $_POST['username']  ?? '' );
        $email     = sanitize_email( $_POST['email']    ?? '' );
        $password  = $_POST['password']  ?? '';
        $password2 = $_POST['password2'] ?? '';
        $first     = sanitize_text_field( $_POST['first_name'] ?? '' );
        $last      = sanitize_text_field( $_POST['last_name']  ?? '' );
        $sport     = sanitize_text_field( $_POST['sport']      ?? '' );
        $agree     = ! empty( $_POST['agree'] );

        $params = [
            'pn_reg_first'    => rawurlencode( $first ),
            'pn_reg_last'     => rawurlencode( $last ),
            'pn_reg_username' => rawurlencode( $username ),
            'pn_reg_email'    => rawurlencode( $email ),
            'pn_reg_sport'    => rawurlencode( $sport ),
        ];

        $error = '';
        if ( ! $username )                      $error = 'username';
        elseif ( ! is_email( $email ) )         $error = 'email';
        elseif ( strlen( $password ) < 8 )      $error = 'password';
        elseif ( $password !== $password2 )     $error = 'match';
        elseif ( ! $first || ! $last )          $error = 'name';
        elseif ( ! $agree )                     $error = 'agree';
        elseif ( username_exists( $username ) ) $error = 'user_exists';
        elseif ( email_exists( $email ) )       $error = 'email_exists';

        if ( $error ) {
            wp_safe_redirect( add_query_arg( array_merge( $params, [ 'pn_reg_error' => $error ] ), $reg_page ) );
            exit;
        }

        $uid = wp_create_user( $username, $password, $email );
        if ( is_wp_error( $uid ) ) {
            wp_safe_redirect( add_query_arg( array_merge( $params, [ 'pn_reg_error' => 'wp_error' ] ), $reg_page ) );
            exit;
        }

        wp_update_user( [ 'ID' => $uid, 'first_name' => $first, 'last_name' => $last, 'display_name' => "$first $last" ] );
        update_user_meta( $uid, 'pn_athlete_sport',     $sport );
        update_user_meta( $uid, 'pn_athlete_approved',  0 );
        update_user_meta( $uid, 'pn_registration_date', current_time( 'mysql' ) );

        // Notify admin
        $settings    = get_option( 'prepsnext_settings', [] );
        $admin_email = $settings['contact_email'] ?? get_option( 'admin_email' );
        wp_mail(
            $admin_email,
            'New PrepsNext Athlete Registration',
            "$first $last ($username / $email) has registered. Approve at: " . admin_url( 'users.php' )
        );

        wp_safe_redirect( home_url( '/prepsnext-login/?registered=1' ) );
        exit;
    }

    /* ── HELPER ──────────────────────────────────────────────────── */
    private static function notif_text( $type ) {
        $map = [
            'like'    => 'liked your thread',
            'comment' => 'replied to your thread',
            'repost'  => 'reposted your thread',
            'follow'  => 'started following you',
            'mention' => 'mentioned you',
        ];
        return $map[ $type ] ?? 'interacted with your post';
    }
}
