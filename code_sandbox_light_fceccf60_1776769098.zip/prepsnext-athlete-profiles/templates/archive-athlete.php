<?php
/**
 * Athlete Profile Archive Template
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

// Filters from query string
$filter_sport = sanitize_text_field( $_GET['sport']  ?? '' );
$filter_state = sanitize_text_field( $_GET['state']  ?? '' );
$filter_class = sanitize_text_field( $_GET['class']  ?? '' );
$filter_pos   = sanitize_text_field( $_GET['pos']    ?? '' );
$search       = sanitize_text_field( $_GET['search'] ?? '' );
?>

<div class="pn-archive-wrapper">
    <div class="pn-archive-hero">
        <h1 class="pn-archive-title">🏆 Athlete Profiles</h1>
        <p class="pn-archive-subtitle">Discover the next generation of stars</p>
    </div>

    <!-- Filter Bar -->
    <form class="pn-filter-bar" method="GET" action="<?php echo esc_url(get_post_type_archive_link('pn_athlete')); ?>">
        <div class="pn-filter-inner">
            <input type="search" name="search" class="pn-filter-search"
                   placeholder="Search athlete name..." value="<?php echo esc_attr($search); ?>">

            <select name="sport" class="pn-filter-select">
                <option value="">All Sports</option>
                <?php $sports = get_terms(['taxonomy'=>'pn_sport','hide_empty'=>true]);
                foreach($sports as $t): ?>
                <option value="<?php echo esc_attr($t->slug); ?>" <?php selected($filter_sport,$t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="state" class="pn-filter-select">
                <option value="">All States</option>
                <?php $states = get_terms(['taxonomy'=>'pn_state','hide_empty'=>true]);
                foreach($states as $t): ?>
                <option value="<?php echo esc_attr($t->slug); ?>" <?php selected($filter_state,$t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="class" class="pn-filter-select">
                <option value="">All Classes</option>
                <?php $classes = get_terms(['taxonomy'=>'pn_class_year','hide_empty'=>true]);
                foreach($classes as $t): ?>
                <option value="<?php echo esc_attr($t->slug); ?>" <?php selected($filter_class,$t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="pos" class="pn-filter-select">
                <option value="">All Positions</option>
                <?php $positions = get_terms(['taxonomy'=>'pn_position','hide_empty'=>true]);
                foreach($positions as $t): ?>
                <option value="<?php echo esc_attr($t->slug); ?>" <?php selected($filter_pos,$t->slug); ?>><?php echo esc_html($t->name); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="pn-btn pn-btn-primary">Filter</button>
            <?php if($filter_sport||$filter_state||$filter_class||$filter_pos||$search): ?>
            <a href="<?php echo esc_url(get_post_type_archive_link('pn_athlete')); ?>" class="pn-btn pn-btn-outline">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <!-- Athlete Grid -->
    <div class="pn-archive-content">
        <?php if ( have_posts() ) : ?>
        <div class="pn-athlete-grid">
            <?php while ( have_posts() ) : the_post();
                $pid        = get_the_ID();
                $first_name = get_post_meta($pid,'_pn_first_name',true) ?: get_the_title();
                $last_name  = get_post_meta($pid,'_pn_last_name',true);
                $school     = get_post_meta($pid,'_pn_school_name',true);
                $height     = get_post_meta($pid,'_pn_height',true);
                $positions  = get_post_meta($pid,'_pn_positions',true);
                $city       = get_post_meta($pid,'_pn_city',true);
                $nat_rank   = get_post_meta($pid,'_pn_national_rank',true);
                $state_rank = get_post_meta($pid,'_pn_state_rank',true);
                $status     = get_post_meta($pid,'_pn_prospect_status',true);
                $action_id  = get_post_meta($pid,'_pn_action_image_id',true);

                $sport_terms  = get_the_terms($pid,'pn_sport');
                $sport        = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';
                $sport_icon   = strtolower($sport)==='football' ? '🏈' : '🏀';
                $class_terms  = get_the_terms($pid,'pn_class_year');
                $class_year   = $class_terms && !is_wp_error($class_terms) ? $class_terms[0]->name : '';
                $state_terms  = get_the_terms($pid,'pn_state');
                $state        = $state_terms && !is_wp_error($state_terms) ? $state_terms[0]->name : '';

                $thumb_url = $action_id ? wp_get_attachment_image_url($action_id,'medium') : get_the_post_thumbnail_url($pid,'medium');
                ?>
                <article class="pn-athlete-card">
                    <a href="<?php the_permalink(); ?>" class="pn-athlete-card-link">
                        <div class="pn-athlete-card-photo">
                            <?php if($thumb_url): ?>
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo esc_attr("$first_name $last_name"); ?>">
                            <?php else: ?>
                            <div class="pn-athlete-card-placeholder"><?php echo esc_html($sport_icon); ?></div>
                            <?php endif; ?>
                            <?php if($status === 'top_prospect'): ?>
                            <div class="pn-card-badge pn-badge--gold">TOP PROSPECT</div>
                            <?php elseif($status === 'featured'): ?>
                            <div class="pn-card-badge pn-badge--featured">FEATURED</div>
                            <?php elseif($status === 'stock_riser'): ?>
                            <div class="pn-card-badge pn-badge--riser">📈 RISER</div>
                            <?php endif; ?>
                        </div>
                        <div class="pn-athlete-card-info">
                            <div class="pn-athlete-card-sport"><?php echo esc_html($sport_icon.' '.$sport); ?></div>
                            <h2 class="pn-athlete-card-name">
                                <?php echo esc_html($first_name); ?><br>
                                <strong><?php echo esc_html($last_name); ?></strong>
                            </h2>
                            <?php if($school): ?><div class="pn-athlete-card-school"><?php echo esc_html($school); ?></div><?php endif; ?>
                            <div class="pn-athlete-card-meta">
                                <?php if($positions): ?><span><?php echo esc_html($positions); ?></span><?php endif; ?>
                                <?php if($height): ?><span><?php echo esc_html($height); ?></span><?php endif; ?>
                                <?php if($class_year): ?><span><?php echo esc_html($class_year); ?></span><?php endif; ?>
                            </div>
                            <?php if($city || $state): ?>
                            <div class="pn-athlete-card-location">📍 <?php echo esc_html(trim(($city?$city.', ':'').$state)); ?></div>
                            <?php endif; ?>
                            <?php if($nat_rank || $state_rank): ?>
                            <div class="pn-athlete-card-rank">
                                <?php if($nat_rank): ?><span class="pn-cr-rank">#<?php echo esc_html($nat_rank); ?> Nat.</span><?php endif; ?>
                                <?php if($state_rank): ?><span class="pn-cr-rank">#<?php echo esc_html($state_rank); ?> State</span><?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="pn-pagination">
            <?php the_posts_pagination([
                'mid_size'  => 2,
                'prev_text' => '← Prev',
                'next_text' => 'Next →',
            ]); ?>
        </div>

        <?php else: ?>
        <div class="pn-no-results">
            <div class="pn-no-results-icon">🔍</div>
            <h2>No Athletes Found</h2>
            <p>Try adjusting your search filters.</p>
            <a href="<?php echo esc_url(get_post_type_archive_link('pn_athlete')); ?>" class="pn-btn pn-btn-primary">View All Athletes</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer();
