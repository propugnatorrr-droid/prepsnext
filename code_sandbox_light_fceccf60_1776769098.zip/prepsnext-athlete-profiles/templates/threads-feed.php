<?php
/**
 * PrepsNext Threads — Main Feed Template
 * Rendered via [prepsnext_feed] shortcode
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$uid       = get_current_user_id();
$approved  = PrepsNext_Threads::current_user_approved();
$me        = $uid ? PrepsNext_Threads::get_user_display( $uid ) : null;
$threads   = PrepsNext_Threads::get_feed( 1, 20 );
$notif_count = $uid ? PrepsNext_Threads::unread_notification_count( $uid ) : 0;
?>
<div class="pnt-app" id="pnt-app">

    <!-- ── Top Nav ────────────────────────────────────────────── -->
    <nav class="pnt-nav">
        <a href="<?php echo esc_url( home_url('/prepsnext-feed/') ); ?>" class="pnt-nav-logo">
            <span class="pnt-logo-icon">🏆</span>
            <span class="pnt-logo-text">PrepsNext</span>
        </a>

        <div class="pnt-nav-tabs">
            <button class="pnt-nav-tab pnt-nav-tab--active" data-filter="all">For You</button>
            <?php if ( $uid ): ?>
            <button class="pnt-nav-tab" data-filter="following">Following</button>
            <?php endif; ?>
            <button class="pnt-nav-tab" data-filter="sport" data-sport="basketball">🏀 Basketball</button>
            <button class="pnt-nav-tab" data-filter="sport" data-sport="football">🏈 Football</button>
        </div>

        <div class="pnt-nav-right">
            <?php if ( $uid ): ?>
            <button class="pnt-notif-btn" id="pnt-notif-btn" title="Notifications">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <?php if ( $notif_count > 0 ): ?>
                <span class="pnt-notif-badge" id="pnt-notif-badge"><?php echo $notif_count; ?></span>
                <?php endif; ?>
            </button>
            <div class="pnt-notif-panel" id="pnt-notif-panel" style="display:none">
                <div class="pnt-notif-header">
                    <strong>Notifications</strong>
                    <button class="pnt-notif-close" id="pnt-notif-close">✕</button>
                </div>
                <div class="pnt-notif-list" id="pnt-notif-list">
                    <div class="pnt-loading-spinner"></div>
                </div>
            </div>
            <?php if ( $me ): ?>
            <a href="<?php echo esc_url( $me['profile_url'] ?: '#' ); ?>" class="pnt-nav-avatar-link">
                <?php if ( $me['avatar'] ): ?>
                <img src="<?php echo esc_url( $me['avatar'] ); ?>" class="pnt-avatar pnt-avatar--nav" alt="">
                <?php else: ?>
                <div class="pnt-avatar pnt-avatar--nav pnt-avatar--placeholder"><?php echo esc_html( mb_strtoupper( mb_substr( $me['name'], 0, 1 ) ) ); ?></div>
                <?php endif; ?>
            </a>
            <?php endif; ?>
            <a href="<?php echo esc_url( wp_logout_url( home_url('/prepsnext-feed/') ) ); ?>" class="pnt-btn pnt-btn--ghost pnt-btn--sm">Log out</a>
            <?php else: ?>
            <a href="<?php echo esc_url( home_url('/prepsnext-login/') ); ?>" class="pnt-btn pnt-btn--ghost pnt-btn--sm">Log in</a>
            <a href="<?php echo esc_url( home_url('/prepsnext-register/') ); ?>" class="pnt-btn pnt-btn--accent pnt-btn--sm">Sign up</a>
            <?php endif; ?>
        </div>
    </nav>

    <div class="pnt-layout">

        <!-- ── Left Sidebar ─────────────────────────────────────── -->
        <aside class="pnt-sidebar pnt-sidebar--left">
            <nav class="pnt-sidebar-nav">
                <a href="<?php echo esc_url( home_url('/prepsnext-feed/') ); ?>" class="pnt-sidebar-link pnt-sidebar-link--active">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    Home
                </a>
                <a href="<?php echo esc_url( get_post_type_archive_link('pn_athlete') ?: '#' ); ?>" class="pnt-sidebar-link">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    Explore Athletes
                </a>
                <?php if ( $uid && $me ): ?>
                <a href="<?php echo esc_url( $me['profile_url'] ?: '#' ); ?>" class="pnt-sidebar-link">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    My Profile
                </a>
                <?php endif; ?>
                <?php if ( ! $uid ): ?>
                <a href="<?php echo esc_url( home_url('/prepsnext-login/') ); ?>" class="pnt-sidebar-link">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                    Log In
                </a>
                <a href="<?php echo esc_url( home_url('/prepsnext-register/') ); ?>" class="pnt-sidebar-link">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
                    Sign Up
                </a>
                <?php endif; ?>
            </nav>

            <?php if ( $uid && ! $approved ): ?>
            <div class="pnt-approval-banner">
                <span>⏳</span>
                <div>
                    <strong>Pending Approval</strong>
                    <p>An admin will approve your account soon. You can browse but not post yet.</p>
                </div>
            </div>
            <?php endif; ?>
        </aside>

        <!-- ── Main Feed ─────────────────────────────────────────── -->
        <main class="pnt-main">

            <!-- Compose Box -->
            <?php if ( $approved ): ?>
            <div class="pnt-compose-card" id="pnt-compose-card">
                <div class="pnt-compose-inner">
                    <?php if ( $me && $me['avatar'] ): ?>
                    <img src="<?php echo esc_url( $me['avatar'] ); ?>" class="pnt-avatar" alt="">
                    <?php else: ?>
                    <div class="pnt-avatar pnt-avatar--placeholder"><?php echo $me ? esc_html( mb_strtoupper( mb_substr( $me['name'], 0, 1 ) ) ) : '?'; ?></div>
                    <?php endif; ?>
                    <div class="pnt-compose-fields">
                        <textarea id="pnt-compose-body" class="pnt-compose-textarea" placeholder="What's happening in your sport…" maxlength="500" rows="2"></textarea>
                        <div class="pnt-compose-meta" id="pnt-compose-meta" style="display:none">
                            <div class="pnt-compose-img-preview" id="pnt-compose-img-preview"></div>
                        </div>
                        <div class="pnt-compose-toolbar">
                            <div class="pnt-compose-tools">
                                <label class="pnt-tool-btn" title="Add Photo">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                                    <input type="file" id="pnt-compose-img" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none">
                                </label>
                                <select id="pnt-compose-sport" class="pnt-sport-select">
                                    <option value="">🏆 All Sports</option>
                                    <option value="basketball">🏀 Basketball</option>
                                    <option value="football">🏈 Football</option>
                                </select>
                            </div>
                            <div class="pnt-compose-right">
                                <span class="pnt-char-count" id="pnt-char-count">500</span>
                                <button class="pnt-btn pnt-btn--accent" id="pnt-post-btn">Post</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php elseif ( ! $uid ): ?>
            <div class="pnt-guest-cta">
                <div class="pnt-guest-cta-inner">
                    <span class="pnt-guest-cta-icon">🏆</span>
                    <div>
                        <strong>Join PrepsNext</strong>
                        <p>Sign up as an athlete to post, comment, and showcase yourself.</p>
                    </div>
                    <div class="pnt-guest-cta-actions">
                        <a href="<?php echo esc_url( home_url('/prepsnext-login/') ); ?>" class="pnt-btn pnt-btn--ghost pnt-btn--sm">Log in</a>
                        <a href="<?php echo esc_url( home_url('/prepsnext-register/') ); ?>" class="pnt-btn pnt-btn--accent pnt-btn--sm">Sign up free</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Feed Tabs (mobile) -->
            <div class="pnt-feed-tabs-mobile">
                <button class="pnt-feed-tab pnt-feed-tab--active" data-filter="all">For You</button>
                <?php if ( $uid ): ?><button class="pnt-feed-tab" data-filter="following">Following</button><?php endif; ?>
                <button class="pnt-feed-tab" data-filter="sport" data-sport="basketball">🏀</button>
                <button class="pnt-feed-tab" data-filter="sport" data-sport="football">🏈</button>
            </div>

            <!-- Thread List -->
            <div class="pnt-thread-list" id="pnt-thread-list">
                <?php foreach ( $threads as $thread ):
                    PrepsNext_Threads::render_thread_card( $thread, $uid );
                endforeach;

                if ( empty( $threads ) ): ?>
                <div class="pnt-empty-state">
                    <div class="pnt-empty-icon">🏟️</div>
                    <h3>No threads yet</h3>
                    <p>Be the first athlete to post on PrepsNext.</p>
                </div>
                <?php endif; ?>
            </div>

            <div class="pnt-load-more-wrap" id="pnt-load-more-wrap">
                <button class="pnt-btn pnt-btn--ghost pnt-load-more" id="pnt-load-more" data-page="2">Load more</button>
            </div>
        </main>

        <!-- ── Right Sidebar ─────────────────────────────────────── -->
        <aside class="pnt-sidebar pnt-sidebar--right">
            <div class="pnt-widget">
                <h3 class="pnt-widget-title">🔥 Top Prospects</h3>
                <?php
                $top = get_posts([
                    'post_type'  => 'pn_athlete',
                    'numberposts'=> 5,
                    'meta_query' => [['key'=>'_pn_prospect_status','value'=>'top_prospect']],
                ]);
                foreach ( $top as $tp ):
                    $tfirst = get_post_meta($tp->ID,'_pn_first_name',true);
                    $tlast  = get_post_meta($tp->ID,'_pn_last_name',true);
                    $tname  = trim("$tfirst $tlast") ?: $tp->post_title;
                    $tschool= get_post_meta($tp->ID,'_pn_school_name',true);
                    $tnat   = get_post_meta($tp->ID,'_pn_national_rank',true);
                    $tsport_terms = get_the_terms($tp->ID,'pn_sport');
                    $tsport = $tsport_terms && !is_wp_error($tsport_terms) ? $tsport_terms[0]->name : '';
                    $thead_id = get_post_meta($tp->ID,'_pn_headshot_id',true);
                    $tthumb = $thead_id ? wp_get_attachment_image_url($thead_id,'thumbnail') : get_the_post_thumbnail_url($tp->ID,'thumbnail');
                ?>
                <a href="<?php echo get_permalink($tp->ID); ?>" class="pnt-widget-athlete">
                    <?php if($tthumb): ?>
                    <img src="<?php echo esc_url($tthumb); ?>" class="pnt-avatar pnt-avatar--sm" alt="">
                    <?php else: ?>
                    <div class="pnt-avatar pnt-avatar--sm pnt-avatar--placeholder">🏆</div>
                    <?php endif; ?>
                    <div class="pnt-widget-athlete-info">
                        <div class="pnt-widget-athlete-name"><?php echo esc_html($tname); ?> <span class="pnt-badge pnt-badge--gold">⭐</span></div>
                        <div class="pnt-widget-athlete-meta"><?php echo esc_html($tsport); ?><?php echo $tnat ? ' · #'.$tnat.' Nat.' : ''; ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
                <?php if ( empty($top) ): ?>
                <p class="pnt-widget-empty">No top prospects yet.</p>
                <?php endif; ?>
            </div>

            <div class="pnt-widget">
                <h3 class="pnt-widget-title">📈 Rising Athletes</h3>
                <?php
                $rising = get_posts([
                    'post_type'  => 'pn_athlete',
                    'numberposts'=> 4,
                    'meta_query' => [['key'=>'_pn_prospect_status','value'=>'stock_riser']],
                    'orderby'    => 'rand',
                ]);
                foreach ( $rising as $rp ):
                    $rfirst = get_post_meta($rp->ID,'_pn_first_name',true);
                    $rlast  = get_post_meta($rp->ID,'_pn_last_name',true);
                    $rname  = trim("$rfirst $rlast") ?: $rp->post_title;
                    $rsport_terms = get_the_terms($rp->ID,'pn_sport');
                    $rsport = $rsport_terms && !is_wp_error($rsport_terms) ? $rsport_terms[0]->name : '';
                    $rhead_id = get_post_meta($rp->ID,'_pn_headshot_id',true);
                    $rthumb = $rhead_id ? wp_get_attachment_image_url($rhead_id,'thumbnail') : get_the_post_thumbnail_url($rp->ID,'thumbnail');
                ?>
                <a href="<?php echo get_permalink($rp->ID); ?>" class="pnt-widget-athlete">
                    <?php if($rthumb): ?>
                    <img src="<?php echo esc_url($rthumb); ?>" class="pnt-avatar pnt-avatar--sm" alt="">
                    <?php else: ?>
                    <div class="pnt-avatar pnt-avatar--sm pnt-avatar--placeholder">📈</div>
                    <?php endif; ?>
                    <div class="pnt-widget-athlete-info">
                        <div class="pnt-widget-athlete-name"><?php echo esc_html($rname); ?> <span class="pnt-badge pnt-badge--riser">📈</span></div>
                        <div class="pnt-widget-athlete-meta"><?php echo esc_html($rsport); ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>

            <p class="pnt-footer-links">
                <a href="<?php echo esc_url( home_url() ); ?>">Home</a> ·
                <a href="<?php echo esc_url( get_post_type_archive_link('pn_athlete') ?: '#' ); ?>">Athletes</a>
            </p>
        </aside>
    </div>

    <!-- ── Thread Detail Modal ───────────────────────────────────── -->
    <div class="pnt-modal-overlay" id="pnt-thread-modal" style="display:none" role="dialog" aria-modal="true">
        <div class="pnt-modal">
            <button class="pnt-modal-close" id="pnt-modal-close">✕</button>
            <div class="pnt-modal-body" id="pnt-modal-body">
                <div class="pnt-loading-spinner"></div>
            </div>
        </div>
    </div>

    <!-- ── Repost Modal ──────────────────────────────────────────── -->
    <div class="pnt-modal-overlay" id="pnt-repost-modal" style="display:none" role="dialog" aria-modal="true">
        <div class="pnt-modal pnt-modal--sm">
            <button class="pnt-modal-close pnt-repost-cancel">✕</button>
            <h3 class="pnt-modal-title">Repost</h3>
            <div class="pnt-repost-options">
                <button class="pnt-repost-option" id="pnt-repost-plain">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
                    <span><strong>Repost</strong><small>Share this thread instantly</small></span>
                </button>
                <button class="pnt-repost-option" id="pnt-quote-open">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    <span><strong>Quote</strong><small>Add your own comment</small></span>
                </button>
            </div>
            <div id="pnt-quote-compose" style="display:none">
                <textarea id="pnt-quote-body" class="pnt-compose-textarea" placeholder="Add a comment…" maxlength="500" rows="3"></textarea>
                <div class="pnt-compose-toolbar" style="margin-top:10px">
                    <span></span>
                    <button class="pnt-btn pnt-btn--accent pnt-btn--sm" id="pnt-quote-submit">Quote Post</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ── Toast ─────────────────────────────────────────────────── -->
    <div class="pnt-toast" id="pnt-toast" style="display:none"></div>

</div>
