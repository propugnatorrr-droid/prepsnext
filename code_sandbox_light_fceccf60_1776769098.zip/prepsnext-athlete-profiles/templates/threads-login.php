<?php
/**
 * PrepsNext Threads — Login Template
 *
 * Login is processed via admin-post.php (pn_thread_login action)
 * to avoid wp_redirect() inside ob_start() which causes fatal errors.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$redirect = esc_url_raw( $_GET['redirect_to'] ?? home_url( '/prepsnext-feed/' ) );
$error    = sanitize_text_field( $_GET['pn_login_error'] ?? '' );
$registered = ! empty( $_GET['registered'] );

$error_messages = [
    'nonce'    => 'Security check failed. Please try again.',
    'invalid'  => 'Incorrect username or password.',
    'generic'  => 'Login failed. Please try again.',
];
?>
<div class="pnt-auth-wrap">
    <div class="pnt-auth-card">
        <div class="pnt-auth-logo">
            <span class="pnt-logo-icon" style="font-size:40px">🏆</span>
            <h1 class="pnt-auth-title">Welcome back</h1>
            <p class="pnt-auth-sub">Log in to your PrepsNext athlete account</p>
        </div>

        <?php if ( $error && isset( $error_messages[ $error ] ) ): ?>
        <div class="pnt-alert pnt-alert--error"><?php echo esc_html( $error_messages[ $error ] ); ?></div>
        <?php endif; ?>

        <?php if ( $registered ): ?>
        <div class="pnt-alert pnt-alert--success">✅ Account created! An admin will approve you shortly. You can log in now to browse.</div>
        <?php endif; ?>

        <form method="POST" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pnt-auth-form">
            <?php wp_nonce_field( 'pn_thread_login', 'pn_login_nonce' ); ?>
            <input type="hidden" name="action"      value="pn_thread_login">
            <input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect ); ?>">
            <input type="hidden" name="login_page"  value="<?php echo esc_attr( get_permalink() ); ?>">

            <div class="pnt-field">
                <label for="pn-username">Username or Email</label>
                <input type="text" id="pn-username" name="username"
                       value="<?php echo esc_attr( $_GET['pn_login_user'] ?? '' ); ?>"
                       autocomplete="username" required>
            </div>
            <div class="pnt-field">
                <label for="pn-password">Password</label>
                <div class="pnt-input-eye">
                    <input type="password" id="pn-password" name="password" autocomplete="current-password" required>
                    <button type="button" class="pnt-eye-toggle" tabindex="-1">👁</button>
                </div>
            </div>
            <div class="pnt-field pnt-field--row">
                <label class="pnt-checkbox-label">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="pnt-link">Forgot password?</a>
            </div>
            <button type="submit" class="pnt-btn pnt-btn--accent pnt-btn--full">Log In</button>
        </form>

        <p class="pnt-auth-switch">Don't have an account? <a href="<?php echo esc_url( home_url( '/prepsnext-register/' ) ); ?>" class="pnt-link">Sign up free →</a></p>
    </div>
</div>
