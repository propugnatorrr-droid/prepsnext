<?php
/**
 * PrepsNext Threads — Registration Template
 *
 * Registration is processed via admin-post.php (pn_thread_register action)
 * to avoid wp_redirect() inside ob_start() which causes fatal errors.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$error_map = [
    'nonce'     => 'Security check failed.',
    'username'  => 'Username is required.',
    'email'     => 'A valid email is required.',
    'password'  => 'Password must be at least 8 characters.',
    'match'     => 'Passwords do not match.',
    'name'      => 'First and last name are required.',
    'agree'     => 'You must agree to the terms.',
    'user_exists' => 'That username is already taken.',
    'email_exists'=> 'That email is already registered.',
    'wp_error'  => 'Registration failed. Please try again.',
];
$error = sanitize_text_field( $_GET['pn_reg_error'] ?? '' );
?>
<div class="pnt-auth-wrap">
    <div class="pnt-auth-card pnt-auth-card--wide">
        <div class="pnt-auth-logo">
            <span class="pnt-logo-icon" style="font-size:40px">🏆</span>
            <h1 class="pnt-auth-title">Join PrepsNext</h1>
            <p class="pnt-auth-sub">Create your free athlete account and start showcasing your game</p>
        </div>

        <?php if ( $error && isset( $error_map[ $error ] ) ): ?>
        <div class="pnt-alert pnt-alert--error"><?php echo esc_html( $error_map[ $error ] ); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pnt-auth-form">
            <?php wp_nonce_field( 'pn_thread_register', 'pn_reg_nonce' ); ?>
            <input type="hidden" name="action"       value="pn_thread_register">
            <input type="hidden" name="register_page" value="<?php echo esc_attr( get_permalink() ); ?>">

            <div class="pnt-field-row">
                <div class="pnt-field">
                    <label for="pn-first">First Name *</label>
                    <input type="text" id="pn-first" name="first_name"
                           value="<?php echo esc_attr( $_GET['pn_reg_first'] ?? '' ); ?>"
                           required placeholder="Malik">
                </div>
                <div class="pnt-field">
                    <label for="pn-last">Last Name *</label>
                    <input type="text" id="pn-last" name="last_name"
                           value="<?php echo esc_attr( $_GET['pn_reg_last'] ?? '' ); ?>"
                           required placeholder="Thompson">
                </div>
            </div>

            <div class="pnt-field">
                <label for="pn-reg-username">Username *</label>
                <input type="text" id="pn-reg-username" name="username"
                       value="<?php echo esc_attr( $_GET['pn_reg_username'] ?? '' ); ?>"
                       required autocomplete="username" placeholder="malik_hoops3">
            </div>

            <div class="pnt-field">
                <label for="pn-reg-email">Email *</label>
                <input type="email" id="pn-reg-email" name="email"
                       value="<?php echo esc_attr( $_GET['pn_reg_email'] ?? '' ); ?>"
                       required autocomplete="email" placeholder="you@example.com">
            </div>

            <div class="pnt-field">
                <label for="pn-reg-sport">Primary Sport</label>
                <select id="pn-reg-sport" name="sport">
                    <option value="">Select your sport…</option>
                    <option value="basketball" <?php selected( $_GET['pn_reg_sport'] ?? '', 'basketball' ); ?>>🏀 Basketball</option>
                    <option value="football"   <?php selected( $_GET['pn_reg_sport'] ?? '', 'football'   ); ?>>🏈 Football</option>
                </select>
            </div>

            <div class="pnt-field-row">
                <div class="pnt-field">
                    <label for="pn-reg-pass">Password * <small>(min 8 chars)</small></label>
                    <div class="pnt-input-eye">
                        <input type="password" id="pn-reg-pass" name="password" required autocomplete="new-password" minlength="8">
                        <button type="button" class="pnt-eye-toggle" tabindex="-1">👁</button>
                    </div>
                </div>
                <div class="pnt-field">
                    <label for="pn-reg-pass2">Confirm Password *</label>
                    <div class="pnt-input-eye">
                        <input type="password" id="pn-reg-pass2" name="password2" required autocomplete="new-password">
                        <button type="button" class="pnt-eye-toggle" tabindex="-1">👁</button>
                    </div>
                </div>
            </div>

            <div class="pnt-field pnt-field--agreement">
                <label class="pnt-checkbox-label">
                    <input type="checkbox" name="agree" required>
                    I agree to the <a href="#" class="pnt-link">Terms of Service</a> and <a href="#" class="pnt-link">Privacy Policy</a>
                </label>
            </div>

            <button type="submit" class="pnt-btn pnt-btn--accent pnt-btn--full">Create Account</button>
        </form>

        <div class="pnt-auth-info">
            <p>🔒 Your account will be reviewed by a PrepsNext admin before you can post. This keeps the community exclusive to real athletes.</p>
        </div>

        <p class="pnt-auth-switch">Already have an account? <a href="<?php echo esc_url( home_url( '/prepsnext-login/' ) ); ?>" class="pnt-link">Log in →</a></p>
    </div>
</div>
