<?php
/**
 * Single Athlete Profile Template
 * Override by placing a copy in your-theme/prepsnext/single-athlete.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while ( have_posts() ) :
    the_post();
    $pid = get_the_ID();

    // ── Fetch all meta ────────────────────────────────────────────────────
    $first_name    = get_post_meta( $pid, '_pn_first_name', true ) ?: get_the_title();
    $last_name     = get_post_meta( $pid, '_pn_last_name', true );
    $city          = get_post_meta( $pid, '_pn_city', true );
    $bio           = get_post_meta( $pid, '_pn_bio', true );
    $dob           = get_post_meta( $pid, '_pn_dob', true );

    // Sport & Class
    $sport_terms   = get_the_terms( $pid, 'pn_sport' );
    $sport         = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->name : '';
    $sport_slug    = $sport_terms && !is_wp_error($sport_terms) ? $sport_terms[0]->slug : 'basketball';
    $class_terms   = get_the_terms( $pid, 'pn_class_year' );
    $class_year    = $class_terms && !is_wp_error($class_terms) ? $class_terms[0]->name : '';
    $state_terms   = get_the_terms( $pid, 'pn_state' );
    $state         = $state_terms && !is_wp_error($state_terms) ? $state_terms[0]->name : '';

    // School
    $school_name   = get_post_meta( $pid, '_pn_school_name', true );
    $school_loc    = get_post_meta( $pid, '_pn_school_location', true );
    $school_logo_id= get_post_meta( $pid, '_pn_school_logo_id', true );
    $team_name     = get_post_meta( $pid, '_pn_team_name', true );
    $jersey        = get_post_meta( $pid, '_pn_jersey_number', true );
    $positions     = get_post_meta( $pid, '_pn_positions', true );
    $conference    = get_post_meta( $pid, '_pn_conference', true );
    $division      = get_post_meta( $pid, '_pn_division', true );

    // Measurements
    $height        = get_post_meta( $pid, '_pn_height', true );
    $weight        = get_post_meta( $pid, '_pn_weight', true );
    $wingspan      = get_post_meta( $pid, '_pn_wingspan', true );
    $dom_hand      = get_post_meta( $pid, '_pn_dominant_hand', true );
    $dom_foot      = get_post_meta( $pid, '_pn_dominant_foot', true );
    $vertical      = get_post_meta( $pid, '_pn_vertical', true );
    $forty         = get_post_meta( $pid, '_pn_forty_time', true );
    $bench         = get_post_meta( $pid, '_pn_bench_press', true );
    $hand_size     = get_post_meta( $pid, '_pn_hand_size', true );
    $shuttle       = get_post_meta( $pid, '_pn_shuttle', true );

    // Academics
    $gpa           = get_post_meta( $pid, '_pn_gpa', true );
    $sat           = get_post_meta( $pid, '_pn_sat_score', true );
    $act           = get_post_meta( $pid, '_pn_act_score', true );
    $major         = get_post_meta( $pid, '_pn_intended_major', true );
    $ncaa_eli      = get_post_meta( $pid, '_pn_ncaa_eligible', true );
    $honors        = get_post_meta( $pid, '_pn_academic_honors', true );

    // Rankings
    $prospect_status= get_post_meta( $pid, '_pn_prospect_status', true );
    $nat_rank      = get_post_meta( $pid, '_pn_national_rank', true );
    $state_rank    = get_post_meta( $pid, '_pn_state_rank', true );
    $pos_rank      = get_post_meta( $pid, '_pn_position_rank', true );
    $rank_label    = get_post_meta( $pid, '_pn_rank_label', true );
    $watchlist     = get_post_meta( $pid, '_pn_watchlist_rank', true );
    $watch_label   = get_post_meta( $pid, '_pn_watchlist_label', true );
    $stock_riser   = get_post_meta( $pid, '_pn_stock_riser', true );

    // Recruiting
    $offers        = get_post_meta( $pid, '_pn_college_offers', true );
    $interests     = get_post_meta( $pid, '_pn_college_interests', true );
    $committed_to  = get_post_meta( $pid, '_pn_committed_to', true );
    $college_logos = get_post_meta( $pid, '_pn_college_logos', true );
    $rec_profile   = get_post_meta( $pid, '_pn_recruiting_profile_url', true );

    // Media
    $gallery       = get_post_meta( $pid, '_pn_media_gallery', true );
    $action_img_id = get_post_meta( $pid, '_pn_action_image_id', true );
    $headshot_id   = get_post_meta( $pid, '_pn_headshot_id', true );

    // Social
    $socials_map = [
        'instagram' => ['label'=>'Instagram','icon'=>'pn-icon-instagram'],
        'twitter'   => ['label'=>'Twitter / X','icon'=>'pn-icon-twitter'],
        'tiktok'    => ['label'=>'TikTok','icon'=>'pn-icon-tiktok'],
        'youtube'   => ['label'=>'YouTube','icon'=>'pn-icon-youtube'],
        'hudl'      => ['label'=>'Hudl','icon'=>'pn-icon-hudl'],
        'rivals'    => ['label'=>'Rivals','icon'=>'pn-icon-rivals'],
        'twofour7'  => ['label'=>'247Sports','icon'=>'pn-icon-247'],
        'on3'       => ['label'=>'On3','icon'=>'pn-icon-on3'],
        'espn'      => ['label'=>'ESPN','icon'=>'pn-icon-espn'],
        'facebook'  => ['label'=>'Facebook','icon'=>'pn-icon-facebook'],
    ];

    // Career Seasons
    $seasons       = get_post_meta( $pid, '_pn_seasons', true );
    $stats         = get_post_meta( $pid, '_pn_stats', true );

    // Related posts
    $related_posts = get_post_meta( $pid, '_pn_related_posts', true );
    $athlete_tag   = get_post_meta( $pid, '_pn_athlete_tag', true );

    // Images
    $action_img_url= $action_img_id  ? wp_get_attachment_image_url($action_img_id, 'large')  : '';
    $headshot_url  = $headshot_id    ? wp_get_attachment_image_url($headshot_id, 'medium')    : '';
    $school_logo_url = $school_logo_id ? wp_get_attachment_image_url($school_logo_id,'thumbnail') : '';

    // Build status badge HTML
    $badge_html = '';
    $status_map = [
        'top_prospect' => ['label'=>'TOP PROSPECT','class'=>'pn-badge--gold'],
        'featured'     => ['label'=>'FEATURED','class'=>'pn-badge--featured'],
        'stock_riser'  => ['label'=>'STOCK RISER','class'=>'pn-badge--riser'],
        'under_radar'  => ['label'=>'UNDER THE RADAR','class'=>'pn-badge--radar'],
        'committed'    => ['label'=>'COMMITTED','class'=>'pn-badge--committed'],
        'signed'       => ['label'=>'SIGNED','class'=>'pn-badge--signed'],
    ];
    if ( isset($status_map[$prospect_status]) ) {
        $badge_html = '<div class="pn-status-badge '.$status_map[$prospect_status]['class'].'">'
                    . esc_html($status_map[$prospect_status]['label'])
                    . '</div>';
    }

    // Sport icon
    $sport_icon = ( strtolower($sport_slug) === 'football' ) ? '🏈' : '🏀';

    // Location string
    $location = trim( ($city ? $city.', ' : '') . $state );

    // Contact info (per-athlete private contact, shown if set)
    $athlete_email = get_post_meta( $pid, '_pn_contact_email', true );
    $athlete_phone = get_post_meta( $pid, '_pn_contact_phone', true );
    ?>

    <div class="pn-profile-wrapper pn-sport-<?php echo esc_attr($sport_slug); ?>">

        <!-- ════════════════════════════════════
             PROFILE CARD HERO
        ════════════════════════════════════ -->
        <section class="pn-profile-card" id="pn-hero">
            <div class="pn-card-bg"></div>

            <div class="pn-card-inner">

                <!-- ── Full-width name banner across the top ── -->
                <div class="pn-name-banner">
                    <h1 class="pn-athlete-name">
                        <span class="pn-name-first"><?php echo esc_html($first_name); ?></span>
                        <span class="pn-name-last"><?php echo esc_html($last_name); ?></span>
                    </h1>
                    <?php if($badge_html): ?>
                    <div class="pn-badge-wrap" style="margin-left:auto;flex-shrink:0;"><?php echo $badge_html; ?></div>
                    <?php endif; ?>
                </div>

                <!-- ── Two-column body below the name ── -->
                <div class="pn-card-body">

                <!-- Left: Info -->
                <div class="pn-card-left">

                    <?php if($location): ?>
                    <div class="pn-location">
                        <svg class="pn-pin-icon" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                        <?php echo esc_html($location); ?>
                    </div>
                    <?php endif; ?>

                    <?php if($class_year): ?>
                    <div class="pn-class-year">
                        <span class="pn-label"><?php echo esc_html($class_year); ?></span>
                        <?php if($sport): ?>
                        <span class="pn-sport-badge"><?php echo esc_html($sport_icon.' '.$sport); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if($school_name): ?>
                    <div class="pn-school-block">
                        <?php if($school_logo_url): ?>
                        <div class="pn-school-logo">
                            <img src="<?php echo esc_url($school_logo_url); ?>" alt="<?php echo esc_attr($school_name); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="pn-school-details">
                            <div class="pn-school-name"><?php echo esc_html($school_name); ?></div>
                            <?php if($school_loc): ?><div class="pn-school-loc"><?php echo esc_html($school_loc); ?></div><?php endif; ?>
                            <?php if($positions): ?><div class="pn-school-pos"><?php echo esc_html($positions); ?></div><?php endif; ?>
                            <?php if($jersey): ?><div class="pn-school-jersey">Jersey <?php echo esc_html($jersey); ?></div><?php endif; ?>
                            <?php if($team_name): ?><div class="pn-school-team"><?php echo esc_html($team_name); ?></div><?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Quick Stats Bar -->
                    <div class="pn-quick-stats">
                        <?php if($height): ?><div class="pn-qs-item"><span class="pn-qs-val"><?php echo esc_html($height); ?></span><span class="pn-qs-label">HT</span></div><?php endif; ?>
                        <?php if($weight): ?><div class="pn-qs-item"><span class="pn-qs-val"><?php echo esc_html($weight); ?></span><span class="pn-qs-label">WT</span></div><?php endif; ?>
                        <?php if($positions): ?><div class="pn-qs-item"><span class="pn-qs-val"><?php echo esc_html($positions); ?></span><span class="pn-qs-label">POS</span></div><?php endif; ?>
                        <?php if($jersey): ?><div class="pn-qs-item"><span class="pn-qs-val"><?php echo esc_html($jersey); ?></span><span class="pn-qs-label">JERSEY</span></div><?php endif; ?>
                    </div>

                    <!-- Contact Info Pills -->
                    <?php if($athlete_email || $athlete_phone): ?>
                    <div class="pn-contact-pills">
                        <?php if($athlete_email): ?>
                        <a href="mailto:<?php echo esc_attr($athlete_email); ?>" class="pn-contact-pill pn-pill-email">
                            <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                            <?php echo esc_html($athlete_email); ?>
                        </a>
                        <?php endif; ?>
                        <?php if($athlete_phone): ?>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$athlete_phone)); ?>" class="pn-contact-pill pn-pill-phone">
                            <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                            <?php echo esc_html($athlete_phone); ?>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div><!-- .pn-card-left -->

                <!-- Right: Hero Photo + Rankings -->
                <div class="pn-card-right">
                    <?php if($action_img_url): ?>
                    <div class="pn-hero-image">
                        <div class="pn-hero-glow"></div>
                        <img src="<?php echo esc_url($action_img_url); ?>" alt="<?php echo esc_attr("$first_name $last_name"); ?>">
                    </div>
                    <?php elseif(has_post_thumbnail()): ?>
                    <div class="pn-hero-image">
                        <div class="pn-hero-glow"></div>
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                    <?php endif; ?>

                    <!-- Rankings Panel -->
                    <?php if($nat_rank || $state_rank || $pos_rank || $watchlist): ?>
                    <div class="pn-rankings-panel">
                        <div class="pn-rankings-title">PREPS NEXT RANKINGS</div>
                        <?php if($pos_rank && $rank_label): ?>
                        <div class="pn-rank-item">
                            <span class="pn-rank-num">#<?php echo esc_html($pos_rank); ?></span>
                            <span class="pn-rank-label"><?php echo esc_html(strtoupper($rank_label)); ?></span>
                        </div>
                        <?php elseif($state_rank): ?>
                        <div class="pn-rank-item">
                            <span class="pn-rank-num">#<?php echo esc_html($state_rank); ?></span>
                            <span class="pn-rank-label">IN <?php echo esc_html(strtoupper($state ?: 'STATE')); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if($watchlist && $watch_label): ?>
                        <div class="pn-rank-item">
                            <span class="pn-rank-num">#<?php echo esc_html($watchlist); ?></span>
                            <span class="pn-rank-label"><?php echo esc_html(strtoupper($watch_label)); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if($nat_rank): ?>
                        <div class="pn-rank-item pn-rank-national">
                            <span class="pn-rank-num">#<?php echo esc_html($nat_rank); ?></span>
                            <span class="pn-rank-label">NATIONAL RANK</span>
                        </div>
                        <?php endif; ?>
                        <?php if($stock_riser): ?>
                        <div class="pn-rank-riser">
                            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M3.5 18.5L9.5 12.5L13.5 16.5L22 6.92L20.59 5.51L13.5 13.5L9.5 9.5L2 17L3.5 18.5Z"/></svg>
                            STOCK RISER
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div><!-- .pn-card-right -->

                </div><!-- .pn-card-body -->

            </div><!-- .pn-card-inner -->
        </section><!-- .pn-profile-card -->

        <!-- ════════════════════════════════════
             NAVIGATION TABS
        ════════════════════════════════════ -->
        <nav class="pn-profile-tabs" id="pn-tabs">
            <ul class="pn-tab-list">
                <li><a href="#pn-overview"  class="pn-tab active" data-tab="overview">Overview</a></li>
                <?php if(!empty($gallery) && is_array($gallery)): ?>
                <li><a href="#pn-media"    class="pn-tab" data-tab="media">Media</a></li>
                <?php endif; ?>
                <?php if(!empty($seasons) && is_array($seasons)): ?>
                <li><a href="#pn-career"   class="pn-tab" data-tab="career">Career History</a></li>
                <?php endif; ?>
                <?php if(!empty($stats) && is_array($stats)): ?>
                <li><a href="#pn-stats"    class="pn-tab" data-tab="stats">Stats</a></li>
                <?php endif; ?>
                <?php if(!empty($offers) || !empty($interests) || !empty($committed_to)): ?>
                <li><a href="#pn-recruiting" class="pn-tab" data-tab="recruiting">Recruiting</a></li>
                <?php endif; ?>
                <?php if($gpa || $sat || $act): ?>
                <li><a href="#pn-academics" class="pn-tab" data-tab="academics">Academics</a></li>
                <?php endif; ?>
                <li><a href="#pn-news"     class="pn-tab" data-tab="news">News</a></li>
            </ul>
        </nav>

        <!-- ════════════════════════════════════
             MAIN CONTENT
        ════════════════════════════════════ -->
        <div class="pn-profile-content">
            <div class="pn-content-main">

                <!-- OVERVIEW TAB -->
                <section id="pn-overview" class="pn-tab-section active">

                    <?php if($bio): ?>
                    <div class="pn-section pn-about-section">
                        <h2 class="pn-section-title">About</h2>
                        <p class="pn-bio-text"><?php echo wp_kses_post($bio); ?></p>
                    </div>
                    <?php endif; ?>

                    <!-- Measurements -->
                    <?php if($height || $weight || $wingspan || $dom_hand || $dom_foot || $vertical || $forty): ?>
                    <div class="pn-section pn-measurements-section">
                        <h2 class="pn-section-title">📏 Measurements</h2>
                        <div class="pn-measurements-grid">
                            <?php
                            $meas = [
                                'Height'         => $height,
                                'Weight'         => $weight,
                                'Wingspan'       => $wingspan,
                                'Hand Size'      => $hand_size,
                                'Dominant Hand'  => $dom_hand,
                                'Dominant Foot'  => $dom_foot,
                                'Vertical Leap'  => $vertical,
                                '40-Yard Dash'   => $forty,
                                'Bench Press'    => $bench,
                                'Shuttle Run'    => $shuttle,
                            ];
                            foreach ($meas as $label => $val):
                                if (!$val) continue;
                            ?>
                            <div class="pn-meas-item">
                                <span class="pn-meas-label"><?php echo esc_html($label); ?></span>
                                <span class="pn-meas-val"><?php echo esc_html($val); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- School Info -->
                    <?php if($school_name || $conference || $division): ?>
                    <div class="pn-section pn-school-section">
                        <h2 class="pn-section-title">🏫 School & Team</h2>
                        <div class="pn-info-grid">
                            <?php if($school_name): ?>
                            <div class="pn-info-row">
                                <span class="pn-info-label">School</span>
                                <span class="pn-info-val"><?php echo esc_html($school_name); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if($school_loc): ?>
                            <div class="pn-info-row">
                                <span class="pn-info-label">Location</span>
                                <span class="pn-info-val"><?php echo esc_html($school_loc); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if($team_name): ?>
                            <div class="pn-info-row">
                                <span class="pn-info-label">Team</span>
                                <span class="pn-info-val"><?php echo esc_html($team_name); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if($conference): ?>
                            <div class="pn-info-row">
                                <span class="pn-info-label">Conference</span>
                                <span class="pn-info-val"><?php echo esc_html($conference); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if($division): ?>
                            <div class="pn-info-row">
                                <span class="pn-info-label">Division</span>
                                <span class="pn-info-val"><?php echo esc_html($division); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Social Media -->
                    <?php
                    $has_social = false;
                    foreach(array_keys($socials_map) as $sk) {
                        if(get_post_meta($pid,'_pn_social_'.$sk,true)) { $has_social = true; break; }
                    }
                    ?>
                    <?php if($has_social): ?>
                    <div class="pn-section pn-social-section">
                        <h2 class="pn-section-title">📱 Find <?php echo esc_html($first_name); ?> Online</h2>
                        <div class="pn-social-links">
                            <?php foreach($socials_map as $sk => $sinfo):
                                $url = get_post_meta($pid,'_pn_social_'.$sk,true);
                                if(!$url) continue;
                                $icons_svg = [
                                    'instagram' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
                                    'twitter'   => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
                                    'tiktok'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V9.18a8.29 8.29 0 004.84 1.55V7.29a4.85 4.85 0 01-1.07-.6z"/></svg>',
                                    'youtube'   => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
                                    'facebook'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
                                    'hudl'      => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
                                    'rivals'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>',
                                    'twofour7'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-9 3h2v8h-2zm-4 0h2v8H7zm8 0h2v8h-2z"/></svg>',
                                    'on3'       => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>',
                                    'espn'      => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>',
                                ];
                                ?>
                                <a href="<?php echo esc_url($url); ?>" class="pn-social-link pn-social-<?php echo esc_attr($sk); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($sinfo['label']); ?>">
                                    <?php echo $icons_svg[$sk] ?? ''; ?>
                                    <span><?php echo esc_html($sinfo['label']); ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- College Interests -->
                    <?php if($college_logos && is_array($college_logos)): ?>
                    <div class="pn-section pn-interests-section">
                        <h2 class="pn-section-title">🎓 School Interests</h2>
                        <?php if($committed_to): ?>
                        <div class="pn-committed-banner">
                            <span class="pn-committed-label">✅ COMMITTED TO</span>
                            <span class="pn-committed-school"><?php echo esc_html($committed_to); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="pn-college-logos">
                            <?php foreach($college_logos as $logo):
                                if(!$logo['id']) continue;
                                $lurl = wp_get_attachment_image_url($logo['id'],'thumbnail');
                                ?>
                                <div class="pn-college-logo-display" title="<?php echo esc_attr($logo['name']); ?>">
                                    <img src="<?php echo esc_url($lurl); ?>" alt="<?php echo esc_attr($logo['name']); ?>">
                                    <?php if($logo['name']): ?><span><?php echo esc_html($logo['name']); ?></span><?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </section><!-- #pn-overview -->

                <!-- MEDIA TAB -->
                <?php if(!empty($gallery) && is_array($gallery)): ?>
                <section id="pn-media" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">🎬 Photo / Video</h2>
                        <div class="pn-media-grid">
                            <?php
                            // Show featured first
                            usort($gallery, function($a,$b){
                                return ($b['featured'] ?? '') <=> ($a['featured'] ?? '');
                            });
                            foreach($gallery as $gi => $item):
                                $img_url = $item['image_id'] ? wp_get_attachment_image_url($item['image_id'],'medium_large') : '';
                                $is_video = ($item['type'] === 'video');
                                $is_large = ($gi === 0 || $gi === 1);
                                $class = $is_large ? 'pn-media-tile pn-media-large' : 'pn-media-tile';
                                ?>
                                <div class="<?php echo $class; ?>">
                                    <?php if($img_url): ?>
                                    <div class="pn-media-thumb" <?php if($is_video && $item['video_url']): ?>data-video="<?php echo esc_attr($item['video_url']); ?>"<?php endif; ?>>
                                        <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($item['title'] ?? ''); ?>">
                                        <?php if($is_video): ?>
                                        <div class="pn-play-btn">
                                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                                        </div>
                                        <?php endif; ?>
                                        <div class="pn-media-overlay">
                                            <?php if($item['title']): ?><div class="pn-media-title"><?php echo esc_html($item['title']); ?></div><?php endif; ?>
                                            <?php if($item['views']): ?><div class="pn-media-views">👁 <?php echo esc_html($item['views']); ?></div><?php endif; ?>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="pn-media-thumb pn-media-no-img">
                                        <div class="pn-no-img-icon">🎥</div>
                                        <?php if($item['title']): ?><div class="pn-media-title"><?php echo esc_html($item['title']); ?></div><?php endif; ?>
                                        <?php if($item['video_url']): ?>
                                        <a href="<?php echo esc_url($item['video_url']); ?>" target="_blank" class="pn-btn pn-btn-sm">Watch ▶</a>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>
                <?php endif; ?>

                <!-- CAREER HISTORY TAB -->
                <?php if(!empty($seasons) && is_array($seasons)): ?>
                <section id="pn-career" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">📅 Career History</h2>
                        <div class="pn-career-timeline">
                            <?php
                            // Sort by year descending
                            usort($seasons, fn($a,$b) => ($b['year'] ?? 0) <=> ($a['year'] ?? 0));
                            foreach($seasons as $season):
                                $record = '';
                                if($season['record_w'] || $season['record_l']) {
                                    $record = $season['record_w'].'-'.$season['record_l'];
                                }
                            ?>
                            <div class="pn-season-card">
                                <div class="pn-season-header-display">
                                    <div class="pn-season-grade"><?php echo esc_html($season['grade'] ?? ''); ?></div>
                                    <div class="pn-season-year"><?php echo esc_html($season['year'] ?? ''); ?></div>
                                </div>
                                <div class="pn-season-body-display">
                                    <div class="pn-season-school"><?php echo esc_html($season['school'] ?? ''); ?>
                                        <?php if($season['location']): ?><span class="pn-season-loc">(<?php echo esc_html($season['location']); ?>)</span><?php endif; ?>
                                    </div>
                                    <div class="pn-season-details">
                                        <?php if($season['position']): ?><div class="pn-sd-item"><span class="pn-sd-label">Position</span><span class="pn-sd-val"><?php echo esc_html($season['position']); ?></span></div><?php endif; ?>
                                        <?php if($season['jersey']): ?><div class="pn-sd-item"><span class="pn-sd-label">Jersey</span><span class="pn-sd-val"><?php echo esc_html($season['jersey']); ?></span></div><?php endif; ?>
                                        <?php if($season['height']): ?><div class="pn-sd-item"><span class="pn-sd-label">HT</span><span class="pn-sd-val"><?php echo esc_html($season['height']); ?></span></div><?php endif; ?>
                                        <?php if($season['weight']): ?><div class="pn-sd-item"><span class="pn-sd-label">WT</span><span class="pn-sd-val"><?php echo esc_html($season['weight']); ?></span></div><?php endif; ?>
                                        <?php if($record): ?><div class="pn-sd-item"><span class="pn-sd-label">Record</span><span class="pn-sd-val"><?php echo esc_html($record); ?><?php if($season['league']): ?> <span class="pn-season-league"><?php echo esc_html($season['league']); ?></span><?php endif; ?></span></div><?php endif; ?>
                                        <?php if($season['nat_rank']): ?><div class="pn-sd-item"><span class="pn-sd-label">Nat. Rank</span><span class="pn-sd-val pn-rank-highlight"><?php echo esc_html($season['nat_rank']); ?></span></div><?php endif; ?>
                                        <?php if($season['state_rank']): ?><div class="pn-sd-item"><span class="pn-sd-label">State Rank</span><span class="pn-sd-val pn-rank-highlight"><?php echo esc_html($season['state_rank']); ?></span></div><?php endif; ?>
                                    </div>
                                    <?php if($season['notes']): ?>
                                    <div class="pn-season-notes"><?php echo esc_html($season['notes']); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>
                <?php endif; ?>

                <!-- STATS TAB -->
                <?php if(!empty($stats) && is_array($stats)): ?>
                <section id="pn-stats" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">📊 Career Stats</h2>
                        <?php
                        $bball_stats = [
                            'ppg'=>'PPG','rpg'=>'RPG','apg'=>'APG','spg'=>'SPG',
                            'bpg'=>'BPG','fg_pct'=>'FG%','three_pct'=>'3P%','ft_pct'=>'FT%','gp'=>'Games'
                        ];
                        $fb_stats = [
                            'pass_yards'=>'Pass Yds','pass_tds'=>'Pass TDs',
                            'rush_yards'=>'Rush Yds','rush_tds'=>'Rush TDs',
                            'rec_yards'=>'Rec Yds','rec_tds'=>'Rec TDs',
                            'tackles'=>'Tackles','sacks'=>'Sacks','ints'=>'INTs','ff'=>'Forced Fumbles'
                        ];
                        $has_bb = array_filter(array_intersect_key($stats, $bball_stats));
                        $has_fb = array_filter(array_intersect_key($stats, $fb_stats));
                        ?>
                        <?php if($has_bb): ?>
                        <h3 class="pn-stats-subtitle">🏀 Basketball</h3>
                        <div class="pn-stats-grid">
                            <?php foreach($bball_stats as $k => $label):
                                if(empty($stats[$k])) continue; ?>
                            <div class="pn-stat-box">
                                <span class="pn-stat-val"><?php echo esc_html($stats[$k]); ?></span>
                                <span class="pn-stat-label"><?php echo esc_html($label); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <?php if($has_fb): ?>
                        <h3 class="pn-stats-subtitle">🏈 Football</h3>
                        <div class="pn-stats-grid">
                            <?php foreach($fb_stats as $k => $label):
                                if(empty($stats[$k])) continue; ?>
                            <div class="pn-stat-box">
                                <span class="pn-stat-val"><?php echo esc_html($stats[$k]); ?></span>
                                <span class="pn-stat-label"><?php echo esc_html($label); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </section>
                <?php endif; ?>

                <!-- RECRUITING TAB -->
                <?php if(!empty($offers) || !empty($interests) || !empty($committed_to)): ?>
                <section id="pn-recruiting" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">🎓 Recruiting Info</h2>

                        <?php if($committed_to): ?>
                        <div class="pn-committed-card">
                            <div class="pn-committed-icon">✅</div>
                            <div>
                                <div class="pn-committed-label">COMMITTED TO</div>
                                <div class="pn-committed-school-lg"><?php echo esc_html($committed_to); ?></div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(!empty($offers)): ?>
                        <h3 class="pn-subsection-title">Scholarship Offers (<?php echo count($offers); ?>)</h3>
                        <div class="pn-offer-list">
                            <?php foreach($offers as $offer): ?>
                            <div class="pn-offer-item">
                                <span class="pn-offer-dot"></span>
                                <?php echo esc_html($offer); ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>

                        <?php if(!empty($interests)): ?>
                        <h3 class="pn-subsection-title">College Interests</h3>
                        <div class="pn-offer-list">
                            <?php foreach($interests as $int): ?>
                            <div class="pn-offer-item pn-offer-interest">
                                <span class="pn-offer-dot"></span>
                                <?php echo esc_html($int); ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>

                        <?php if($rec_profile): ?>
                        <div style="margin-top:20px;">
                            <a href="<?php echo esc_url($rec_profile); ?>" class="pn-btn pn-btn-outline" target="_blank">
                                View Full Recruiting Profile ↗
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </section>
                <?php endif; ?>

                <!-- ACADEMICS TAB -->
                <?php if($gpa || $sat || $act || $major): ?>
                <section id="pn-academics" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">📚 Academics</h2>
                        <div class="pn-measurements-grid">
                            <?php
                            $acad = [
                                'GPA'             => $gpa,
                                'SAT Score'       => $sat,
                                'ACT Score'       => $act,
                                'Intended Major'  => $major,
                                'NCAA Eligible'   => $ncaa_eli ? 'Yes ✅' : '',
                            ];
                            foreach($acad as $label => $val):
                                if(!$val) continue;
                            ?>
                            <div class="pn-meas-item">
                                <span class="pn-meas-label"><?php echo esc_html($label); ?></span>
                                <span class="pn-meas-val"><?php echo esc_html($val); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if($honors): ?>
                        <div class="pn-honor-list">
                            <h3 class="pn-subsection-title">Honors & Awards</h3>
                            <p><?php echo wp_kses_post(nl2br($honors)); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </section>
                <?php endif; ?>

                <!-- NEWS TAB -->
                <section id="pn-news" class="pn-tab-section">
                    <div class="pn-section">
                        <h2 class="pn-section-title">📰 News & Articles</h2>
                        <?php
                        // Get tagged posts
                        $tag_posts = [];
                        if($athlete_tag) {
                            $tag_posts = get_posts([
                                'post_type'   => 'post',
                                'numberposts' => 12,
                                'tag'         => $athlete_tag,
                                'post_status' => 'publish',
                            ]);
                        }
                        // Merge manually linked posts
                        if(!empty($related_posts)) {
                            foreach($related_posts as $rpid) {
                                if(!in_array($rpid, array_column($tag_posts,'ID'))) {
                                    $rp = get_post($rpid);
                                    if($rp && $rp->post_status === 'publish') {
                                        $tag_posts[] = $rp;
                                    }
                                }
                            }
                        }
                        if(!empty($tag_posts)):
                        ?>
                        <div class="pn-news-grid">
                            <?php foreach($tag_posts as $news_post):
                                $news_thumb = get_the_post_thumbnail_url($news_post->ID,'medium');
                                ?>
                                <article class="pn-news-card">
                                    <?php if($news_thumb): ?>
                                    <a href="<?php echo get_permalink($news_post->ID); ?>" class="pn-news-thumb">
                                        <img src="<?php echo esc_url($news_thumb); ?>" alt="<?php echo esc_attr($news_post->post_title); ?>">
                                    </a>
                                    <?php endif; ?>
                                    <div class="pn-news-body">
                                        <div class="pn-news-date"><?php echo get_the_date('M j, Y', $news_post); ?></div>
                                        <h3 class="pn-news-title">
                                            <a href="<?php echo get_permalink($news_post->ID); ?>"><?php echo esc_html($news_post->post_title); ?></a>
                                        </h3>
                                        <p class="pn-news-excerpt"><?php echo esc_html(wp_trim_words($news_post->post_excerpt ?: $news_post->post_content, 18, '...')); ?></p>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <div class="pn-no-news">
                            <p>No news articles found for <?php echo esc_html("$first_name $last_name"); ?> yet. Check back soon!</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </section>

            </div><!-- .pn-content-main -->

            <!-- SIDEBAR -->
            <aside class="pn-profile-sidebar">

                <!-- Contact CTA -->
                <div class="pn-sidebar-card pn-contact-card">
                    <div class="pn-contact-avatar">
                        <?php if($headshot_url): ?>
                        <img src="<?php echo esc_url($headshot_url); ?>" alt="<?php echo esc_attr("$first_name $last_name"); ?>">
                        <?php elseif($action_img_url): ?>
                        <img src="<?php echo esc_url($action_img_url); ?>" alt="<?php echo esc_attr("$first_name $last_name"); ?>">
                        <?php else: ?>
                        <div class="pn-avatar-placeholder"><?php echo esc_html(substr($first_name,0,1).substr($last_name,0,1)); ?></div>
                        <?php endif; ?>
                    </div>
                    <h3 class="pn-sidebar-name"><?php echo esc_html("$first_name $last_name"); ?></h3>
                    <p class="pn-sidebar-school"><?php echo esc_html($school_name); ?></p>
                    <?php if($athlete_email): ?>
                    <a href="mailto:<?php echo esc_attr($athlete_email); ?>" class="pn-btn pn-btn-primary pn-btn-full">
                        📬 <?php echo esc_html($athlete_email); ?>
                    </a>
                    <?php else: ?>
                    <a href="mailto:<?php echo esc_attr(get_option('admin_email')); ?>?subject=Inquiry: <?php echo esc_attr("$first_name $last_name"); ?>"
                       class="pn-btn pn-btn-primary pn-btn-full">
                        📬 Contact Player
                    </a>
                    <?php endif; ?>
                    <?php if($athlete_phone): ?>
                    <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$athlete_phone)); ?>" class="pn-btn pn-btn-outline pn-btn-full">
                        📞 <?php echo esc_html($athlete_phone); ?>
                    </a>
                    <?php endif; ?>
                    <?php if($rec_profile): ?>
                    <a href="<?php echo esc_url($rec_profile); ?>" class="pn-btn pn-btn-outline pn-btn-full" target="_blank">
                        View Recruiting Profile
                    </a>
                    <?php endif; ?>
                </div>

                <!-- Key Rankings Sidebar Card -->
                <?php if($nat_rank || $state_rank || $pos_rank): ?>
                <div class="pn-sidebar-card pn-sidebar-rankings">
                    <h3 class="pn-sidebar-card-title">🏆 Rankings</h3>
                    <?php if($pos_rank && $rank_label): ?>
                    <div class="pn-sidebar-rank-row">
                        <span class="pn-sr-num">#<?php echo esc_html($pos_rank); ?></span>
                        <span class="pn-sr-label"><?php echo esc_html($rank_label); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if($state_rank): ?>
                    <div class="pn-sidebar-rank-row">
                        <span class="pn-sr-num">#<?php echo esc_html($state_rank); ?></span>
                        <span class="pn-sr-label">In <?php echo esc_html($state); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if($nat_rank): ?>
                    <div class="pn-sidebar-rank-row">
                        <span class="pn-sr-num">#<?php echo esc_html($nat_rank); ?></span>
                        <span class="pn-sr-label">National</span>
                    </div>
                    <?php endif; ?>
                    <?php if($stock_riser): ?>
                    <div class="pn-sidebar-riser">📈 Stock Riser</div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Quick Info Sidebar Card -->
                <div class="pn-sidebar-card pn-sidebar-info">
                    <h3 class="pn-sidebar-card-title">📋 Quick Info</h3>
                    <div class="pn-si-rows">
                        <?php if($sport): ?><div class="pn-si-row"><span>Sport</span><strong><?php echo esc_html($sport_icon.' '.$sport); ?></strong></div><?php endif; ?>
                        <?php if($class_year): ?><div class="pn-si-row"><span>Class</span><strong><?php echo esc_html($class_year); ?></strong></div><?php endif; ?>
                        <?php if($positions): ?><div class="pn-si-row"><span>Position</span><strong><?php echo esc_html($positions); ?></strong></div><?php endif; ?>
                        <?php if($height): ?><div class="pn-si-row"><span>Height</span><strong><?php echo esc_html($height); ?></strong></div><?php endif; ?>
                        <?php if($weight): ?><div class="pn-si-row"><span>Weight</span><strong><?php echo esc_html($weight); ?></strong></div><?php endif; ?>
                        <?php if($school_name): ?><div class="pn-si-row"><span>School</span><strong><?php echo esc_html($school_name); ?></strong></div><?php endif; ?>
                        <?php if($location): ?><div class="pn-si-row"><span>Location</span><strong><?php echo esc_html($location); ?></strong></div><?php endif; ?>
                        <?php if($ncaa_eli): ?><div class="pn-si-row"><span>NCAA</span><strong>Cleared ✅</strong></div><?php endif; ?>
                    </div>
                </div>

            </aside><!-- .pn-profile-sidebar -->

        </div><!-- .pn-profile-content -->

        <!-- Video Modal -->
        <div id="pn-video-modal" class="pn-modal" role="dialog" aria-modal="true" aria-label="Video Player">
            <div class="pn-modal-backdrop"></div>
            <div class="pn-modal-inner">
                <button class="pn-modal-close" aria-label="Close video">✕</button>
                <div class="pn-modal-video"></div>
            </div>
        </div>

    </div><!-- .pn-profile-wrapper -->

<?php endwhile;
get_footer();
